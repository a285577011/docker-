# 保留10天数据，
docker exec -i mysql bash<<'EOF'
if [ ! -d "/var/lib/mysql/backup" ]; then
  mkdir -p /var/lib/mysql/backup
fi
# gcs 为数据库的名称
mysqldump -uroot -p16273849 gcs  | gzip > "/var/lib/mysql/backup/gcs_$(date +%Y%m%d).sql.gz"
#删除超过10天的数据
rm -f /var/lib/mysql/backup/gcs_$(date -d -10day +%Y%m%d).sql
exit
EOF
