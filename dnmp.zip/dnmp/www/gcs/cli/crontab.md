## 计划任务

### 福利彩票
### 双色球 每周二、四、日21:15开奖
* 21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/ssq/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_ssq.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/ssq/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_ssq.log 2>&1
### 福彩3d 每日21:15开奖
* 21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/fc3d/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_fc3d.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/fc3d/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_fc3d.log 2>&1
### 七乐彩 每周一、三、五 21:15开
* 21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/qlc/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_qlc.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/qlc/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_qlc.log 2>&1


### 15选5   每日19:35开奖
* 19 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/fc15x5/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_fc15x5.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/fc15x5/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_fc15x5.log 2>&1
### 东方6+1 每日22:00开奖
* 22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/fc6jia1/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_fc6jia1.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/fucai/table/fc6jia1/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_fucai_fc6jia1.log 2>&1

### pk10 每天 09:10 至 23:50 开奖
* 0-2 * * * www php -f cli/index.php request_uri=/cron/spider/caipiao/type/place/table/pk10/
* 9-23 * * * www php -f cli/index.php request_uri=/cron/spider/caipiao/type/place/table/pk10/


#####------------#####

## 体育彩票
### 排列3 每日20:30开奖
*/5 20 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/ticai/table/pailie3/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_ticai_pailie3.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/ticai/table/pailie3/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_ticai_pailie3.log 2>&1
### 排列5 每日 20:30开奖
*/5 20 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/ticai/table/pailie5/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_ticai_pailie5.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/ticai/table/pailie5/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_ticai_pailie5.log 2>&1
### 七星彩 每周二、五、日 20:30开奖
*/5 20 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/ticai/table/qixingcai/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_ticai_qixingcai.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/ticai/table/qixingcai/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_ticai_qixingcai.log 2>&1
### 超级大乐透 每周一、三、六20:30开奖
*/5 20 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/ticai/table/daletou/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_ticai_daletou.log 2>&1
*/30 * * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/ticai/table/daletou/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_ticai_daletou.log 2>&1
#####------------#####

## 11选5
### 广东11选5	10分钟一期，共84期，每天09:10~23:00开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5gd/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5gd.log 2>&1
### 河北11选5	10 分钟一期，共85期，每天08:30至22:30开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5hb/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5hb.log 2>&1
### 江苏11选5	10 分钟一期，共 82 期， 每天 08:36 至 22:06 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5js/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5js.log 2>&1
### 浙江11选5	10 分钟一期，共 85 期， 每天 08:30 至 22:30 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5zj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5zj.log 2>&1
### 山东11选5	10 分钟一期，共 87 期， 每天 08:36 至 22:56 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5sd/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5sd.log 2>&1
### 上海11选5	10 分钟一期，共 90 期， 每天 09:00 至 23:50 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5sh/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5sh.log 2>&1
### 福建11选5	10 分钟一期，共 90 期， 每天 08:09 至 22:59 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5fj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5fj.log 2>&1
### 北京11选5	10 分钟一期，共 85 期， 每天 09:01 至 23:01 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5bj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5bj.log 2>&1
### 甘肃11选5	10 分钟一期，共 78 期， 每天 10:11 至 23:01 开奖
* 10-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5gs/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5gs.log 2>&1
### 江西11选5	10 分钟一期，共 84 期， 每天 09:10 至 23:00 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5jx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5jx.log 2>&1
### 辽宁11选5	10 分钟一期，共 83 期， 每天 08:49 至 22:29 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5ln/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5ln.log 2>&1
### 安徽11选5	10 分钟一期，共 81 期， 每天 08:40 至 22:00 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5ah/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5ah.log 2>&1
### 新疆11选5	10 分钟一期，共 97 期， 每天 10:01 至 02:01 开奖
* 0-2 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5xj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5xj.log 2>&1
* 10-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5xj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5xj.log 2>&1
### 陕西11选5	10 分钟一期，共 88 期， 每天 08:30 至 23:00 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5sx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5sx.log 2>&1
### 黑龙江11选5	10 分钟一期，共 88 期， 每天 08:05 至 22:35 开奖
* 8-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5hlj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5hlj.log 2>&1
### 山西11选5	10 分钟一期，共 94 期， 每天 08:26 至 23:56 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5shx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5shx.log 2>&1
### 内蒙古11选5	10 分钟一期，共 85 期， 每天 09:06 至 23:06 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5nmg/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5nmg.log 2>&1
### 湖北11选5	10 分钟一期，共 81 期， 每天 08:35 至 21:55 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5hub/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5hub.log 2>&1
### 贵州11选5	10 分钟一期，共 80 期， 每天 09:01 至 22:11 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5gz/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5gz.log 2>&1
### 云南11选5	10 分钟一期，共 85 期， 每天 09:00 至 23:00 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5yn/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5yn.log 2>&1
### 广西11选5	10 分钟一期，共 90 期， 每天 09:01 至 23:51 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5gx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5gx.log 2>&1
### 天津11选5	10 分钟一期，共 90 期， 每天 09:01 至 23:51 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5tj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5tj.log 2>&1
### 吉林11选5	10 分钟一期，共 79 期， 每天 08:30 至 21:30 开奖
* 8-21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5jl/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5jl.log 2>&1
### 宁夏11选5	10 分钟一期，共 79 期， 每天 09:06 至 22:06 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/11x5nx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_11x5nx.log 2>&1
#####------------#####

## 快3
### 江苏快3	10 分钟一期，共 82 期， 每天 08:40 至 22:11 开奖
* 8-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3js/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3js.log 2>&1
### 湖北快3	10 分钟一期，共 78 期， 每天 09:10 至 22:00 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3hb/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3hb.log 2>&1
### 上海快3	10 分钟一期，共 82 期， 每天 08:58 至 22:28 开奖
* 8-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3sh/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3sh.log 2>&1
### 河北快3	10 分钟一期，共 81 期， 每天 08:39 至 21:59 开奖
* 8-21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3heb/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3heb.log 2>&1
### 贵州快3	10 分钟一期，共 78 期， 每天 09:09 至 22:12 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3gz/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3gz.log 2>&1
### 吉林快3	9 分钟一期，共 87 期， 每天 08:29 至 21:32 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3jl/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3jl.log 2>&1
### 安徽快3	10 分钟一期，共 80 期， 每天 08:49 至 21:59 开奖
* 8-21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3ah/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3ah.log 2>&1
### 广西快3	10 分钟一期，共 78 期， 每天 09:37 至 22:27 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3gx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3gx.log 2>&1
### 内蒙古快3	10 分钟一期，共 73 期， 每天 09:44 至 22:00 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3nmg/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3nmg.log 2>&1
### 福建快3	10 分钟一期，共 84 期， 每天 08:40 至 22:41 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3fj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3fj.log 2>&1
### 河南快3	10 分钟一期，共 84 期， 每天 08:45 至 22:35 开奖
* 8-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3hn/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3hn.log 2>&1
### 北京快3	10 分钟一期，共 89 期， 每天 09:10 至 23:50 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3bj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3bj.log 2>&1
### 甘肃快3	10 分钟一期，共 72 期， 每天 10:09 至 21:59 开奖
* 10-21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3gs/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3gs.log 2>&1
### 江西快3	9 分钟一期，共 84 期， 每天 09:05 至 22:51 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/k3jx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_k3jx.log 2>&1
#####------------#####

## 快乐12	
### 四川快乐12	10 分钟一期，共 78 期， 每天 09:09 至 21:59 开奖
* 9-21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl12sc/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl12sc.log 2>&1
### 辽宁快乐12	10 分钟一期，共 80 期， 每天 08:42 至 21:52 开奖
* 8-21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl12ln/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl12ln.log 2>&1
### 浙江快乐12	10 分钟一期，共 80 期， 每天 09:10 至 22:20 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl12zj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl12zj.log 2>&1

#####------------#####

## 快乐十分	
### 广东快乐十分	10 分钟一期，共 84 期， 每天 09:11 至 23:01 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10gd/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10gd.log 2>&1
### 湖南快乐十分	10 分钟一期，共 84 期， 每天 09:10 至 23:00 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10hn/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10hn.log 2>&1
### 云南快乐十分	10 分钟一期，共 72 期， 每天 09:46 至 21:36 开奖
* 9-21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10yn/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10yn.log 2>&1
### 天津快乐十分	9 分钟一期，共 84 期， 每天 09:06 至 22:54 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10tj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10tj.log 2>&1
### 重庆快乐十分	10 分钟一期，共 97 期， 每天 00:04 至 23:54 开奖
* 0-2 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10cq/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10cq.log 2>&1
* 10-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10cq/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10cq.log 2>&1
### 山西快乐十分	10 分钟一期，共 80 期， 每天 08:50 至 22:00 开奖
* 8-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10sx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10sx.log 2>&1
### 陕西快乐十分	10 分钟一期，共 77 期， 每天 09:11 至 21:59 开奖
* 9-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10shx/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10shx.log 2>&1
### 黑龙江快乐十分	10 分钟一期，共 84 期， 每天 08:46 至 22:36 开奖
* 8-22 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/kl10hlj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_kl10hlj.log 2>&1

#####------------#####

## 时时彩	
### 重庆时时彩	5 分钟一期，共 120 期， 每天 00:05 至 00:00 开奖
* 0-2 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/sscqc/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_sscqc.log 2>&1
* 10-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/sscqc/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_sscqc.log 2>&1
### 天津时时彩	10 分钟一期，共 84 期， 每天 09:10 至 23:00 开奖
* 9-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/ssctj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_ssctj.log 2>&1
### 新疆时时彩	10 分钟一期，共 96 期， 每天 10:09 至 01:59 开奖
* 0-2 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/sscxj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_sscxj.log 2>&1
* 10-23 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/sscxj/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_sscxj.log 2>&1
### 内蒙古时时彩	10 分钟一期，共 73 期， 每天 09:41 至 21:55 开奖
* 9-21 * * *  www /usr/local/php7.0/bin/php -f /web/wwwroot/cai.com/www/cli/index.php request_uri=/cron/spider/caipiao/type/icaile/table/sscnmg/ >> /web/logs/cron/cai.com.wwww_cron_caipiao_icaile_sscnmg.log 2>&1