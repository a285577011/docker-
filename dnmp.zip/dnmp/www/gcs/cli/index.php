<?php

/**
 * Created by PhpStorm.
 * User: lindan
 * Date: 2016/6/3
 * Time: 15:27
 *
 * @example php -f cli/index.php request_uri=/Item/Index/index
 */

/**
 *  路径分隔符, 缩写
 */
define('DS', DIRECTORY_SEPARATOR);

/**
 * 应用的根目录
 */
define('APPLICATION_PATH', realpath(__DIR__ . DS . '..'));

/**
 * Web入口目录
 */
define('PUBLIC_PATH', realpath(__DIR__ . DS . '..' . DS . 'public'));

$app = new \Yaf\Application(APPLICATION_PATH . DS . 'conf' . DS . 'application.ini');

$app->bootstrap();
$app->getDispatcher()->dispatch(new \Yaf\Request\Simple());