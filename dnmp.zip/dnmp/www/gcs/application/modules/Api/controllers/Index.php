<?php

use Ku\Aes;

class IndexController extends \Base\AbstractController {

    public function indexAction() {
        //用户主页
        echo 'api';
        exit;
    }
    public function enAction(){
        $aes=new Aes();
        $data = $this->getRequest()->getRequest(); //数组
        unset($data['q']);
        $params=$aes->encrypt(json_encode($data));
        echo $params;die;
    }
}
