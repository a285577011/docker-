<?php

class ErrorController extends \Base\ErrorController {

}
