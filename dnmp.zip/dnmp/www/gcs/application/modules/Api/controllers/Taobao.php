<?php

/**淘宝业务控制器
 * Class TaobaoController
 */
class TaobaoController extends \Base\ApiController
{

    public function addUserAction()
    {
        $post = $this->getPrivateRequest();
        $tbnick = \Ku\FieldVerify::filter_value($post, 'nick');
        if (!$tbnick) {
            return $this->returnData('nick参数缺失', 1001, false, null);
        }
        $tbaccount = \Ku\FieldVerify::filter_value($post, 'account');
        if ($tbData = \Mapper\TbuserModel::getInstance()->fetchArray(['imie' => \Base\ApiController::$imie])) {//暂时不作操作
        } else {
            $insert = ['nick' => $tbnick, 'account' => $tbaccount, 'imie' => \Base\ApiController::$imie];
            \Mapper\TbuserModel::getInstance()->insertWithArray($insert);
        }
        return $this->returnData('成功', 0, true);
    }

    /**
     * 支付宝账单收集
     */
    public function alipayBillAction()
    {
        $post = $this->getPrivateRequest();
        $order_sn = \Ku\FieldVerify::filter_value($post, 'order_sn');
        $amount = \Ku\FieldVerify::filter_value($post, 'amount');
        $trade_to = \Ku\FieldVerify::filter_value($post, 'trade_to');//交易对象
        $detail = \Ku\FieldVerify::filter_value($post, 'detail');//明细json
        $pay_time=\Ku\FieldVerify::filter_value($post, 'pay_time');//明细json
        if (!$order_sn) {
            return $this->returnData('订单编号参数缺失', 1001, false, null);
        }
        if (!$trade_to) {
            return $this->returnData('交易对象参数缺失', 1002, false, null);
        }
        $pay_time=strtotime($pay_time);
        if(!$pay_time){
            return $this->returnData('交易时间参数缺失', 1003, false, null);
        }
        $insert = [];
        $insert['imie'] = \Base\ApiController::$imie;
        $insert['order_sn'] = $order_sn;
        $insert['trade_to'] = $trade_to;
        $insert['detail'] = $detail;
        $amount_type = 1;//金额类型
        switch (true) {
            case strpos($amount, '+')!==false:
                $amount_type = 1;
                break;
            case strpos($amount, '-')!==false:
                $amount_type = 2;
                break;
            default:
                $amount_type = 3;
        }
        $amount=str_replace([',','，'],'',$amount);
        $amount = abs($amount);
        $insert['amount_type'] = $amount_type;
        $insert['amount'] = $amount;
        $pay_time=date('YmdHis',$pay_time);
        $insert['pay_time'] =$pay_time;
        \Mapper\DeviceAlipayBillModel::getInstance()->insertWithArray($insert);
        return $this->returnData('成功', 0, true);
    }
}
