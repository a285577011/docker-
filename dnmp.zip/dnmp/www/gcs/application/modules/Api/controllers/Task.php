<?php

class TaskController extends \Base\ApiController
{
    /**
     * 任务上报通知
     */
    public function taskNoticeAction()
    {
        $post = $this->getPrivateRequest();
        $task_device_log_id = $post['task_id'] ?? '';
        $status = $post['status'] ?? '';
        $remark = $post['remark'] ?? '';
        if (!$task_device_log_id) {
            return $this->returnData('task_id参数缺失', 1001, false, null);
        }
        if (!$status) {
            return $this->returnData('status参数缺失', 1002, false, null);
        }
        $data = \Mapper\TaskDeviceLogModel::getInstance()->fetchArray(['id' => $task_device_log_id]);
        if (!$data) {
            return $this->returnData('task_id对应的任务不存在', 1003, false, null);
        }
        \Mapper\TaskDeviceLogModel::getInstance()->updateWithArray(['status' => $status,'u_time'=>date('YmdHis')], ['id' => $task_device_log_id]);
        \Mapper\TaskAccessLogModel::getInstance()->insertWithArray(['device_id' => $data['device_id'], 'task_device_log_id' => $task_device_log_id, 'status' => $status, 'remark' => $remark, 'c_time' => date('YmdHis')]);
        return $this->returnData('成功', 0,true);
    }
}
