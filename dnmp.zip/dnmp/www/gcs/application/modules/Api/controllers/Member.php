<?php

class MemberController extends \Base\MemberController {

    protected function before() {
        
        $request = $this->getRequest();
        $action = $request->getActionName();
        //本套系统需要的功能
        if (!in_array($action, ['reg', 'login', 'logout', 'getmemberinfo', 'changepassword', 'findpassword'])) {
            throw new \Ku\Exception("不存在的操作");
        }
        
        //不需要用户登陆的操作
        if (!in_array($action, ['reg', 'login', 'getmemberinfo', 'findpassword'])) {
            parent::before();
        }
        
    }

    public function indexAction() {
        //用户主页
        exit;
    }

    public function regAction() {
        $callback = \Ku\Tool::filter($this->getParam('callback', null));
        
        $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
        $mid = $memberBs->getMid();
        if ($mid > 0) {
            return $this->returnData('已登陆', 0, true, array());
        }
        
        //提交的参数
        $request = $this->getRequest();
        $user = \Ku\Tool::filter($request->getPost('user'));
        $password = \Ku\Tool::filter($request->getPost('password'));
        $code = $request->getPost('code');
        $data = array();

        //单位时间内注册次数限制
        if ($this->useLimit('limit.member.reg.' . \Ku\Tool::getClientIp(true, true), 5, 1200) === true) {
            return $this->returnData('操作太频繁了, 请休息下吧', 0, false, $data, $callback);
        }

        //注册用户
        $result = $memberBs->reg($user, $password, $code, array('mobile'));
        if ($result === false) {
            return $this->returnData($memberBs->getResultMsg(), 0, false, $memberBs->getResultData(), $callback);
        }

        return $this->returnData('帐号注册成功', 0, true, $memberBs->getResultData(), $callback);
    }

    public function loginAction() {
        $callback = \Ku\Tool::filter($this->getParam('callback', null));
        
        $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
        $mid = $memberBs->getMid();
        if ($mid > 0) {
            return $this->returnData('已登陆', 0, true, array(), $callback);
        }
        
        $request = $this->getRequest();
        $captcha = $request->getPost('captcha');
        $captchaBs = \Business\CaptchaModel::getInstance();
        if ($captchaBs->isCaptcha('login') === true && $captchaBs->checkCaptcha($captcha, 'login') === false) {
            $captchaBs->incrCaptcha('login');
            return $this->returnData($captchaBs->getResultMsg(), $captchaBs->getResultCode(), false, array(
                        'using_captcha' => true
                            ), $callback);
        }

        if ($this->useLimit('limit.member.login.' . \Ku\Tool::getClientIp(true), 20, 600) === true) {
            return $this->returnData('登录操作太频繁了, 请休息下吧', 23101, false, array(
                        'using_captcha' => $captchaBs->isCaptcha('login')
                            ), $callback);
        }

        $user = $request->getPost('user', '');
        $password = $request->getPost('password', '');
        $remember = $request->getPost('isremember', true);
        $result = $memberBs->login($user, $password, $remember, null, array('mobile'));
        if ($result === false) {
            $captchaBs->incrCaptcha('login');
            return $this->returnData($memberBs->getResultMsg(), $memberBs->getResultCode(), $result, $data = array(
                        'using_captcha' => $captchaBs->isCaptcha('login')
                            ), $callback);
        }

        return $this->returnData($memberBs->getResultMsg(), $memberBs->getResultCode(), $result, $memberBs->getResultData(), $callback);
    }

    public function logoutAction() {
        $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
        $mid = $memberBs->getMid();
        if ($mid < 1) {
            return $this->returnData('账号并未登陆', 0, true, array());
        }
        $result = $memberBs->logout();
        return $this->returnData('账号退出' . ($result ? '成功' : '失败'), 0, $result, $memberBs->getResultData());
    }

    /**
     * 找回密码
     * @return type
     */
    public function findPasswordAction() {
        $request = $this->getRequest();
        if ($request->isPost() === true) {
            if ($this->useLimit('limit.member.resetpasswd.' . \Ku\Tool::getClientIp(true), 6, 1800) === true) {
                return $this->returnData('操作太频繁了，休息下吧', 0, false, array());
            }

            $user = $request->getPost('user', '');
            $password = $request->getPost('password', '');
            $code = $request->getPost('code', null);

            $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
            $result = $memberBs->findPassword($user, $password, $code);
            if ($result === false) {
                return $this->returnData($memberBs->getResultMsg(), 0, false);
            }
            return $this->returnData('密码已被重置，请使用新密码登录，', 0, true, $memberBs->getResultData());
        }
        return $this->returnData('操作失败，请重试', 0, false);
    }

    public function changePasswordAction() {
        $request = $this->getRequest();
        if ($request->isPost() === true) {
            if ($this->useLimit('limit.member.changepasswd.' . \Ku\Tool::getClientIp(true), 6, 1800) === true) {
                return $this->returnData('操作太频繁了，休息下吧', 0, false);
            }

            $oldpassword = $request->getPost('oldpassword', '');
            $password = $request->getPost('password', '');

            $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
            $result = $memberBs->checkPassword($oldpassword);
            if ($result === false) {
                return $this->returnData($memberBs->getResultMsg(), 0, false);
            }

            $result = $memberBs->changePassword($password);
            if ($result === false) {
                return $this->returnData($memberBs->getResultMsg(), 0, false);
            }
            $returnData = $memberBs->getResultData();
            $memberBs->logout();
            return $this->returnData('密码修改成功', 0, true, $returnData);
        }
        return $this->returnData('操作失败，请重试', 0, false);
    }

    public function getMemberInfoAction() {
        $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
        $memberInfo = $memberBs->getMemberInfo();
        return $this->returnData('用户信息', 0, is_array($memberInfo) ? true : false, $memberInfo);
    }

    public function changeInfoAction() {
        $request = $this->getRequest();
        $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
        $mid = $memberBs->getMid(0);
        if ($mid < 1) {
            return $this->returnData('登陆超时，请重新登陆');
        }

        if ($request->isPost() === true) {
            //检查字段
            $field = $this->getPost('field', null);
            $value = $this->getPost('value', null);
            $fields = array('nickname', 'avatar', 'mobile', 'email');
            $memberMdl = $memberBs->getMember();
            if(!$memberMdl instanceof \MemberModel){
                return $this->returnData('登陆超时，请重新登陆');
            }
            if (!$field || !in_array($field, $fields) || !method_exists($memberMdl, 'set' . ucfirst(strtolower($field))) || !$value) {
                return $this->returnData('不允许操作的内容');
            }
            //检查限制
            if ($this->useLimit('limit.member.changeuserinfo.' . $mid, 6, 1800) === true) {
                return $this->returnData('操作太频繁了，休息下吧');
            }

            //修改字段前处理
            switch ($field) {
                case 'avatar'://上传头像
                    $upload = new \Ku\Upload();
                    $uploaded = $upload->setFormName($value)->exec(array($this, 'saveImage'), $mid);
                    if ($uploaded === false) {
                        return $this->returnData('用户头像上传失败', 0, false, $upload->getErrval());
                    }
                    $pic = $upload->getRetval();
                    $value = $pic['source'];
                    break;
                case 'mobile':
                    $code = $this->getPost('code', null);
                    if (\Ku\Verify::isMobile($value) === false) {
                        return $this->returnData('手机号不正确');
                    }

                    if (\Ku\Sender\Compare::sms($value, 'changemobile', $code) === false) {
                        return $this->returnData('手机已注册过或者验证码错误');
                    }
                    break;
                case 'email':
                    $code = $this->getPost('code', null);
                    if (\Ku\Verify::isEmail($value) === false) {
                        return $this->returnData('手机号不正确');
                    }

                    if (\Ku\Sender\Compare::sms($value, 'changeemail', $code) === false) {
                        return $this->returnData('邮箱已注册过或者验证码错误');
                    }
                    break;
                default:
                    break;
            }
            //修改字段
            call_user_func(array($memberMdl, 'set' . ucfirst(strtolower($field))), $value);
            $memberMp = \Mapper\MemberModel::getInstance();
            $effer = $memberMp->updateProfile($memberMdl);
            //修改字段后处理
            if ($effer === true) {
                $result = '';
                //头像提供
                if ($field == 'avatar') {
                    $value = $this->getHttpUri($model->getAvatar());
                }

                switch ($field) {
                    case 'mobile':
                    case 'email':
                        $memberBs->logout();
                        break;
                    default:
                        break;
                }
                return $this->returnData('修改成功', 0, true, array(
                    'value' => $value,
                ));
            }
        }
        return $this->returnData('操作失败，请重试', 0);
    }

    /**
     * 上传原图回调处理
     *
     * @param \Ku\Upload $upload
     * @return boolean
     * @todo 目前写 tmp 目录, 方便upload操作
     */
    public function saveImage(\Ku\Upload $upload, $param) {
        $fileext = 'jpg';
        $mid = $param;
        $newPath = '/uploads/avatar/';
        $path = $upload->path($newPath);
        if ($path === false) {
            return false;
        }

        $thumb = new \Ku\Thumb\Thumb($upload->getFiletmpName());
        $dst = $thumb->dst();
        $dst->setExt($fileext)->setFilename($mid);
        $dst->setPath($path);
        $dst->setWidth(270)->setHeight(270);
        $uploaded = $thumb->resized();

        if ($uploaded === true) {
            $upload->setRetval('source', $newPath . $dst->getFullFilename());
            return true;
        }

        $upload->setErrval(26105, '图像上传失败');
        return false;
    }

}
