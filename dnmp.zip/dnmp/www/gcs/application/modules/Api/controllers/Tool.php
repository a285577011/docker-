<?php

use Es\EsModel;

class ToolController extends \Base\AbstractController
{

    /**
     * 自动开启视图引擎及布局模块
     *
     * @var boolean
     */
    protected $autoRender = false;
    protected $autoLayout = false;

    public function indexAction()
    {

    }

    public function esIndexAction()
    {
        $es = new EsModel('apm-a', '_doc');
        $s = $es->getEs()->createIndex([
            'settings' => $this->makeSetting(),
            'mappings' => $this->makeMapping()
        ]);
        var_dump($s);
    }
    private function makeSetting()
    {
        $settings = [
            "number_of_shards" => 1,
            "number_of_replicas" => 1,
            "max_ngram_diff"=>5,
            "analysis" => [
                "analyzer" => [
                    'autocomplete' => [
                        'tokenizer' => "ngram_tokenizer",
                        'filter' => [
                            'lowercase'
                        ]
                    ]
                ],
                'tokenizer' => [
                    'ngram_tokenizer' => [
                        "type" => "ngram",
                        "min_gram" => 1,
                        "max_gram" => 4,
                        "token_chars" => [
                            "letter",
                            "digit"
                        ]
                    ]
                ]
            ],
        ];
        return $settings;
    }

    private function makeMapping(){
        $mapping=[
            "properties" => [
                "detail" => [
                    "type" => "text",
                    "analyzer" => "autocomplete"
                ],
            ]
        ];
        return $mapping;
    }
    /**
     * 检查是否需要验证码
     */
    public function preCaptchaAction() {
        $channel = $this->getRequest()->get('channel', '');
        $callback = \Ku\Tool::filter($this->getRequest()->get('callback', null));

        $captchaBs = \Business\CaptchaModel::getInstance();
        $result = $captchaBs->isCaptcha($channel);

        $this->returnData($result == false ? '不需要显示图形验证码' : '需要显示图形验证码', 0, $result, array('using_captcha' => $result), $callback);
    }

    /**
     * 展示验证码图片，一个验证码可有用十次 \base\AbstractController::checkCaptcha
     */
    public function captchaAction() {
        $channel = $this->getParam('channel', '');
        $clientIp = \Ku\Tool::getClientIp(true, true);

        //一分钟超过十次直接显示空白
        if ($this->useLimit('limit.tool.captcha.' . $clientIp, 10, 60) === true) {
            return false;
        }

        $captchaBs = \Business\CaptchaModel::getInstance();
        $captchaBs->captcha($channel);
        return false;
    }

    /**
     * 短信验证码
     */
    public function smsAction() {
        $request = $this->getRequest();
        $channel = $this->getParam('channel');
        $mobile = $this->getParam('mobile');
        // $callback = $this->getParam('callback', null);
        $callback='';
        $captcha = $this->getParam('captcha', '');

        //检测验证码
        $captchaBs = \Business\CaptchaModel::getInstance();
        if ($captchaBs->isCaptcha('sms', 0)) {
            if(!$captchaBs->checkCaptcha($captcha, 'sms')){
                return $this->returnData('验证码不正确', $captchaBs->getResultCode(), false, $captchaBs->getResultData(), $callback);
            }
        }

        if (true) {//$request->isPost() === true || !empty($callback)
            //手机号码或发送频道错误
            if (empty($mobile) || empty($channel) || \Ku\Verify::isMobile($mobile) === false ) {
                return $this->returnData('手机号码或发送频道错误' . $channel, 30100, false, null, $callback);
            }

            //存在渠道
            $funcName = ucfirst(strtolower($channel));
            $presms = \Business\SenderModel::getInstance();
            if (method_exists($presms, $funcName)) {
                //验证渠道
                $pass = call_user_func_array(array($presms, $funcName), array($mobile));

                //各个渠道短信一分钟最多一条
                if ($this->useLimit('limit.tool.sms.' . $channel . '.' . $mobile, 1, 60) === true) {
                    return $this->returnData('短信验证码刷新太快了, 休息下吧', 21101, false, null, $callback);
                }

                //各个渠道短信八个小时最多发6条短信
                if ($this->useLimit('limit.tool.sms.' . $channel . '.' . \Ku\Tool::getClientIp(true, true), 6, 1200) === true) {
                    return $this->returnData('短信发送频繁, 休息下吧', 21102, false, null, $callback);
                }

                //发送短信
                if ($pass === true && $this->sms($mobile, $channel) === true) {
                    return $this->returnData('短信验证码已发送', 20200, true, null, $callback);
                }

                $errval = $presms->getMessage();
                if (!empty($errval)) {
                    return $this->returnData($errval['msg'], $errval['code'], $errval['status'], null, $callback);
                }
            }
        }

        return $this->returnData('短信验证码发送失败, 请稍候重试', 21103, false, null, $callback);
    }

    /**
     * 检查邮箱是否已存在
     *
     * @return boolean
     */
    public function preEmailAction() {
        $email = $this->getRequest()->get('email', null);

        if (empty($email) || \Ku\Verify::isEmail($email) === false) {
            return $this->returnData('请输入正确的密保邮箱', 31100);
        }

        $ip = \Ku\Tool::getClientIp(true, true);
        if ($this->useLimit(sprintf(\Ku\Consts::EMAIL_IKEY, $ip), 6, 1800) === true) {
            return $this->returnData('通信错误', 22100);
        }

        return $this->returnData('密保邮箱已被其他会员占用', 31103, $this->checkEmail($email));
    }

    protected function checkEmail($email) {
        $memberModel = \Mapper\MemberModel::getInstance()->findByEmail($email);

        return ($memberModel instanceof \MemberModel ? true : false);
    }

    /**
     * 检查用户手机用户是否已存在
     * @return boolean
     */
    public function preMobileAction() {
        $mobile = $this->getRequest()->get('mobile', null);
        // $callback = $this->getRequest()->get('callback', null);
        $callback ='';
        if (empty($mobile) || \Ku\Verify::isMobile($mobile) === false) {
            return $this->returnData('手机格式有误', 31100, false, null, $callback);
        }

        $ip = \Ku\Tool::getClientIp(true, true);
        if ($this->useLimit(sprintf(\Ku\Consts::MOBILE_IKEY, $ip), 10, 1800) === true) {
            $this->returnData('操作太频繁了，请稍候重试', 31101, false, null, $callback);
            return false;
        }

        return $this->returnData('手机号已经被注册', 31104, $this->checkMobile($mobile), null, $callback);
    }

    protected function checkMobile($mobile) {
        $memberModel = \Mapper\MemberModel::getInstance()->findByMobile($mobile);

        return ($memberModel instanceof \MemberModel ? true : false);
    }

    /**
     * 检查用户手机用户是否已存在
     * @return boolean
     */
    public function preUsernameAction() {
        $username = $this->getRequest()->get('username', null);
        // $callback = $this->getRequest()->get('callback', null);
        $callback = '';
        if (empty($username) || \Ku\Verify::isUsername($mobile) === false) {
            return $this->returnData('用户名格式有误', 31100, false, null, $callback);
        }

        $ip = \Ku\Tool::getClientIp(true, true);
        if ($this->useLimit(sprintf(\Ku\Consts::USERNAME_IKEY, $ip), 10, 1800) === true) {
            $this->returnData('操作太频繁了，请稍候重试', 31101, false, null, $callback);
            return false;
        }

        return $this->returnData('手机号已经被注册', 31104, $this->checkUsername($username), null, $callback);
    }

    protected function checkUsername($username) {
        $memberModel = \Mapper\MemberModel::getInstance()->findByUsername($username);

        return ($memberModel instanceof \MemberModel ? true : false);
    }
}
