<?php

use Mapper\DevicePortModel;

/**设备接口
 * Class DeviceController
 */
class DeviceController extends \Base\ApiController
{

    public function addDeviceAction()
    {
        $post = $this->getPrivateRequest();
        $post['type']=$post['type']??'';
        $port=\Ku\FieldVerify::filter_value($post,'port');
        if(!$port){
            return $this->returnData('port参数缺失', 1001, false, null);
        }
        if(!$server=\Ku\FieldVerify::filter_ip($post,'server_ip')){
            return $this->returnData('server_ip参数缺失', 1002, false, null);
        }
        switch ($post['type']){
            case 1://连接frps成功后回调
                break;
            default://连接frps成功后回调
                \Business\DeviceModel::getInstance()->connCallback($port,$server);
                break;

        }
        return $this->returnData('成功', 0, true);
    }

    /**
     * 初始化设备推送ID
     */
    public function initRegIdAction(){
        $post = $this->getPrivateRequest();
        $post['regId']=$post['regId']??'';
        if(!$post['regId']){
            return $this->returnData('regId参数缺失', 1001, false);
        }
        $imie=\Base\ApiController::$imie;
        $deviceData=\Mapper\DeviceModel::getInstance()->fetchArray(['imie'=>$imie]);
        $ip= \Ku\Tool::getClientIp(false, true);
        if(!$deviceData){
            $insert = [];
            $insert['name'] = $imie;
            $insert['imie'] = $imie;
            $insert['reg_id'] = $post['regId'];
            $insert['ip'] = $ip;
            $deviceId=\Mapper\DeviceModel::getInstance()->insertWithArray($insert);
        }else{//后台先创建 更新
            $update['reg_id'] = $post['regId'];
            $update['ip'] = $ip;
            \Mapper\DeviceModel::getInstance()->updateWithArray($update,['id'=>$deviceData['id']]);
           // $deviceId=$deviceData['id'];
        }
        return $this->returnData('成功', 0, true);
    }
    /**
     * 短信/alert通知记录
     */
    public function addMsgAction(){
        $post = $this->getPrivateRequest();
        $post['type']=$post['type']??1;
        if(!$post['type']){
            return $this->returnData('type参数缺失', 1001, false);
        }
        $post['content']=$post['content']??'';
        if(!$post['content']){
            return $this->returnData('content参数缺失', 1001, false);
        }
        $insert=['type'=>$post['type'],'content'=>$post['content'],'imie'=>\Base\ApiController::$imie];
        $content=json_decode($post['content'],true);
        switch ($post['type']){
            case 1://1短信2alert通知
                $insert['title']=$content['title']??"";
                $insert['text']=$content['text']??"";
                $insert['msg_time']=date('YmdHis',strtotime($content['times']));
                break;
            case 2:
                $insert['title']=$content['title']??"";
                $insert['text']=$content['text']??"";
                $insert['msg_time']=date('YmdHis',strtotime($content['times']));
                $insert['app_name']=$content['appName']??"";
                break;
        }
        \Mapper\DeviceMsgLogModel::getInstance()->insertWithArray($insert);
        return $this->returnData('成功', 0, true);
    }

}
