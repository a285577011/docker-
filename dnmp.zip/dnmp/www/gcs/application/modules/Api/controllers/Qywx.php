<?php

/*
配置 applicition.ini

;企业微信应用，用于告警
resources.weixin.crop.id = ''
resources.weixin.crop.secret = ''
*/
class QywxController extends \Base\AbstractController {

    protected $_http = null;
    protected $_id = null;
    protected $_secret = null;
    protected $_auth = null;

    public function init(){
        parent::init();
        //配置
        $config = $this->getConfig();
        $crop = $config->get('resources.weixin.crop');
        if(!isset($crop['id']) || !isset($crop['secret']) || !isset($crop['auth'])){
            $this->returnData('系统无配置', 0, false);
            exit;
        }
        $this->setConfig($crop['id'], $crop['secret'], $crop['auth']);

        //授权token
        if(!$this->_auth()){
            $this->returnData('授权失败', 0, false);
            exit;
        }
    }

    public function setConfig($id, $secret, $auth){
        $this->_id = $id;
        $this->_secret = $secret;
        $this->_auth = $auth;
    }

    public function _auth(){
        $request = $this->getRequest();
        $auth = $request->get('auth', '');
        if($auth && $auth == $this->_auth){
            return true;
        }
        return false;
    }

    public function _token(){
        //获取ACCESS TOKEN
        $cacheId = $this->cacheId([__CLASS__, __METHOD__, $this->_id, $this->_secret]);
        $token = $this->getCache($cacheId);
        if(!$token){
            $url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid='.$this->_id.'&corpsecret='.$this->_secret;
            $tokenInfo = \json_decode($this->_send($url),  true);
            //var_dump($tokenInfo);exit;
            if(isset($tokenInfo['errcode']) && $tokenInfo['errcode']==0 && isset($tokenInfo['access_token'])){
                $token = $tokenInfo['access_token'];
                $this->setCache($cacheId, $token, 5400);
            }
        }
        return $token;
    }

    public function _send($url, $data = null){
        if(!$this->_http instanceof \Ku\Http){
            $this->_http = new \Ku\Http();
        }
        $this->_http->setUrl($url);
        if($data!==null){
            $this->_http->setPostFields($data);
        }
        return $this->_http->send();
    }

    public function _msg($msg, $to='@all'){
        $token = $this->_token();
        if(!$token){
            //var_dump($token);exit;
            return false;
        }
        //发送消息
        $data = \json_encode([
            'touser' => $to,//@all 或 XuFuSheng|LinDan
            //'toparty' => 1, // 1 或 1|2|3
            //'totag' => 'a', // a 或 a|b|c
            'msgtype' => 'text',
            'agentid' => 1000002,
            'text' => [
                'content' => $msg,
            ],
            'safe' => 0,
        ]);
        $url = 'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token='.$token;
        $result = $this->_send($url, $data);
        if(strpos($result, 'ok')){
            return true;
        }
        return false;
    }

    public function _party($pid=0){
        $token = $this->_token();
        if(!$token){
            return false;
        }
        $url = 'https://qyapi.weixin.qq.com/cgi-bin/department/list?id='.$pid.'&access_token='.$token;
        $result = \json_decode($this->_send($url), true);
        if(isset($result['errmsg']) && $result['errmsg']=='ok' && isset($result['department'])){
            return $result['department'];
        }
        return false;
    }

    public function _member($pid=1){
        $token = $this->_token();
        if(!$token){
            return false;
        }
        $url = 'https://qyapi.weixin.qq.com/cgi-bin/user/simplelist?department_id='.$pid.'&fetch_child=1&access_token='.$token;
        $result = \json_decode($this->_send($url), true);
        if(isset($result['errmsg']) && $result['errmsg']=='ok' && isset($result['userlist'])){
            return $result['userlist'];
        }
        return false;
    }

    // http://www.local.chajiechi.com/api/qywx/msg/?msg=消息测试&to=XuFuSheng&auth=xfs
    public function msgAction(){
        $request = $this->getRequest();
        $msg = $request->get('msg');
        if(!$msg || !is_string($msg)){
            return $this->returnData('消息不能为空', 1, false, $msg);
        }

        $to = $request->get('to', '@all');
        
        if($this->_msg($msg, $to)){
            return $this->returnData('sucess', 0, true);
        }
        return $this->returnData('fail', 0, false);
    }

    // http://www.local.chajiechi.com/api/qywx/party/?auth=xfs
    public function partyAction(){
        $request = $this->getRequest();
        $pid = $request->get('pid', 1);

        $result = $this->_party($pid);
        if($result){
            return $this->returnData('sucess', 0, true, $result);
        }
        return $this->returnData('fail', 0, false);
    }

    // http://www.local.chajiechi.com/api/qywx/member/?auth=xfs
    public function memberAction(){
        $request = $this->getRequest();
        $pid = $request->get('pid', 1);

        $result = $this->_member($pid);
        if($result){
            return $this->returnData('sucess', 0, true, $result);
        }
        return $this->returnData('fail', 0, false);
    }
}
