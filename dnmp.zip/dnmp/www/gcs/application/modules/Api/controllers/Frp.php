<?php

class FrpController extends \Base\ApiController {
    const FRP_URL="http://192.168.66.155:7500";

    public function getPortAction() {
        //通过imie号判断连接状态
        $imie=\Base\ApiController::$imie;
        $device=\Mapper\DeviceModel::getInstance()->fetchArray(['imie'=>$imie]);
        if($device){
            $devicePort=\Mapper\DevicePortModel::getInstance()->fetchArray(['device_id'=>$device['id'],'status'=>2]);
            if($devicePort){
                return $this->returnData('设备已连接', 2001, false, null);
            }
        }

        $uri="/api/getfreeports/";
        //提交的参数
        $url=self::FRP_URL.$uri;
        $http=new \Ku\Http();
        $http->setUrl($url);
        $data = $http->send();
        $data=json_decode($data,true);
        if($data['code']!=0){
            return $this->returnData('服务器错误', 1001, false, null);
        }
        $ports=array_keys($data['data']);
        if(!$ports){
            return $this->returnData('无可用端口', 1002, false, null);
        }
        foreach ($ports as $k=>$v){
            if($v<=10000){
                unset($ports[$k]);
            }
        }
        $randKeys =array_rand($ports,1);
        $port=$ports[$randKeys];
        $redis=new \Redis\RedisModel();
        $try=0;
        while (!$redis->getRedis()->set('frp-port::used-'.$port, $port, ['nx', 'ex' => 2])&&$try<5){//尝试5次
            unset($ports[array_search($port,$ports)]);
            $randKeys =array_rand($ports,1);
            $port=$ports[$randKeys];
            $try++;
        }
       if(!$redis->getRedis()->get('frp-port::used-'.$port)){
           return $this->returnData('端口获取失败，请重试', 1002, false, null);
       }
        return $this->returnData('', 0, true, ['port'=>['p'=>$port]]);
    }

    /**
     * 操作端口 frps调用
     */
    public function doPortAction(){
        $post=$this->getRequest()->getPost();
       $ip= \Ku\Tool::getClientIp(false, true);
        switch ($post['type']){
            case 1://新增连接
                \Business\FrpModel::connPort($post['port'],$ip);
                break;
            case 2://删除连接
                \Business\FrpModel::delPort($post['port'],$ip);
                break;
            default:
                return $this->returnData('类型错误', 1001);
                break;

        }
        return $this->returnData('成功', 0, true);
    }
}
