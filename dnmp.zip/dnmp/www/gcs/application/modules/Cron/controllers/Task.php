<?php

use Ku\Aes;

class TaskController extends \Base\AbstractController
{

    /**
     * 自动任务 每分钟跑一次
     */
    public function autoTaskAction()
    {
        //获取可用设备
        $redis = new \Redis\RedisModel();
        $key = 'task_lock::autoTask';
        if ($redis->getRedis(1)->get($key)) {
            \Ku\Logger::write('autoTask', 'has already do...');
          //  echo 'success';
          //  exit;
        }
        try {
            $redis->getRedis(1)->set($key, 1);//锁
            $onlineDevice = \Mapper\DeviceModel::getInstance()->fetchAllArray("reg_id!=''",'task_time asc');
            $complete = [];
            if (!$onlineDevice) {//无可用设备
                throw new \Exception('no onlineDevice complete', 1001);
            }
            shuffle($onlineDevice);//打乱随机
            $now = date('YmdHis');
            $where = " status=1 and s_time<{$now} and e_time>{$now} and auto=1";
            $onlineTask = \Mapper\TaskModel::getInstance()->fetchAllArray($where, 'sort desc');
            if ($onlineTask) {
                foreach ($onlineTask as $k => $v) {
                    if ($v['num'] == 0) {
                        unset($onlineTask[$k]);
                    }
                }
            }

            if (!$onlineTask) {//无可用设备
                throw new \Exception('no onlineTask complete', 1002);
            }
            $onlineTask = array_column($onlineTask, null, 'id');
            $dm = new \Mapper\DeviceModel();
            require APPLICATION_PATH . '/application/library/Ku/jpush/autoload.php';
            $client = new \JPush\Client(\Mapper\TaskModel::JP_APPKEY, \Mapper\TaskModel::JP_APPSECRET);
            foreach ($onlineDevice as $v) {
               /* $device = $dm->fetchArray(['id' => $v['device_id']]);
                if (!$device) {
                    \Ku\Logger::write('autoTask', 'no found device:' . var_export($v, true));
                }
               */
                //判断符不符合
                foreach ($onlineTask as $kc=>$vc) {
                    $tdl = \Mapper\TaskDeviceLogModel::getInstance()->fetchArray(['task_id' => $vc['id'], 'device_id' => $v['id']], 'c_time desc');//最新一条
                    if ($vc['limit_ip']&&$this->isLimitIp($v['ip'],$vc['limit_ip'])) {//限制IP
                        \Ku\Logger::write('autoTask', "limit_ip device:" . var_export($tdl, true));
                        continue;
                    }
                    if($vc['num']==0){
                        \Ku\Logger::write('autoTask', 'num 0,taskId:' . var_export($vc['id'], true));
                        unset($onlineTask[$k]);
                        continue;
                    }
                    if ($vc['time_limit'] == 0) {//设备不可重复做
                        if ($tdl && $tdl->status != 9) {//正在进行或者完成该任务
                            \Ku\Logger::write('autoTask', 'time_limit 0 arlead do deviceid-taskId:' . var_export([$v['id'],$vc['id']], true));
                            continue;
                        }
                    } else {
                        $now = time();
                        if ($tdl && $tdl['status'] != 9) {
                            $ctime = strtotime($tdl['c_time']);
                            $limitTime = $vc['time_limit'] * 3600;
                            if ($now - $ctime < $limitTime) {//还在限制时间内
                                \Ku\Logger::write('autoTask', "time_limit {$limitTime} arlead do deviceid-taskId:" . var_export([$v['id'],$vc['id']], true));
                                continue;
                            }

                        }
                    }
                    $insertLog = ['task_id' => $vc['id'], 'device_id' => $v['id'], 'status' => 0, 'c_time' => date('YmdHis')];
                    $tdlId = \Mapper\TaskDeviceLogModel::getInstance()->insertWithArray($insertLog);
                    $pushJson=[];
                    $params=json_decode($vc['params_json'],true);
                    if($params) {
                        $pushJson['taskType']=$vc['key'];
                        foreach ($params as $k => $vcc) {
                            if($vcc['val']) {
                                $pushJson[$vcc['key']] = $vcc['val'];
                            }
                        }
                    }
                    $pushJson['taskId'] = $tdlId;
                    $push_payload = $client->push()
                        ->setPlatform('all')
                        ->addRegistrationId($v['reg_id'])
                        ->options(['time_to_live' => 0])//不保留离线
                        ->message($vc['key'], array(
                            'title' => $vc['key'],
                            // 'content_type' => 'text',
                            'extras' => $pushJson));
                    try {
                        $response = $push_payload->send();
                    } catch (\JPush\Exceptions\APIConnectionException $e) {
                        // try something here
                        return $this->returnData($e->getMessage(), $e->getCode());
                    } catch (\JPush\Exceptions\APIRequestException $e) {
                        // try something here
                        return $this->returnData($e->getMessage(), $e->getCode());
                    }
                    \Mapper\TaskDeviceLogModel::getInstance()->updateWithArray(['status'=>1],['id'=>$tdlId]);
                    if($onlineTask[$vc['id']]['num']!=-1) {//不限制
                        $onlineTask[$vc['id']]['num'] -= 1;//任务数量减少1
                        \Mapper\TaskModel::getInstance()->updateWithArray(['num'=>new \Zend\Db\Sql\Expression('num-1')],['id'=>$vc['id']]);
                    }
                    array_push($complete,$tdlId);
                    \Mapper\DeviceModel::getInstance()->updateWithArray(['task_time'=>date('YmdHis'),'task_status'=>2],['id'=>$v['id']]);//更新时间下次执行权重更低
                }

            }
        } catch (\Exception $e) {
            $redis->getRedis(1)->del($key);//锁
            \Ku\Logger::write('autoTask', 'complete-msg:' . $e->getMessage());
            echo 'success';
            exit;
        }
        $redis->getRedis(1)->del($key);//锁
        \Ku\Logger::write('autoTask', 'complete-data:' . var_export($complete, true));
        echo 'success';
        exit;
    }
    private function isLimitIp($checkip,$limitIp){
        $limitIps = explode(',', $limitIp);
        foreach ($limitIps as $lp) {
            $pos = stripos($lp, 'x');
            $ip = $lp;
            if ($pos) {
                $ip = substr($lp,0, $pos - 1);
            }
            if (stripos($checkip, $ip) !== false) {//找到
                return true;
            }
        }
        return false;
    }
    /**
     * 定时取消任务(客户端异常，或者太久没上报结果)
     */
    public function cancleTaskAction(){
        $limitTime=3600;//1小时没结果就取消
        $now=time();
        $t=$now-$limitTime;
        $t=date('YmdHis',$t);
        $where=" status<9 and u_time<{$t}";
        $data=\Mapper\TaskDeviceLogModel::getInstance()->fetchAllArray($where);
        if($data){
            foreach ($data as $v){
                \Mapper\TaskDeviceLogModel::getInstance()->updateWithArray(['status'=>9],['id'=>$v['id']]);
                \Mapper\DeviceModel::getInstance()->updateWithArray(['task_status'=>1],['id'=>$v['device_id']]);//更新设备为空闲状态
            }
        }
        \Ku\Logger::write('cancleTask', 'complete-data:');
        echo 'success';
        exit;
    }
}
