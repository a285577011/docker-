<?php

use Mapper\AdminModel as AdminMapper;
use Ku\Captcha\Captcha;
use Ku\Verify;
use Ku\Tool;

/**
 * 登录
 */
class UserController extends \Base\AdminController {

    /**
     * 布局模板的名称
     * @var sting
     */
    protected $layout = '';

    protected $layoutFollowModule = false;

    public function init() {
        parent::init();
        $this->disableLayout();
    }

    /**
     * 首页
     */
    public function loginAction() {
        $myadmin = $this->getloginAdmin();
        if (!!$myadmin) {
            $this->redirect('/admin/', true);
        }
    }

    protected function doLoginAction() {
        $myadmin = $this->getloginAdmin();
        if (!!$myadmin) {
            return $this->returnData('已登陆', 0, true, array(
                'redirectUrl' => '/admin/'
            ));
        }

        $request = $this->getRequest();
        $captcha   = trim($request->getPost('captcha'));
        $email    = trim($request->getPost('email'));
        $password = trim($request->getPost('password'));
        $captchaBs = \Business\CaptchaModel::getInstance();
        if ($captchaBs->checkCaptcha($captcha, 'admin') === false) {
            $captchaBs->incrCaptcha('admin');
            return $this->returnData($captchaBs->getResultMsg(), $captchaBs->getResultCode(), false, array(
                'using_captcha' => true
            ));
        }
        
        if (!Verify::isEmail($email)) {
            return $this->returnData('email 格式不正确', 0, false, array(
                'using_captcha' => true
            ));
        }
        if (empty($password)) {
            return $this->returnData('密码不允许为空', 1, false, array(
                'using_captcha' => true
            ));
        }
        $adminMapper = AdminMapper::getInstance();
        $adminModel = $adminMapper->findByEmail($email);
        if(!($adminModel instanceof \AdminModel)){
            $captchaBs->incrCaptcha('admin');
            return $this->returnData('账号无效', 2, false, array(
                'using_captcha' => true
            ));
        }
        
        if (password_verify($password, $adminModel->getPassword()) === false) {
            $captchaBs->incrCaptcha('admin');
            return $this->returnData('密码不正确', 3, false, array(
                'using_captcha' => true
            ));
        }
        
        if ($adminModel->getDisabled()) {
            return $this->returnData('账号已被禁用, 请联系系统管理员', 4, false, array(
                'using_captcha' => true
            ));
        }
     

        if($this->setLoginAdmin($adminModel)){
            return $this->returnData('登陆成功', 0, true, array(
                'redirectUrl' => '/admin/'
            ));
        }

        return $this->returnData('登陆失败, 请联系系统管理员', 5, false, array(
            'using_captcha' => true
        ));
    }

    /**
     * 设置管理员为登录状态
     *
     * @param \AdminModel $adminModel
     * @return boolean
     */
    protected function setLoginAdmin(\AdminModel $adminModel) {
        if (1 > $adminModel->getId()) {
            return false;
        }
        $ip = Tool::getClientIp();
        $res=$this->getSession()->set('Admin', array('id' => $adminModel->getId(), 'ip' => $ip));
        $adminMapper = AdminMapper::getInstance();
        $adminMapper->upLoginInfo($adminModel);
        \Mapper\AdminlogModel::getInstance()->log('管理员ID：'.$this->getAdminId().'，后台登录', \Mapper\AdminlogModel::LOGIN);
        return true;
    }

    /**
     * 退出登录
     *
     * @todo 还没有写日志
     */
    public function logoutAction() {
        $this->getSession()->del('Admin');
        $this->redirect('/admin/user/login/', true);
    }
    

}
