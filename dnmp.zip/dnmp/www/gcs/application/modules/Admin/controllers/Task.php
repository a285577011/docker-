<?php

/**
 * 自动脚本任务管理
 */
class TaskController extends \Base\AdminController
{
    public function init()
    {
        $action=$this->getRequest()->getActionName();
        if(in_array($action,['do','devicelist','bind'])){//表单操作用iframe使用另外一个模板
            $this->layout='simpleadmin';
        }
        parent::init();
    }
	public function indexAction()
	{
        $dp = \Mapper\TaskModel::getInstance();
        $name = $this->getParam('name');
        $page = abs((int)$this->getRequest()->get('page', 1));
        $limit=10;
        $where=[];
        if($name){
            $where['name']=$name;
        }
        $offset=($page-1)*$limit;
        $data=$dp->fetchAllArray($where,null,$limit,$offset);
        if($data){
            $arr=['1'=>'全部设备',2=>'指定设备'];
            $auto=['1'=>'自动分配设备',2=>'手动分配设备'];
            $status=['1'=>'开启',2=>'关闭'];
            foreach ($data as $k=>$v){
                $data[$k]['typeCn']=$arr[$v['type']];
                $data[$k]['autoCn']=$auto[$v['auto']];
                $data[$k]['statusCn']=$status[$v['status']];
                $data[$k]['s_time']=$v['s_time']?date('Y-m-d H:i:s',strtotime($v['s_time'])):'';
                $data[$k]['e_time']=$v['s_time']?date('Y-m-d H:i:s',strtotime($v['e_time'])):'';
            }
        }
        $total = (int)$dp->count($where);
        $devices=[];
        $totalPage = ceil($total / $limit);
        $this->assign('datalist', json_encode($data));
        $this->assign('page', $page);
        $this->assign('total', $total);
        $this->assign('totalPage', $totalPage);
        $this->assign('pageData', $data);
	}

    /**
     * 添加自动脚本任务
     */
	public function doAction(){
        if ($this->getRequest()->isPost()) {
            $post=$this->getRequest()->getPost();
            $name=\Ku\FieldVerify::filter_value($post,'name');
            $key=\Ku\FieldVerify::filter_value($post,'key');
            $remark=\Ku\FieldVerify::filter_value($post,'remark');
            $type=\Ku\FieldVerify::filter_value($post,'type');
            $paramsJson=\Ku\FieldVerify::filter_value($post,'paramsJson');
            $id=\Ku\FieldVerify::filter_int($post,'id');
            $auto=\Ku\FieldVerify::filter_int($post,'auto');
            $time_limit=\Ku\FieldVerify::filter_int($post,'time_limit');
            $num=\Ku\FieldVerify::filter_int($post,'num');
            $limit_ip=\Ku\FieldVerify::filter_value($post,'limit_ip');
            $sort=\Ku\FieldVerify::filter_int($post,'sort');
            $status=\Ku\FieldVerify::filter_int($post,'status');
            $time_range=\Ku\FieldVerify::filter_value($post,'time_range');
            $startTime=$endTime=0;
            if($time_range){
                list($startTime,$endTime)=explode('-',$time_range);
                $startTime=date('YmdHis',strtotime($startTime));
                $endTime=date('YmdHis',strtotime($endTime));
            }
            /*if ($data = \Mapper\TaskModel::getInstance()->fetchArray(['key' => $key])) {
                if(!$id) {
                    return $this->returnData('任务key已经存在', 1001);
                }
            }*/
            $adminId=$this->getSession()->get('Admin')['id'];
            if($id){//修改
                //key不能修改涉及到绑定推送设备的
                $update = ['name' => $name,'remark'=>$remark,'params_json'=>$paramsJson,'type'=>$type,'admin_id'=>$adminId,'auto'=>$auto,'time_limit'=>$time_limit,'num'=>$num,'limit_ip'=>$limit_ip,'s_time'=>$startTime,'e_time'=>$endTime,'sort'=>$sort,'status'=>$status];
                \Mapper\TaskModel::getInstance()->updateWithArray($update,['id'=>$id]);
            }else {
                $insert =['name' => $name,'remark'=>$remark,'params_json'=>$paramsJson,'key'=>$key,'type'=>$type,'admin_id'=>$adminId,'auto'=>$auto,'time_limit'=>$time_limit,'num'=>$num,'limit_ip'=>$limit_ip,'s_time'=>$startTime,'e_time'=>$endTime,'sort'=>$sort,'status'=>$status];
                \Mapper\TaskModel::getInstance()->insertWithArray($insert);
            }

            return $this->returnData('添加成功',0);
        }else{
            $id=$this->getParam('id');
            $task=[];
            if($id){
                $task=\Mapper\TaskModel::getInstance()->fetchArray(['id'=>$id]);
                $task['time_range']=date('Y/m/d H:i:s',strtotime($task['s_time'])).'-'.date('Y/m/d H:i:s',strtotime($task['e_time']));
            }
            $paramsJson=[];
            if($task){
                $paramsJson=json_decode($task['params_json']);
            }
            if(!$task){
                $task['auto']=1;
                $task['time_limit']=24;
                $task['num']=-1;
                $task['num_day']=0;
                $task['status']=1;
            }
            $this->assign('paramsJson', (string)json_encode($paramsJson));
            $this->assign('pushType', (string)json_encode(['1'=>'全部设备',2=>'指定设备']));
            $this->assign('taskData', (string)json_encode($task));
        }
    }
    /**
     * 删除任务
     */
    public function delAction(){
        $post=$this->getRequest()->getPost();
        $id=\Ku\FieldVerify::filter_value($post,'id');
        if(!$id){
            return $this->returnData('id参数错误',1001);
        }
        if(\Mapper\DevicetaskModel::getInstance()->fetchArray(['task_id'=>$id])){
            return $this->returnData('存在绑定的设备,无法删除,请先解除绑定',1002);
        }
        \Mapper\TaskModel::getInstance()->del(['id'=>$id]);
        return $this->returnData('删除成功',0);
    }
    /**
     * 任务设备列表
     */
    public function deviceListAction(){
        $id=$this->getParam('id');
        $name = $this->getParam('name');
        $page = abs((int)$this->getRequest()->get('page', 1));
        $limit=10;
        $offset=($page-1)*$limit;
        $sql="SELECT device_task.id,task.name as task_name,device.name,device.imie,device_task.c_time FROM device_task LEFT JOIN task ON device_task.task_id=task.id LEFT JOIN device ON device_task.device_id=device.id ";
        $where=" WHERE task.id={$id}";
        if($name){
            $where.=" AND device.name={$name}";
        }
        $limitstr=" limit {$offset},{$limit}";
        $order=' order by device_task.id desc';
        $sql=$sql.$where.$order.$limitstr;

        $model=\Mapper\DevicePortModel::getInstance();
        $data=$model->queryForSql($sql);
        $sqlCount="SELECT count(1) as total FROM device_task LEFT JOIN task ON device_task.task_id=task.id LEFT JOIN device ON device_task.device_id=device.id";
        $sqlCount.=$where;
        $count=$model->queryForSql($sqlCount);
        $total=$count[0]['total'];
        $totalPage = ceil($total / $limit);
        $this->assign('queryData', json_encode($this->getRequest()->getQuery()));
        $this->assign('taskId', $id);
        $this->assign('datalist', json_encode($data));
        $this->assign('page', $page);
        $this->assign('total', $total);
        $this->assign('totalPage', $totalPage);
        $this->assign('pageData', $data);
    }
    /**
     * 解除任务设备绑定
     */
    public function unbindAction(){
        $id=$this->getParam('id');
        $dt=\Mapper\DevicetaskModel::getInstance()->fetchArray(['id'=>$id]);
        $taskData=\Mapper\TaskModel::getInstance()->fetchArray(['id'=>$dt['task_id']]);
        $deviceData=\Mapper\DeviceModel::getInstance()->fetchArray(['id'=>$dt['device_id']]);
        try {
            require APPLICATION_PATH.'/application/library/Ku/jpush/autoload.php';
            $client = new \JPush\Client(\Mapper\TaskModel::JP_APPKEY, \Mapper\TaskModel::JP_APPSECRET);
            $result = $client->device()->removeDevicesFromTag($taskData['key'], $deviceData['reg_id']);
        } catch (\JPush\Exceptions\APIConnectionException $e) {
            return $this->returnData($e->getMessage(),$e->getCode());
        } catch (\JPush\Exceptions\APIRequestException $e) {
            // try something here
            return $this->returnData($e->getMessage(),$e->getCode());
        }
        \Mapper\DevicetaskModel::getInstance()->del(['id'=>$id]);
        return $this->returnData('解除成功',0);
    }
    /**
     * 绑定设备
     */
    public function bindAction(){
        if ($this->getRequest()->isPost()) {
            require APPLICATION_PATH.'/application/library/ku/jpush/autoload.php';
            $client = new \JPush\Client(\Mapper\TaskModel::JP_APPKEY, \Mapper\TaskModel::JP_APPSECRET);
            $post=$this->getRequest()->getPost();
            $taskId=\Ku\FieldVerify::filter_value($post,'taskId');
            $deviceIds=\Ku\FieldVerify::filter_value($post,'deviceIds');
            if(!$deviceIds){
                return $this->returnData('无绑定的设备',1001);
            }

            $deviceIds=explode(',',$deviceIds);
            $taskData=\Mapper\TaskModel::getInstance()->fetchArray(['id'=>$taskId]);
            $tag=$taskData['key'];
            foreach ($deviceIds as $id){
                if(\Mapper\DevicetaskModel::getInstance()->fetchArray(['task_id'=>$taskId,'device_id'=>$id])){
                    continue;
                }
                $deviceData=\Mapper\DeviceModel::getInstance()->fetchArray(['id'=>$id]);
                if(!$deviceData['reg_id']){
                    continue;
                }
                try {
                    $result = $client->device()->addDevicesToTag($tag,$deviceData['reg_id']);
                } catch (\JPush\Exceptions\APIConnectionException $e) {
                    return $this->returnData($e->getMessage(),$e->getCode());
                } catch (\JPush\Exceptions\APIRequestException $e) {
                    // try something here
                    return $this->returnData($e->getMessage(),$e->getCode());
                }
                $insert=['task_id'=>$taskId,'device_id'=>$id];
                \Mapper\DevicetaskModel::getInstance()->insertWithArray($insert);
            }
            return $this->returnData('添加成功',0);
        }else{
            $model=\Mapper\DevicetaskModel::getInstance();
            $taskid=$this->getParam('id');
            $sql="SELECT device.id,device.name FROM device WHERE device.reg_id!=''";
            //$sql="SELECT device.id,device.name FROM device LEFT JOIN device_task ON device_task.device_id=device.id";
           // $where=" WHERE device.reg_id!='' AND device_task.id IS NULL OR ";
            //$sql.=$where;
            $dtData=\Mapper\DevicetaskModel::getInstance()->fetchAllArray(['task_id'=>$taskid]);
            $dtData=array_column($dtData,'device_id');
            $data=$model->queryForSql($sql);
            if($dtData) {
                foreach ($data as $k => $v) {
                    if (in_array($v['id'], $dtData)) {
                        unset($data[$k]);
                    }
                }
            }
            $data=array_values($data);
            $this->assign('dataList', (string)json_encode($data));
            $this->assign('taskId', $taskid);
        }
    }
    /**
     * 执行任务
     */
    public function dotaskAction(){
        $post=$this->getRequest()->getPost();
        $taskId=\Ku\FieldVerify::filter_value($post,'taskId');
        $taskData=\Mapper\TaskModel::getInstance()->fetchArray(['id'=>$taskId]);
        require APPLICATION_PATH.'/application/library/ku/jpush/autoload.php';
        $client = new \JPush\Client(\Mapper\TaskModel::JP_APPKEY, \Mapper\TaskModel::JP_APPSECRET);
        $params=json_decode($taskData['params_json'],true);
        $pushJson=[];
        if($params) {
            $pushJson['taskType']=$taskData['key'];
            foreach ($params as $k => $v) {
                $pushJson[$v['key']] = $v['val'];
            }
        }
        if($taskData['status']!=1){
            return $this->returnData('脚本状态为关闭',1001);
        }
        switch ($taskData['type']){
            case 1://全局推送
                //$pushJson=json_encode($pushJson);
                $insertLog=['task_id'=>$taskId,'status'=>0,'c_timestamp'=>date('YmdHis')];
                $taskLogId=\Mapper\TaskLogModel::getInstance()->insertWithArray($insertLog);
                $pushJson['taskId']=$taskId;
                $push_payload = $client->push()
                    ->setPlatform('all')
                    ->addAllAudience()
                    ->message($taskData['key'], array(
                        'title' => $taskData['key'],
                        // 'content_type' => 'text',
                        'extras' =>$pushJson));
                try {
                    $response = $push_payload->send();
                } catch (\JPush\Exceptions\APIConnectionException $e) {
                    // try something here
                    return $this->returnData($e->getMessage(),$e->getCode());
                } catch (\JPush\Exceptions\APIRequestException $e) {
                    // try something here
                    return $this->returnData($e->getMessage(),$e->getCode());
                }
                break;
            case 2://分组
                if(!\Mapper\DevicetaskModel::getInstance()->fetchArray(['task_id'=>$taskId])){
                    return $this->returnData('未绑定任何设备',1003);
                }
                //$pushJson=json_encode($pushJson);
                $insertLog=['task_id'=>$taskId,'status'=>0,'c_timestamp'=>date('YmdHis')];
                $taskLogId=\Mapper\TaskLogModel::getInstance()->insertWithArray($insertLog);
                $pushJson['taskId']=$taskLogId;
                $push_payload = $client->push()
                    ->setPlatform('all')
                    ->addTag([$taskData['key']])
                    // ->addRegistrationId($registration_id)
                    ->message($taskData['key'], array(
                        'title' => $taskData['key'],
                        // 'content_type' => 'text',
                        'extras' =>$pushJson));
                try {
                    $response = $push_payload->send();
                } catch (\JPush\Exceptions\APIConnectionException $e) {
                    // try something here
                    return $this->returnData($e->getMessage(),$e->getCode());
                } catch (\JPush\Exceptions\APIRequestException $e) {
                    // try something here
                    return $this->returnData($e->getMessage(),$e->getCode());
                }
                break;
        }
        \Mapper\TaskLogModel::getInstance()->updateWithArray(['status'=>1],['id'=>$taskLogId]);
        return $this->returnData('任务发送成功',0);
    }

    /**
     * 任务日志
     */
    public function taskLogAction(){
        $name = $this->getParam('name');
        $page = abs((int)$this->getRequest()->get('page', 1));
        $limit=10;
        $offset=($page-1)*$limit;
        $sql="SELECT task_log.id,task_log.status,task_log.c_time,task.name,task.key FROM task_log LEFT JOIN task ON task_log.task_id=task.id ";
        $where=" WHERE 1=1";
        if($name){
            $where.=" AND task.name LIKE '%{$name}%'";
        }
        $limitstr=" limit {$offset},{$limit}";
        $order=' order by task_log.id desc';
        $sql=$sql.$where.$order.$limitstr;
        $model=\Mapper\TaskLogModel::getInstance();
        $data=$model->queryForSql($sql);
        if($data){
            foreach ($data as $k=>$v){
                $data[$k]['statusCn']=\Mapper\TaskModel::TASK_STATUS[$v['key']][$v['status']]??'';
            }
        }
        $sqlCount="SELECT count(1) as total FROM task_log LEFT JOIN task ON task_log.task_id=task.id";
        $sqlCount.=$where;
        $count=$model->queryForSql($sqlCount);
        $total=$count[0]['total'];
        $totalPage = ceil($total / $limit);
        $this->assign('queryData', json_encode($this->getRequest()->getQuery()));
        $this->assign('datalist', json_encode($data));
        $this->assign('page', $page);
        $this->assign('total', $total);
        $this->assign('totalPage', $totalPage);
        $this->assign('pageData', $data);
        $this->assign('taskStatus', json_encode(\Mapper\TaskModel::TASK_STATUS));
    }
    public function socketAction(){

    }

}