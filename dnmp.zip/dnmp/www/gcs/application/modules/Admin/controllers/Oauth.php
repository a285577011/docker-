<?php
/**
 * Description of Oauth
 * 开放账户
 * @author Administrator
 */
class OauthController extends \Base\AdminController {

    public function indexAction() {

    }
}
