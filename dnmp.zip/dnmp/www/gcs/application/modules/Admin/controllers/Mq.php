<?php

/**
 * 查劫持队列管理
 */
class MqController extends \Base\AdminController
{
	protected $_redisPrefix = 'task:channel:';

	public function indexAction()
	{
		$taskBs = \Business\TaskModel::getInstance();

		$redis = $this->getRedis();
        $countryAreaKeys = $redis->keys($this->_redisPrefix.'*');
		
		$channels = [];
		/*
		foreach($taskBs->_areas as $country => $areas){
			foreach($areas as $area => $areaName){
				foreach($taskBs->_operators as $operator => $operatorName){
					$channels[$country][$area][$operator] = [];
				}
			}
		}
		*/

		//$tids = [];
        foreach($countryAreaKeys as $countryAreaKey){
			$country =  substr($countryAreaKey, -8, 2);
			$area = substr($countryAreaKey, -6);
			$countryAreaKey = substr($countryAreaKey, strpos($countryAreaKey, $this->_redisPrefix));

			$operatorTids = $redis->hgetall($countryAreaKey);
			foreach($operatorTids as $operatorTid=>$num){
				$operator = substr($operatorTid, 0, 2);
				$tid = substr($operatorTid, 2);
				$channels[$country][$area][$operator][$tid] = $num;
			}
			
		}
		//var_dump($channels);
		//exit;

		$this->assign('channels', $channels);
		$this->assign('_areas', $taskBs->_areas);
		$this->assign('_operators', $taskBs->_operators);
	}

	public function listAction()
	{
		$request = $this->getRequest();
		$condition = [];
		$condition['country'] = $request->get('country', 'cn');
		$condition['area'] = $request->get('area', '');
		$condition['id'] = $request->get('id', '');
		$condition['operator'] = $request->get('operator', '');

		$redis = $this->getRedis();
		$tidChannels = [];

		//根据任务id获取任务队列
		if($condition['id']>0){
			$taskMp = \Mapper\TaskModel::getInstance();
			$taskBs = \Business\TaskModel::getInstance();
			$taskMdl = $taskMp->fetch(['id'=>$condition['id']]);
			if(!$taskMdl instanceof \TaskModel){
				throw new Exception('任务不存在');
			}
			$task = $taskBs->parseTask($taskMdl);
			foreach($task['channel'] as $channel => $num){
				$countryArea= substr($channel, 0, 8);
				$countryAreaKey = $this->_redisPrefix.$countryArea;
				$operatorTids = $redis->hgetall($countryAreaKey);
				foreach($operatorTids as $operatorTid => $num){
					$operator = substr($operatorTid, 0, 2);
					$tid = substr($operatorTid, 2);
					if($condition['id'] == $tid){
						$tidChannels[$tid][$countryArea.$operator] = $num;
					}
				}
			}
		}elseif($condition['country'] && $condition['area']){//根据国家地区和运营商获取任务队列
			$countryArea = $condition['country'].$condition['area'];
			$countryAreaKey = $this->_redisPrefix.$countryArea;
			$operatorTids = $redis->hgetall($countryAreaKey);
			foreach($operatorTids as $operatorTid=>$num){
				$operator = substr($operatorTid, 0, 2);
				$tid = substr($operatorTid, 2);
				if($condition['operator']=='' || $condition['operator'] == $operator){
					$tidChannels[$tid][$countryArea.$operator] = $num;
				}
			}
		}else{
			$countryAreaKeys = $redis->keys($this->_redisPrefix.'*');
			foreach($countryAreaKeys as $countryAreaKey){
				$country =  substr($countryAreaKey, -8, 2);
				$area = substr($countryAreaKey, -6);
				$countryArea = $country.$area;
				$countryAreaKey = substr($countryAreaKey, strpos($countryAreaKey, $this->_redisPrefix));
				
				$operatorTids = $redis->hgetall($countryAreaKey);
				foreach($operatorTids as $operatorTid=>$num){
					$operator = substr($operatorTid, 0, 2);
					$tid = substr($operatorTid, 2);
					$tidChannels[$tid][$countryArea.$operator] = $num;
				}
			}
		}
		//var_dump($tidChannels);exit;

		$tasks = [];
		if(!empty($tidChannels)){
			$taskMp = \Mapper\TaskModel::getInstance();
			$tasksArr = $taskMp->fetchAllArray(['id'=>array_keys($tidChannels)]);
			
			foreach($tasksArr as $taskArr){
				$param = \json_decode($taskArr['param'], true);
				$tasks[$taskArr['id']] = $param['url'];
			}
			//var_dump($tasks);exit;
		}

		$taskBs = \Business\TaskModel::getInstance();

		$this->assign('tidChannels', $tidChannels);
		$this->assign('tasks', $tasks);
		$this->assign('condition', $condition);
		$this->assign('_areas', $taskBs->_areas);
		$this->assign('_operators', $taskBs->_operators);
	}

	public function delAction()
	{
		$request = $this->getRequest();
		$condition = [];
		$condition['country'] = $request->get('country', 'cn');
		$condition['area'] = $request->get('area', '');
		$condition['id'] = $request->get('id', '');
		$condition['operator'] = $request->get('operator', '');
		
		$redis = $this->getRedis();

		$flag = true;
		//根据任务id获取任务队列
		if($condition['country'] && $condition['area']){//根据国家地区和运营商获取任务队列
			$countryArea = $condition['country'].$condition['area'];
			$countryAreaKey = $this->_redisPrefix.$countryArea;
			$tidOperators = $redis->hgetall($countryAreaKey);
			foreach($tidOperators as $tidOperator=>$num){
				$operator = substr($tidOperator, 0, 2);
				$tid = substr($tidOperator, 2);
				if($condition['operator']!='' && $condition['id']!=''){
					if($tidOperator==$condition['operator'].$condition['id']){
						$flag = $redis->HDEL($countryAreaKey, $tidOperator);
					}
				}elseif($condition['operator']!=''){
					if($operator==$condition['operator']){
						$flag = $redis->HDEL($countryAreaKey, $tidOperator);
					}
				}elseif($condition['id']!=''){
					if($tid==$condition['id']){
						$flag = $redis->HDEL($countryAreaKey, $tidOperator);
					}
				}
				if($flag==false){
					$flag = false;
					break;
				}
			}
		}elseif($condition['id']>0){
			$taskMp = \Mapper\TaskModel::getInstance();
			$taskBs = \Business\TaskModel::getInstance();
			$taskMdl = $taskMp->fetch(['id'=>$condition['id']]);
			if(!$taskMdl instanceof \TaskModel){
				throw new Exception('任务不存在');
			}
			$task = $taskBs->parseTask($taskMdl);
			
			foreach($task['channel'] as $channel => $num){
				$countryArea= substr($channel, 0, 8);
				$operator = substr($channel, 8, 2);
				$countryAreaKey = $this->_redisPrefix.$countryArea;
				$operatorTid = $operator.$condition['id'];
				if(!$redis->HEXISTS($countryAreaKey, $operatorTid) || !$redis->HDEL($countryAreaKey, $operatorTid)){
					$flag = false;
					break;
				}
			}
		}else{
			if(isset($_GET['auth']) && $_GET['auth']=='xfs'){
				$countryAreaKeys = $redis->keys($this->_redisPrefix.'*');
				foreach($countryAreaKeys as $countryAreaKey){
					$countryAreaKey = substr($countryAreaKey, strpos($countryAreaKey, $this->_redisPrefix));
					if(!$redis->del($countryAreaKey)){
						$flag = false;
						break;
					}
				}
			}else{
				$flag=false;
			}

		}
		if($flag){
			return $this->returnData('删除成功', 0, true);
		}


		return $this->returnData('删除失败', 0, false);
	}

}