<?php

/**
 * 优惠码管理
 */
class CouponController extends \Base\AdminController {

    /**
     * 列表
     */
    public function indexAction() {
        $couponMp = \Mapper\CouponModel::getInstance();
        $memberMp = \Mapper\MemberModel::getInstance();
        $where = [];
        $condition = [];
        $limit = 30;
        //券码
        $code = \Ku\Tool::filter($this->getParam('code', ''));
        if ($code) {
            $where[] = "`code` like '%$code%'";
            $condition['code'] = $code;
        }
        //分类
        $types = \Business\MemberModel::$_couponTypes;
        $type = $this->getParam('type', '');
        if(isset($types[$type])){
            $where['type'] = $type;
            $condition['type'] = $type;
        }
        //var_dump($where);exit;

        $this->paginator($couponMp, $where, $limit, function($data, $total, $totalPage, $page)use($memberMp){
            return $data;
        }, 'addtime desc');
        $cates = \Business\MemberModel::$_payCates;
        $statuses = [0=>'有效', 1=>'无效'];

        $this->assign('condition', $condition);
        $this->assign('types', $types);
        $this->assign('cates', $cates);
        $this->assign('statuses', $statuses);
        $this->assign('redis', $this->getRedis());
    }

	public function editAction()
	{
		$request = $this->getRequest();
		$id = $request->get('id', 0);
		$couponMp = \Mapper\CouponModel::getInstance();
		$data = [];
		if ($id) {
			$data = $couponMp->fetchArray(['id' => $id]);
        }
        
        $types = \Business\MemberModel::$_couponTypes;
        $cates = \Business\MemberModel::$_payCates;
        unset($cates['unknow']);
        unset($cates['coupon']);
        $cates['no'] = '不限制';
        $statuses = [0=>'有效', 1=>'无效'];
        $this->assign('types', $types);
        $this->assign('cates', $cates);
        $this->assign('statuses', $statuses);

        $request = $this->getRequest();
		if ($request->isPost()) {
            $intro = $request->getPost('intro', '');
            $content = $request->getPost('content', 0);
            $max = $request->getPost('max', 1);
            $mid = $request->getPost('mid', 0);
            $total_fee = $request->getPost('total_fee', 0);
            $pay_from = $request->getPost('pay_from', '');
            if($pay_from=='no'){
                $pay_from = '';
            }
            $starttime = $request->getPost('starttime', 0);
            $endtime = $request->getPost('endtime', 0);
            $status = $request->getPost('status', 0);
            $time = time();
            $data = [
                'intro'=>$intro,
                'content'=>$content,
                'max'=>$max,
                'mid'=>$mid,
                'total_fee'=>$total_fee,
                'pay_from'=>$pay_from,
                'starttime'=>$starttime,
                'endtime'=>$endtime,
                'status'=>$status,
                'uptime'=>$time,
            ];
            if(!$id){
                $code = $request->getPost('code');
                if(!$code){
                    $code = rand(10000, 99999);
                }
                $type = $request->getPost('type', 1);
                $data['code'] = $code;
                $data['type'] = $type;
                $data['addtime'] = $time;
                try{
                    $result = $couponMp->_insert($data);
                }catch(\Exception $e){
                    var_dump($e);exit;
                }
                $id = $result;
            }else{
                try{
                    $result = $couponMp->_update($data, ['id'=>$id]);
                }catch(\Exception $e){
                    var_dump($e);exit;
                }
            }

            if($result){
                $this->redirect('/admin/coupon/edit/?id='.$id);
            }
		}
		$this->assign('data', $data);
	}

}
