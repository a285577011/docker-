<?php
use Mapper\TaskModel;

/**
 * 设备管理
 */
class DevicesController extends \Base\AdminController
{

	const BLACKDOMAINS = 'blackdomain';
    public function init()
    {
        $action=$this->getRequest()->getActionName();
        if(in_array($action,['createdevice'])){//表单操作用iframe使用另外一个模板
            $this->layout='simpleadmin';
        }
        parent::init();
    }
    public function indexAction() {
        $dp = \Mapper\DevicePortModel::getInstance();
        $device = $this->getParam('device');
        $deviceName = $this->getParam('deviceName');
        $page = abs((int)$this->getRequest()->get('page', 1));
        $limit=10;
        $where=[];
        if($device){
            list($ip,$port)=explode(':',$device);
            $where['server']=$ip;
            $where['port']=$port;
        }
        $offset=($page-1)*$limit;
        $data=$dp->fetchAllArray($where,null,$limit,$offset);
        $total = (int)$dp->count($where);
        $devices=[];
        if($data){
            $deviceId=array_filter(array_column($data,'device_id'));
            $deviceData=[];
            if($deviceId){
                $deviceData=\Mapper\DeviceModel::getInstance()->fetchAllArray(['id'=>$deviceId]);
                $deviceData=array_column($deviceData, null, 'id');
            }
            foreach ($data as $v){
                $imie='';
                if(isset($deviceData[$v['device_id']])){
                    $imie=$deviceData[$v['device_id']]['imie'];
                }
                $devices[]=['id'=>$v['id'],'name'=>$v['server'].':'.$v['port'],'port'=>$v['port'],'imie'=>$imie,'ip'=>$v['server'],'c_time'=>$v['c_time']];
            }
        }
        $totalPage = ceil($total / $limit);
        $this->assign('queryDevice', $device);
        $this->assign('deviceName', $deviceName);
        $this->assign('devices', json_encode($devices));
        $this->assign('page', $page);
        $this->assign('total', $total);
        $this->assign('totalPage', $totalPage);
        $this->assign('pageData', $devices);
	}
    /**
     * 连接stf
     */
    public function connStfAction(){
        $url='http://192.168.66.228:7100/api/v1/devices/connectDevice/';
        $post=$this->getRequest()->getPost();
        $id=$post['id'];
        $data=\Mapper\DevicePortModel::getInstance()->fetchArray(['id'=>$id]);
        $url.=$data['server'].':'.$data['port'];
        $url.="?port={$data['port']}";
        $http=new \Ku\Http();
        $http->setUrl($url);
        $resdata = $http->send();
        $resdata=json_decode($resdata,true);
        if($resdata&&$resdata['success']){
            return $this->returnData('操作成功',0);
        }
        return $this->returnData('操作失败',1001);
    }
    /**
     * 设备信息列表
     */
	public function infoListAction(){
        $dp = \Mapper\DeviceModel::getInstance();
        $imie = $this->getParam('imie');
        $page = abs((int)$this->getRequest()->get('page', 1));
        $limit=10;
        $where=[];
        if($imie){
            $where['imie']=$imie;
        }
        $offset=($page-1)*$limit;
        $devicesInfo=$dp->fetchAllArray($where,'id desc',$limit,$offset);
        $total = (int)$dp->count($where);
        $totalPage = ceil($total / $limit);
        $this->assign('queryData', json_encode($this->getRequest()->getQuery()));
        $this->assign('devices', json_encode($devicesInfo));
        $this->assign('page', $page);
        $this->assign('total', $total);
        $this->assign('totalPage', $totalPage);
        $this->assign('pageData', $devicesInfo);
    }
    public function createDeviceAction(){
        if ($this->getRequest()->isPost()) {
              $post=$this->getRequest()->getPost();
              $name=\Ku\FieldVerify::filter_value($post,'name');
              $imie=\Ku\FieldVerify::filter_value($post,'imie');
               $id=\Ku\FieldVerify::filter_int($post,'id');
            if ($deviceData = \Mapper\DeviceModel::getInstance()->fetchArray(['imie' => $imie])) {
                return $this->returnData('imie号已存在', 1001);
            }
               if($id){//修改
                   $update = ['name' => $name, 'imie' => $imie];
                   \Mapper\DeviceModel::getInstance()->updateWithArray($update,['id'=>$id]);
               }else {
                   $insert = ['name' => $name, 'imie' => $imie];
                   \Mapper\DeviceModel::getInstance()->insertWithArray($insert);
               }
            return $this->returnData('添加成功',0);
        }else{
            $id=$this->getParam('id');
            $deviceData=[];
            if($id){
                $deviceData=\Mapper\DeviceModel::getInstance()->fetchArray(['id'=>$id]);
            }
            $tasks=[['id'=>1,'name'=>'淘宝刷单'],['id'=>2,'name'=>'京东刷单'],['id'=>3,'name'=>'平多多刷单']];
            $this->assign('device', (string)json_encode($deviceData));
            $this->assign('task', (string)json_encode($tasks));
        }
    }
    public function delDeviceAction(){
        $post=$this->getRequest()->getPost();
        $id=\Ku\FieldVerify::filter_value($post,'id');
        if(!$id){
            return $this->returnData('id参数错误',1001);
        }
        if(\Mapper\DevicePortModel::getInstance()->fetchArray(['device_id'=>$id])){
            return $this->returnData('该设备已绑定端口,无法删除,请先解绑',1002);
        }
        \Mapper\DeviceModel::getInstance()->del(['id'=>$id]);
        return $this->returnData('删除成功',0);
    }
    public function msgLogAction(){
        $type = $this->getParam('type');
        $imie = $this->getParam('imie');
        $page = abs((int)$this->getRequest()->get('page', 1));
        $limit=10;
        $offset=($page-1)*$limit;
        $sql="SELECT *,device_msg_log.id as id FROM device_msg_log LEFT JOIN device ON device_msg_log.imie=device.imie";
        $where=" WHERE 1=1";
        if($type){
            $where.=" AND device_msg_log.type={$type}";
        }
        $imie&&$where.=" AND device_msg_log.imie={$imie}";
        $limitstr=" limit {$offset},{$limit}";
        $order=' order by device_msg_log.msg_time desc';
        $sql=$sql.$where.$order.$limitstr;
        $model=\Mapper\DeviceMsgLogModel::getInstance();
        $data=$model->queryForSql($sql);
        $sqlCount="SELECT count(1) as total FROM device_msg_log LEFT JOIN device ON device_msg_log.imie=device.imie";
        $sqlCount.=$where;
        $count=$model->queryForSql($sqlCount);
        $total=$count[0]['total'];
        $totalPage = ceil($total / $limit);
        $typeArr=[1=>'短信',2=>'通知'];
        if($data){
            foreach ($data as $k=>$v){
                $data[$k]['typeCn']=$typeArr[$v['type']];
                $data[$k]['content']=json_decode($v['content']);
                $data[$k]['msg_time']=date('Y-m-d H:i:s',strtotime($v['msg_time']));
            }
        }
        $this->assign('queryData', json_encode($this->getRequest()->getQuery()));
        $this->assign('dataList', json_encode($data));
        $this->assign('type', json_encode($typeArr));
        $this->assign('page', $page);
        $this->assign('total', $total);
        $this->assign('totalPage', $totalPage);
        $this->assign('pageData', $data);
    }
}