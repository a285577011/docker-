<?php

/**
 * 友链管理
 */
class LinkController extends \Base\AdminController
{

	public function indexAction()
	{
		$module = strtolower($this->getRequest()->getModuleName());
		$controller = strtolower($this->getRequest()->getControllerName());
		$action = strtolower($this->getRequest()->getActionName());
		$this->redirect('/' . $module . '/' . $controller . '/list/');
	}

	public function listAction()
	{
		$request = $this->getRequest();
		$status = $request->get('status', '');
		$mapper = \Mapper\LinkModel::getInstance();
		$where = [];
		if (strlen($status) > 0) {
			$status = intval($status);
			$where['status'] = $status;
		}
		$this->paginator($mapper, $where, 20);
		$this->assign('status', $status);
	}

	public function editAction()
	{
		$request = $this->getRequest();
		$id = $request->get('id', 0);
		$mapper = \Mapper\LinkModel::getInstance();
		$data = [];
		if ($id) {
			$data = $mapper->fetchArray(['id' => $id]);
		}

		if ($this->getRequest()->isPost()) {
			$post = [
				'title' => \Ku\Tool::filter($this->getParam('title', '')),
				'url' => \Ku\Tool::filter($this->getParam('url', '')),
				'content' => ($this->getParam('content', '')),
				'status' => intval($this->getParam('status', 0)),
				'uptime' => date('YmdHis'),
			];
			if ($id > 0) {
				$post['id'] = $id;
				$mapper->_update($post, ['id' => $id]);
				$this->alert(($id > 0 ? '修改' : '添加') . '成功', '/admin/link/edit?id=' . $post['id']);
			} else {
				$post['addtime'] = date('YmdHis');
				$exists = $mapper->fetchArray(['url' => $post['url']]);
				if ($exists && count($exists) > 0) { //已存在
					$this->alert('已存在该地址友链');
				} else {
					$post['id'] = $mapper->_insert($post);
					$this->alert(($id > 0 ? '修改' : '添加') . '成功', '/admin/link/edit?id=' . $post['id']);
				}
			}
		}
		$this->assign('data', $data);
	}


}