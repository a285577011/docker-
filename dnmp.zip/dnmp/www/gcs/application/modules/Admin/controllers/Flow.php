<?php

/**
 * 流水管理
 */
class FlowController extends \Base\AdminController
{

	public function indexAction()
	{
		$module = strtolower($this->getRequest()->getModuleName());
		$controller = strtolower($this->getRequest()->getControllerName());
		$action = strtolower($this->getRequest()->getActionName());
		$this->redirect('/' . $module . '/' . $controller . '/list/');
	}

    public function listAction(){
        $request = $this->getRequest();

        $where = [];
        $condition = [];
        //分类
        $cates = \Business\MemberModel::$_flowCates;
        $cate = $this->getParam('cate', '');
        if(isset($cates[$cate])){
            $where['cate'] = $cate;
            $condition['cate'] = $cate;
        }
        //用户
        $mid = intval($request->get('mid', 0));
        if ($mid) {
            $where[] = '(mid='.$mid.' or aid='.$mid.')';
            $condition['mid'] = $mid;
        }
        //手机号
        $mobile = intval($this->getParam('mobile', 0));
        if ($mobile) {
            $memberMp = \Mapper\MemberModel::getInstance();
            $memberMdl = $memberMp->fetch(['mobile'=>$mobile]);
            if($memberMdl instanceof \memberModel){
                $where['mid'] = $memberMdl->getId();
                $condition['mobile'] = $mobile;
            }
        }
        //日期
        $dayStart = intval(str_replace('-', '', $request->get('daystart', 0)));
        $dayEnd = intval(str_replace('-', '', $request->get('dayend', 0)));
        if($dayStart > 20181201 && $dayStart < 21181201 && $dayEnd > 20181201 && $dayEnd < 21181201){
            $where[] = 'addtime >=' . $dayStart.'000000';
            $where[] = 'addtime <=' . $dayEnd.'235959';
            $condition['daystart'] = $dayStart;
            $condition['dayend'] = $dayEnd;
        }else{
            $dayStart = date('Ymd', strtotime(date('Ymd') . ' -' . (date('N') - 1) . 'day' . ' -1week'));
            $dayEnd = date('Ymd', time()+3600);
            $where[] = 'addtime >=' . $dayStart.'000000';
            $where[] = 'addtime <=' . $dayEnd.'235959';
            $condition['daystart'] = $dayStart;
            $condition['dayend'] = $dayEnd;
        }

        $mapper = \Mapper\MemberflowModel::getInstance();
        $this->paginator($mapper, $where, 50, function($data){
            $mids = [];
            foreach($data as $key=>$value){
                $mids[] = $value['mid'];
                $mids[] = $value['aid'];
            }
            $members = [];
            if(!empty($mids)){
                $memberMp = \Mapper\MemberModel::getInstance();
                $membersArr = $memberMp->fetchAllArray(['id'=>$mids], null, null, null, ['id', 'mobile']);
                foreach ($membersArr as $key => $value) {
                    $members[$value['id']] = $value['mobile'];
                }
            }
            foreach($data as $key=>$value){
                if(isset($members[$value['mid']])){
                    $data[$key]['username'] = $members[$value['mid']];
                }else{
                    $data[$key]['username'] = $value['mid'];
                }
                if(isset($members[$value['aid']])){
                    $data[$key]['ausername'] = $members[$value['aid']];
                }else{
                    $data[$key]['ausername'] = $value['aid'];
                }
            }
            return $data;
        });

        
        $this->assign('cates', $cates);
        $this->assign('condition', $condition);
    }


}