<?php
use Mapper\TaskModel;

/**
 * 域名黑名单管理
 */
class BlackController extends \Base\AdminController
{
	const BLACKDOMAINS = 'blackdomain';

    public function indexAction() {
        $redis = $this->getRedis();
        $blackDomains = $redis->ZRANGE(\Business\TaskModel::BLACKDOMAINS, 0, -1, true);

        $this->assign('blackDomains', $blackDomains);
	}

    public function editAction(){
		$domain = strtolower($this->getParam('domain', ''));
        if(!\Ku\Verify::isDomain(str_replace('*', 'www', $domain))){
			return $this->returnData('域名错误', 1, false);
        }

        $redis = $this->getRedis();
        $result = $redis->ZADD(\Business\TaskModel::BLACKDOMAINS, time(), $domain);

        return $this->returnData('成功', 0, (bool)$result);
    }

    public function delAction(){
        $domain = strtolower($this->getParam('domain', ''));
        if(!\Ku\Verify::isDomain(str_replace('*', 'www', $domain))){
            return $this->returnData('域名错误', 1, false);
        }

        $redis = $this->getRedis();
        $result = $redis->ZREM(\Business\TaskModel::BLACKDOMAINS, $domain);

        return $this->returnData('成功', 0, (bool)$result);
    }

}