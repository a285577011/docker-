<?php

/* 
 * 上传控制器
 */
class UploadController extends \Base\AdminController{
    
    private $drives = ['cover', 'selected'];

    /**
     * 图片上传
     * @return type
     */
    public function imageAction(){
        
        $this->disableView();
        $this->disableLayout();

        // 尺寸判断
        $width = $this->getParam('width', '', 'int');
        $height = $this->getParam('height', '', 'int');
        $drice = $this->getParam('drice', '', 'string');

        if (!$width || !$height) {
            $this->returnData('未设置尺寸', 30102, false);
            return False;
        }

        if(!in_array($drice, $this->drives)){
            return $this->returnData('找不到上传类型', 33106, false);
        }

        if (empty($_FILES['file'])) {
            $this->returnData('请上传文件', 30103, false);
            return False;
        }

        $upload = new \Ku\Upload();
        $uploadsDir = \Bootstrap::getApiDomain('uploads');
        $date = date('Ym');
        $upload->set('path', PUBLIC_PATH . DS . $uploadsDir . DS . $drice . DS . $date)->set('allowtype', array('png', 'jpeg', 'jpg'))->set(
            'maxsize',
            307200
        );
        $method = is_array($_FILES['file']['name']) ? 'multipleUpload' : 'singleUpload';
        $return = $upload->$method('file');

        if (!$return || $upload->getErrorMsg()) {
            $data['error'] = $upload->getErrorMsg();
            $this->returnData('上传失败', 30102, false, $data);
            return False;
        }

        // 图片尺寸检查
        $result = $upload->getAbsoluteFilename();
        $result = is_array($result) ? $result : array($result);
        $error = False;
        foreach ($result as $key => $value) {
            $image = getimagesize($value);
            if ($image[0] != $width && $image[1] != $height) {
                $error = True;
                break;
            }
        }
        if ($error) {
            foreach ($result as $key => $value) {
                @unlink($value);
            }
            $this->returnData("图片尺寸不合法", 30104, false);
            return True;
        }

        $result = $upload->getAbsoluteFilename(PUBLIC_PATH . DS . $uploadsDir . DS);
        $data['image'] = is_array($result) ? $result : array($result);
        $this->returnData('上传成功', 20001, true, $data);
        return True;
    }
    
}
