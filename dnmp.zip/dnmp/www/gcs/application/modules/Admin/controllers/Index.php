<?php

/**
 * 
 */
class IndexController extends \Base\AdminController {

	public function indexAction(){
		$memberMp = \Mapper\MemberModel::getInstance();
		$orderMp = \Mapper\OrderModel::getInstance();
		$memberFlowMp = \Mapper\MemberflowModel::getInstance();
		$taskMp = \Mapper\TaskModel::getInstance();
		$time = time();
		$today = date('Ymd', $time);
		$yesterday = date('Ymd', $time-86400);
		$upMonthDay = date('Ym01', strtotime('-1month'));
		$monthDay = date('Ym01');

		$cacheId = $this->cacheId([__CLASS__, __METHOD__, $today]);
		$data = $this->getCache($cacheId);
		if($data===false){
			$data = [];
			#注册用户量变化
			$data['sumReg'] = $memberMp->count([]);
			$data['todayReg'] = $memberMp->count('addtime >='.$today.'000000 and addtime <'.$today.'235959');
			$data['yesterdayReg'] = $memberMp->count('addtime >='.$yesterday.'000000 and addtime <'.$today.'000000');
			$data['lastmonthReg'] = $memberMp->count('addtime >='.$upMonthDay.'000000 and addtime <'.$monthDay.'000000');
			$data['monthReg'] = $memberMp->count('addtime >='.$monthDay.'000000');

			#充值订单量
			$data['sumOrder'] = $orderMp->count(['pay_from!=?'=>'unknow']);
			$data['todayOrder'] = $orderMp->count('pay_from!="unknow" && addtime >='.strtotime($today.'000000').' and addtime <'.strtotime($today.'235959'));
			$data['yesterdayOrder'] = $orderMp->count('pay_from!="unknow" && addtime >='.strtotime($yesterday.'000000').' and addtime <'.strtotime($today.'000000'));
			$data['lastmonthOrder'] = $orderMp->count('pay_from!="unknow" && addtime >='.strtotime($upMonthDay.'000000').' and addtime <'.strtotime($monthDay.'000000'));
			$data['monthOrder'] = $orderMp->count('pay_from!="unknow" && addtime >='.strtotime($monthDay.'000000'));

			#充值金额
			$data['sumRecharge'] = $orderMp->sum('total_fee', ['pay_from!=?'=>'unknow']);
			$data['todayRecharge'] = $orderMp->sum('total_fee', 'pay_from!="unknow" && addtime >='.strtotime($today.'000000').' and addtime <'.strtotime($today.'235959'));
			$data['yesterdayRecharge'] = $orderMp->sum('total_fee', 'pay_from!="unknow" && addtime >='.strtotime($yesterday.'000000').' and addtime <'.strtotime($today.'000000'));
			$data['lastmonthRecharge'] = $orderMp->sum('total_fee', 'pay_from!="unknow" && addtime >='.strtotime($upMonthDay.'000000').' and addtime <'.strtotime($monthDay.'000000'));
			$data['monthRecharge'] = $orderMp->sum('total_fee', 'pay_from!="unknow" && addtime >='.strtotime($monthDay.'000000'));

			#积分流水变化量
			$data['sumFlow'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', []);
			$data['todayFlow'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'addtime >='.$today.'000000 and addtime <'.$today.'235959');
			$data['yesterdayFlow'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'addtime >='.$yesterday.'000000 and addtime <'.$today.'000000');
			$data['lastmonthFlow'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'addtime >='.$upMonthDay.'000000 and addtime <'.$monthDay.'000000');
			$data['monthFlow'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'addtime >='.$monthDay.'000000');

			#积分增加
			$data['sumIncome'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', ['cate'=>'rechange']);
			$data['todayIncome'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate = "rechange" and addtime >='.$today.'000000 and addtime <'.$today.'235959');
			$data['yesterdayIncome'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate = "rechange" and addtime >='.$yesterday.'000000 and addtime <'.$today.'000000');
			$data['lastmonthIncome'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate = "rechange" and addtime >='.$upMonthDay.'000000 and addtime <'.$monthDay.'000000');
			$data['monthIncome'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate = "rechange" and addtime >='.$monthDay.'000000');

			#积分消耗
			$data['sumPayout'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate in("prepay", "deduction")');
			$data['todayPayout'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate in("prepay", "deduction") and addtime >='.$today.'000000 and addtime <'.$today.'235959');
			$data['yesterdayPayout'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate in("prepay", "deduction") and addtime >='.$yesterday.'000000 and addtime <'.$today.'000000');
			$data['lastmonthPayout'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate in("prepay", "deduction") and addtime >='.$upMonthDay.'000000 and addtime <'.$monthDay.'000000');
			$data['monthPayout'] = $memberFlowMp->sum('`pointChange`+`freezeChange`', 'cate in("prepay", "deduction") and addtime >='.$monthDay.'000000');

			#任务数量变化
			$data['sumTask'] = $taskMp->count([]);
			$data['todayTask'] = $taskMp->count('addtime >='.$today.'000000 and addtime <'.$today.'235959');
			$data['yesterdayTask'] = $taskMp->count('addtime >='.$yesterday.'000000 and addtime <'.$today.'000000');
			$data['lastmonthTask'] = $taskMp->count('addtime >='.$upMonthDay.'000000 and addtime <'.$monthDay.'000000');
			$data['monthTask'] = $taskMp->count('addtime >='.$monthDay.'000000');

			$this->setCache($cacheId, $data, 60);
		}
		//var_dump($data);exit;

		$_flowCates = \Business\MemberModel::$_flowCates;
		$_flowCates['sum'] = '总计';
		$_payCates = \Business\MemberModel::$_payCates;
		$_payCates['sum'] = '支付完成总计';
		$_payCates['num'] = '支付完成笔数';
		$this->assign('_flowCates', $_flowCates);
		$this->assign('_payCates', $_payCates);
		$this->assign('data', $data);
	}

	public function regstatAction(){
		$memberMp = \Mapper\MemberModel::getInstance();
		$data = [];
        //日期
        $startTime = $this->getParam('start', '');
        $endTime = $this->getParam('end','');
        if(empty($startTime)){
            $start = date('Ymd',strtotime("-30 day"));
        }else{
            $start = date('Ymd',strtotime($startTime));
        }
        if(empty($endTime)){
            $end = date('Ymd');
        }else{
            $end = date('Ymd',strtotime($endTime));
        }
		$day = $start;
		$today = date('Ymd');
        do{
			$cacheId = $this->cacheId([__CLASS__, __METHOD__, $day]);
			$data[$day] = $this->getCache($cacheId);
			if($data[$day]===false){
				$data[$day] = $memberMp->count('addtime >='.$day.'000000 and addtime <'.$day.'235959');
				$expire = $day>=$today ? 60 : 2592000;
				$this->setCache($cacheId, $data[$day], $expire);
			}
            $day = date('Ymd',strtotime($day)+86400);
        }while ($day<=$end);
        //提供导出数据
        $export = $this->getParam('export',0);
        if($export){
            $this->export('reg', $data);
        }else{
            $this->returnData('成功', 10000, true, $data);
        }
	}

	public function paystatAction(){
		$orderMp = \Mapper\OrderModel::getInstance();
		$data = [
			'weixinpay'=>[],
			'alipaypage'=>[],
			'unknow'=>[],
			'companypay'=>[],
			'sum'=>[],
			'num'=>[],
		];
        //日期
        $startTime = $this->getParam('start', '');
        $endTime = $this->getParam('end','');
        if(empty($startTime)){
            $start = date('Ymd',strtotime("-30 day"));
        }else{
            $start = date('Ymd',strtotime($startTime));
        }
        if(empty($endTime)){
            $end = date('Ymd');
        }else{
            $end = date('Ymd',strtotime($endTime));
        }
		$day = $start;
		$today = date('Ymd');
        do{
			$cacheId = $this->cacheId([__CLASS__, __METHOD__, $day]);
			$cacheData = $this->getCache($cacheId);
			if($cacheData===false){
				$sum = 0;
				$num = 0;
				$sql = 'select pay_from,sum(total_fee) as count,count(*) as num from `order` where '.'addtime >='.strtotime($day.'000000').' and addtime <'.strtotime($day.'235959').' group by pay_from';
				$todayData = $orderMp->query($sql)->toArray();
				foreach($todayData as $k => $v){
					$cacheData[$v['pay_from']] = intval($v['count']);
					if($v['pay_from']!='unknow'){
						$sum += intval($v['count']);
						$num += intval($v['num']);
					}
				}
				$cacheData['sum'] = $sum;
				$cacheData['num'] = $num;
				
				$expire = $day>=$today ? 60 : 2592000;
				$this->setCache($cacheId, $cacheData, $expire);
			}
			$data['weixinpay'][$day] = isset($cacheData['weixinpay']) ? $cacheData['weixinpay'] : 0;
			$data['alipaypage'][$day] = isset($cacheData['alipaypage']) ? $cacheData['alipaypage'] : 0;
			$data['unknow'][$day] = isset($cacheData['unknow']) ? $cacheData['unknow'] : 0;
			$data['companypay'][$day] = isset($cacheData['companypay']) ? $cacheData['companypay'] : 0;
			$data['sum'][$day] = isset($cacheData['sum']) ? $cacheData['sum'] : 0;
			$data['num'][$day] = isset($cacheData['num']) ? $cacheData['num'] : 0;

            $day = date('Ymd',strtotime($day)+86400);
        }while ($day<=$end);
        //提供导出数据
        $export = $this->getParam('export',0);
        if($export){
            $this->export('pay', $data);
        }else{
            $this->returnData('成功', 10000, true, $data);
        }
	}

	public function flowstatAction(){
		$memberFlowMp = \Mapper\MemberflowModel::getInstance();
		$data = [
			//'income'=>[],
			//'freeze'=>[],
			//'payout'=>[],
			//'freePayout'=>[],
			'changePoint'=>[],
			//'task'=>[],
			'prepay'=>[],
			'rechange'=>[],
			'deduction'=>[],
			'sum'=>[],
		];
        //日期
        $startTime = $this->getParam('start', '');
        $endTime = $this->getParam('end','');
        if(empty($startTime)){
            $start = date('Ymd',strtotime("-30 day"));
        }else{
            $start = date('Ymd',strtotime($startTime));
        }
        if(empty($endTime)){
            $end = date('Ymd');
        }else{
            $end = date('Ymd',strtotime($endTime));
        }
		$day = $start;
		$today = date('Ymd');
        do{
			$cacheId = $this->cacheId([__CLASS__, __METHOD__, $day]);
			$cacheData = $this->getCache($cacheId);
			if($cacheData===false){
				$sum = 0;
				$sql = 'select cate,sum(pointChange+freezeChange) as num from `member_flow` where '.'addtime >='.$day.'000000 and addtime <'.$day.'235959'.' group by cate';
				$todayData = $memberFlowMp->query($sql)->toArray();
				foreach($todayData as $k => $v){
					$cacheData[$v['cate']] = intval($v['num']);
					$sum += intval($v['num']);
				}
				$cacheData['sum'] = $sum;
				
				$expire = $day>=$today ? 60 : 2592000;
				$this->setCache($cacheId, $cacheData, $expire);
			}
			//$data['task'][$day] = isset($cacheData['task']) ? $cacheData['task'] : 0;
			$data['prepay'][$day] = isset($cacheData['prepay']) ? $cacheData['prepay'] : 0;
			$data['rechange'][$day] = isset($cacheData['rechange']) ? $cacheData['rechange'] : 0;
			$data['deduction'][$day] = isset($cacheData['deduction']) ? $cacheData['deduction'] : 0;
			//$data['income'][$day] = isset($cacheData['income']) ? $cacheData['income'] : 0;
			//$data['freeze'][$day] = isset($cacheData['freeze']) ? $cacheData['freeze'] : 0;
			//$data['payout'][$day] = isset($cacheData['payout']) ? $cacheData['payout'] : 0;
			//$data['freePayout'][$day] = isset($cacheData['freePayout']) ? $cacheData['freePayout'] : 0;
			$data['changePoint'][$day] = isset($cacheData['changePoint']) ? $cacheData['changePoint'] : 0;
			$data['sum'][$day] = isset($cacheData['sum']) ? $cacheData['sum'] : 0;

            $day = date('Ymd',strtotime($day)+86400);
        }while ($day<=$end);
        //提供导出数据
        $export = $this->getParam('export',0);
        if($export){
            $this->export('flow', $data);
        }else{
            $this->returnData('成功', 10000, true, $data);
        }
	}

	public function taskstatAction(){
		$taskMp = \Mapper\TaskModel::getInstance();
		$data = [];
		//日期
		$startTime = $this->getParam('start', '');
		$endTime = $this->getParam('end','');
		if(empty($startTime)){
			$start = date('Ymd',strtotime("-30 day"));
		}else{
			$start = date('Ymd',strtotime($startTime));
		}
		if(empty($endTime)){
			$end = date('Ymd');
		}else{
			$end = date('Ymd',strtotime($endTime));
		}
		$day = $start;
		$today = date('Ymd');
		do{
			$cacheId = $this->cacheId([__CLASS__, __METHOD__, $day]);
			$data[$day] = $this->getCache($cacheId);
			if($data[$day]===false){
				$data[$day] = $taskMp->count('addtime >='.$day.'000000 and addtime <'.$day.'235959');
				$expire = $day>=$today ? 60 : 2592000;
				$this->setCache($cacheId, $data[$day], $expire);
			}
			$day = date('Ymd',strtotime($day)+86400);
		}while ($day<=$end);
		//提供导出数据
		$export = $this->getParam('export',0);
		if($export){
			$this->export('task', $data);
		}else{
			$this->returnData('成功', 10000, true, $data);
		}
	}

    protected function export($type, $data){
		$this->disableLayout();
	   $this->disableView();
	   $filename = $type . date('YmdHis') . '.csv'; //文件名
	   header('Content-type:text/csv');
	   header('Content-Disposition:attachment;filename=' . $filename);
	   header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
	   header('Expires:0');
	   header('Pragma:public');
	   switch ($type){
		   case 'task':
		   case 'reg':
				   $dataExport = '日期,数量'. "\n"; //栏目名称;
				   foreach ($data as $key => $value){
					   $dataExport .= $key.','.$value . "\n";
				   }
				   break;
		   case 'pay':
				   $dataExport = '日期,总额,微信总额,支付宝支付,转账支付'. "\n"; //栏目名称;
				   foreach ($data['sum'] as $key => $value){
					   $dataExport .= $key.','.$value.','.$data['weixinpay'][$key].','.$data['alipaypage'][$key].','.$data['companypay'][$key]. "\n";
				   }
				   break;
		   case 'flow':
				   $dataExport = '日期,总消耗,任务相关,预扣款,充值,扣款,收入,冻结,支出,冻结款支出,修改'. "\n"; //栏目名称;
				   foreach ($data['sum'] as $key => $value){
					   $dataExport .= $key.','.$value.','.$data['task'][$key].','.$data['prepay'][$key].','.$data['rechange'][$key].','.$data['deduction'][$key].','.$data['income'][$key].','.$data['freeze'][$key].','.$data['payout'][$key].','.$data['freePayout'][$key].','.$data['changePoint'][$key]. "\n";
				   }
				   break;
	   }
	   echo $dataExport;
   }



}