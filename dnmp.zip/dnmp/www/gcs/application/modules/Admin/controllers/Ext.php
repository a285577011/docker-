<?php
use Ormbuild\Lib\Exception;

/**
 * 查劫持插件管理
 */
class ExtController extends \Base\AdminController
{

	public function indexAction()
	{
		$module = strtolower($this->getRequest()->getModuleName());
		$controller = strtolower($this->getRequest()->getControllerName());
		$action = strtolower($this->getRequest()->getActionName());
		$this->redirect('/' . $module . '/' . $controller . '/list/');
	}

	public function listAction(){
        $redis = $this->getRedis();
		$exts = $redis->ZREVRANGEBYSCORE('monitor:ext', '+inf', '-inf', ['withscores'=>true]);

		$today = date('Ymd');
		$yesterday = date('Ymd', time()-86400);
		//$tendayTime = strtotime(date('Ymd', time()-864000));
		$infos = [];
		foreach($exts as $ext=>$expire){
			//默认
			$infos[$ext] = [
				'version'=>0,
				'ip'=>'', 
				'yesterdaySubmit'=>0,
				'yesterdayFinish'=>0,
				'todaySubmit'=>0,
				'todayFinish'=>0,
				'dest'=>'',
				'remark'=>'',
			];
			//获取数据
			$infoKey = 'monitor:ext:'.$ext;
			$info = $redis->HGETALL($infoKey);
			if(isset($info['ip'])){
				$infos[$ext]['ip'] = $info['ip'];
			}
			if(isset($info['version'])){
				$infos[$ext]['version'] = $info['version'];
			}
			if(isset($info['dest'])){
				$infos[$ext]['dest'] = $info['dest'];
			}
			if(isset($info['remark'])){
				$infos[$ext]['remark'] = $info['remark'];
			}

			$yesterdaySummitKey = 'monitor:ext:'.$ext.":submit:".$yesterday;
			$infos[$ext]['yesterdaySubmit'] = intval($redis->get($yesterdaySummitKey));

			$yesterdayFinishKey = 'monitor:ext:'.$ext.":finish:".$yesterday;
			$infos[$ext]['yesterdayFinish'] = intval($redis->get($yesterdayFinishKey));

			$todaySummitKey = 'monitor:ext:'.$ext.":submit:".$today;
			$infos[$ext]['todaySubmit'] = intval($redis->get($todaySummitKey));

			$todayFinishKey = 'monitor:ext:'.$ext.":finish:".$today;
			$infos[$ext]['todayFinish'] = intval($redis->get($todayFinishKey));

			//十天前的删除
			//if(abs($expire)<$tendayTime){
			//	$redis->ZREM('monitor:ext', $ext);
			//	$redis->DEL($infoKey);
			//}
		}

		$this->assign('exts', $exts);
		$this->assign('infos', $infos);
	}



	public function delAction(){
		$request = $this->getRequest();
		$ext = $request->get('ext');
		if(!$ext){
			return $this->returnData('参数不正确', 0, false);
		}

		$redis = $this->getRedis();
		$score = $redis->ZSCORE('monitor:ext', $ext);
		if($score!==false){
			$redis->ZREM('monitor:ext', $ext);

			$infoKey = 'monitor:ext:'.$ext;
			$redis->DEL($infoKey);

			return $this->returnData('删除成功', 0, true);
		}

		return $this->returnData('插件不存在', 0, false);
	}

	public function remarkAction(){
		$request = $this->getRequest();
		$ext = $request->get('ext');
		$remark = $request->get('remark', '');
		if(!$ext){
			return $this->returnData('参数不正确', 0, false);
		}

		$redis = $this->getRedis();
		$score = $redis->ZSCORE('monitor:ext', $ext);
		if($score!==false){
			$infoKey = 'monitor:ext:'.$ext;
			$redis->HSET($infoKey, 'remark', $remark);
			
			return $this->returnData('修改成功', 0, true);
		}

		return $this->returnData('插件不存在', 0, false);
	}

	public function detailAction(){
		$request = $this->getRequest();
		$ext = $request->get('ext');
		$remark = $request->get('remark', '');
		if(!$ext){
			throw new Exception('参数不正确');
		}

		$redis = $this->getRedis();
		$score = $redis->ZSCORE('monitor:ext', $ext);
		if($score===false){
			throw new Exception('插件不存在');
		}
	
		//默认
		$info = [
			'ext'=>$ext,
			'expire'=>$score,
			'version'=>0,
			'ip'=>'', 
			'dest'=>'',
			'remark'=>'',
		];
		//获取插件信息
		$infoKey = 'monitor:ext:'.$ext;
		$infoData = $redis->HGETALL($infoKey);
		//var_dump($infoData);exit;
		if(isset($infoData['ip'])){
			$info['ip'] = $infoData['ip'];
		}
		if(isset($infoData['version'])){
			$info['version'] = $infoData['version'];
		}
		if(isset($infoData['dest'])){
			$info['dest'] = $infoData['dest'];
		}
		if(isset($infoData['remark'])){
			$info['remark'] = $infoData['remark'];
		}

		//获取十天提交信息
		$time = time();
		$tendayTime = $time-777600;
		for($i=$time;$i>=$tendayTime;$i-=86400){
			$Ymd = date('Ymd', $i);

			$monitorSummitKey = 'monitor:ext:'.$ext.":submit:".$Ymd;
			$info['count'][$Ymd]['submit'] = intval($redis->get($monitorSummitKey));

			$monitorFinishKey = 'monitor:ext:'.$ext.":finish:".$Ymd;
			$info['count'][$Ymd]['finish'] = intval($redis->get($monitorFinishKey));
		}
		//var_dump($info);exit;

		$this->assign('info', $info);
	}
}