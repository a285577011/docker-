<?php

/**
 * 管理员管理
 */
use \Mapper\AdminModel as AdminMapper;
use \Mapper\AdmingroupModel as AdmingroupMapper;
use \Mapper\PurviewsModel as PurviewsMapper;
use \Mapper\AdminlogModel as AdminlogMapper;

class ManageController extends \Base\AdminController {


    public function indexAction() {
        $adminMapper = AdminMapper::getInstance();
        $admingroupMapper = AdmingroupMapper::getInstance();
        $page = $this->getParam('page', 1);
        $name = $this->getParam('name', '');
        $group = $this->getParam('group', '');
        $select = $adminMapper->sql()->select();
        $select->join('admin_group', 'admin.group_id = admin_group.id','group_name');
        $select->order(array('admin.id desc'));
        if ($name) {
            $select->where(array("admin.name like '%" . $name . "%'"));
        }
        if($group){
            $select->where(array("admin_group.id =".$group));
        }
        //分页
        $pager = new \Ku\Page($select, $page);
        $groups = $admingroupMapper->fetchAll();
        $this->assign('lists',$pager->getList());
        $this->assign('pager', $pager);
        $this->assign('groups', $groups);
        $this->assign('group', $group);
    }

    public function addAction() {
        $adminMapper = AdminMapper::getInstance();
        $model = new \AdminModel();
        if ($this->getRequest()->isPost()) {
            $name = $this->getParam('name', '');
            $email = $this->getParam('email', '');
            $password = $this->getParam('password', '');
            $groupId = $this->getParam('group_id', 0);
            $disabled = $this->getParam('disabled', 0);
            $model->setName($name);
            $model->setEmail($email);
            $model->setPassword($adminMapper->password($password));
            $model->setGroup_id($groupId);
            $model->setDisabled($disabled);
            $model->setTime(date('YmdHis'));
            $errors = $this->validators($model);
            if ($errors) {
                return $this->returnData($errors,101);
            } else {
                try {
                    $id = $adminMapper->insert($model);
                    if($id) \Mapper\AdminlogModel::getInstance()->log('管理员ID：'.$this->getAdminId().'，添加后台用户，ID：'.$id, \Mapper\AdminlogModel::MANAGE);
                    return $this->returnData('添加成功',100,true);
                } catch (\Exception $exc) {
                    $errmsg = $exc->getMessage();
                    return $this->returnData($errmsg,101);
                }
            }
        }
    }

    public function editAction() {
        $adminMapper = AdminMapper::getInstance();
        $adminId = intval($this->getParam('id', 0));
        $model = $adminMapper->findById($adminId);
        if (!$model) {
            $this->alert('ID 不存在', '/admin/');
        }
        if ($this->getRequest()->isPost()) {
            $name = $this->getParam('name', '');
            $email = $this->getParam('email', '');
            $password = $this->getParam('password', '');
            $groupId = $this->getParam('group_id', 0);
            $disabled = $this->getParam('disabled', 0);
            $model->setName($name);
            $model->setEmail($email);
            if ($password != $model->getPassword()) {
                $model->setPassword($adminMapper->password($password));
            }
            $model->setGroup_id($groupId);
            $model->setDisabled($disabled);
            $errors = $this->validators($model);
            if ($errors) {
                $this->showError($errors);
            } else {
                try {
                    $id = $adminMapper->update($model);
                    if($id) \Mapper\AdminlogModel::getInstance()->log('管理员ID：'.$this->getAdminId().'，修改后台用户ID：'.$id, \Mapper\AdminlogModel::MANAGE);
                    $this->alert('修改成功', '/admin/');
                } catch (\Exception $exc) {
                    $errmsg = $exc->getMessage();
                    $this->alert($errmsg);
                }
            }
        }

        $admingroupMapper = AdmingroupMapper::getInstance();
        $groups = $admingroupMapper->getAll();
        $this->assign('groups', $groups);
        $this->assign('model', $model);
        $this->display('edit');
        exit();
    }

    /**
     * 管理员组显示
     */
    public function groupAction() {
        $admingroupMapper = AdmingroupMapper::getInstance();
        $groups = $admingroupMapper->fetchAll();
        $this->assign('groups', $groups);
    }

    /**
     * 管理员组添加
     */
    public function groupaddAction() {
        $admingroupMapper = AdmingroupMapper::getInstance();
        $model = new \AdmingroupModel();
        if ($this->getRequest()->isPost()) {
            $groupName = $this->getParam('group_name', '');
            $errors = array();
            if (!$groupName) {
                $errors = '请输入管理员组名称';
            }
            if ($admingroupMapper->findByGroup_name($groupName)) {
                $errors = '管理员组已经存在';
            }
            $model->setGroup_name($groupName);
            $model->setPurview(json_encode(array(1)));

            if ($errors) {
                return $this->returnData($errors,'1001');
            } else {
                try {
                    $id = $admingroupMapper->insert($model);
                    if($id) \Mapper\AdminlogModel::getInstance()->log('管理员ID：'.$this->getAdminId().'添加后台用户组，ID：'.$id, \Mapper\AdminlogModel::MANAGE);
                    return $this->returnData('添加成功','1000',true);
                } catch (\Exception $exc) {
                    $errmsg = $exc->getMessage();
                    return $this->returnData($errmsg,'1001');
                }
            }
        }
    }

    /**
     * 管理员组添加
     */
    public function groupeditAction() {
        $groupId = intval($this->getParam('groupid', 0));
        $admingroupMapper = AdmingroupMapper::getInstance();
        $model = $admingroupMapper->findById($groupId);
        if ($this->getRequest()->isPost()) {
            $groupName = $this->getParam('group_name', '');
            $errors = array();
            if (!$groupName) {
                $errors['group_name'] = '请输入管理员组名称';
            }
            $search = $admingroupMapper->findByGroup_name($groupName);
            if ($search && $model->getId() != $search->getId()) {
                $errors['group_name'] = '管理员组已经存在';
            }
            $model->setGroup_name($groupName);

            if ($errors) {
                $this->showError($errors);
            } else {
                try {
                    $id = $admingroupMapper->update($model);
                    if($id) \Mapper\AdminlogModel::getInstance()->log('管理员ID：'.$this->getAdminId().'，修改后台用户组，ID：'.$id, \Mapper\AdminlogModel::MANAGE);
                    $this->alert('修改成功', '/admin/index/group/');
                } catch (\Exception $exc) {
                    $errmsg = $exc->getMessage();
                    $this->alert($errmsg);
                }
            }
        }
        $this->assign('model', $model);
    }

    /**
     * 权限设置
     */
    public function purviewAction() {
        $groupid = $this->getParam('groupid', 0);
        $this->assign('groupid', $groupid);
        $admingroupMapper = AdmingroupMapper::getInstance();
        $purviewsMapper = PurviewsMapper::getInstance();
        $group = $admingroupMapper->findById($groupid);
        if (!$group) {
            $this->alert('管理员组ID不存在', '/admin/manage/group/');
        } else {
            if ($this->getRequest()->isPost()) {
                $pids = $this->getParam('pid');
                $purs = $pids ? json_encode($pids) : '';
                if ($groupid != 1) {
                    $group->setPurview($purs);
                    $id = $admingroupMapper->update($group);
                    if($id) \Mapper\AdminlogModel::getInstance()->log('管理员ID：'.$this->getAdminId().'，后台用户组权限设置，ID：'.$id, \Mapper\AdminlogModel::MANAGE);
                }
                $this->alert('权限设置成功', '/admin/manage/group/');
            }
            $this->assign('menus', $purviewsMapper->getMenus(0));
            $purs = ($group->getPurview() != '' && $group->getPurview() != '*') ? json_decode($group->getPurview()) : array();
            $this->assign('purs', $purs);
        }
    }

    /**
     * 权限菜单列表
     */
    public function purviewsAction(){
        $purviewsMapper = PurviewsMapper::getInstance();
        $this->assign('lists',$purviewsMapper->findChirdren());
        $this->assign('menus', $purviewsMapper->menus());
    }

    /**
     * 权限菜单添加
     */
    public function purviewsaddAction(){
        $purviewMapper = PurviewsMapper::getInstance();
        $model = new \PurviewsModel();
        if ($this->getRequest()->isPost()) {
            $menu_name = \Ku\Tool::filter($this->getParam('menu_name', ''));
            $module = \Ku\Tool::filter($this->getParam('module', ''));
            $controller = \Ku\Tool::filter($this->getParam('controller', ''));
            $action = \Ku\Tool::filter($this->getParam('action', ''));
            $parent = \Ku\Tool::filter($this->getParam('parent', ''));
            $reorder = \Ku\Tool::filter($this->getParam('reorder', ''));
            $css = \Ku\Tool::filter($this->getParam('css', ''));
            $isshow = \Ku\Tool::filter($this->getParam('isshow', ''));
            $model->setMenu_name($menu_name);
            $model->setModule($module);
            $model->setController($controller);
            $model->setAction($action);
            $model->setParent($parent);
            $model->setReorder($reorder);
            $model->setCss($css);
            $model->setIsshow($isshow);
            $errors = $this->purviewvalidators($model);
            if($errors){
                return $this->returnData($errors, 23201);
            }else {
                try {
                    $purviewMapper->insert($model);
                    return $this->returnData('添加成功', 23200, true);
                } catch (\Exception $exc) {
                    $errmsg = $exc->getMessage();
                    return $this->returnData($errmsg, 23201);
                }
            }
        }
    }

    /**
     * 权限菜单修改
     */
    public function purviewseditAction(){
        $id = intval($this->getParam('id', 0));
        $purviewsMapper = PurviewsMapper::getInstance();
        $model = $purviewsMapper->findById($id);
        $this->assign('model', $model);
        if ($this->getRequest()->isPost()) {
            $menu_name = \Ku\Tool::filter($this->getParam('menu_name', ''));
            $module = \Ku\Tool::filter($this->getParam('module', ''));
            $controller = \Ku\Tool::filter($this->getParam('controller', ''));
            $action = \Ku\Tool::filter($this->getParam('action', ''));
            $parent = \Ku\Tool::filter($this->getParam('parent', ''));
            $reorder = \Ku\Tool::filter($this->getParam('reorder', ''));
            $css = \Ku\Tool::filter($this->getParam('css', ''));
            $isshow = \Ku\Tool::filter($this->getParam('isshow', ''));
            $model->setMenu_name($menu_name);
            $model->setModule($module);
            $model->setController($controller);
            $model->setAction($action);
            $model->setParent($parent);
            $model->setReorder($reorder);
            $model->setCss($css);
            $model->setIsshow($isshow);
            $errors = $this->purviewvalidators($model);
            if($errors){
                return $this->alert($errors);
            }else {
                try {
                    $purviewsMapper->update($model);
                    return $this->alert('修改成功', '/admin/manage/purviews/');
                } catch (\Exception $exc) {
                    $errmsg = $exc->getMessage();
                    return $this->alert($errmsg);
                }
            }
        }
        $this->assign('menus', $purviewsMapper->menus());
    }

    /**
     * 权限菜单删除
     */
    public function purviewsdelAction(){
        $id = intval($this->getParam('id', 0));
        $purviewMapper = PurviewsMapper::getInstance();
        if(empty($id)){
            $this->returnData('非法操作', 23201);
        }
        $where = array(
            'id' => $id
        );
        try {
            $purviewMapper->del($where);
            $this->returnData('删除成功', 23200, true);
        } catch (\Exception $exc) {
            $errmsg = $exc->getMessage();
            $this->returnData($errmsg, 23201);
        }
        $this->redirect('/admin/manage/purviews/');
    }

    /**
     * 验证器
     */
    public function purviewvalidators(\PurviewsModel $model){
        if(!$model->getMenu_name()){
            return '请输入菜单名称';
        }
        if(!$model->getModule()){
            return '请输入模块';
        }
        return false;
    }


    //验证器

    public function validators(\AdminModel $model) {
        //错误消息的键名必须是表单的对应输入对象的名称
        if (!$model->getName()) {
            return '名称不能为空';

        }
        if (!$model->getPassword()) {
            return '密码不能为空';
        }

        if (!$model->getGroup_id()) {
            return '请选择用户组';

        }
        if (!$model->getEmail() || !\Ku\Verify::isEmail($model->getEmail())) {
            return '请输入正确的邮箱';
        }
        return false;

    }

    public function passwordAction() {
        $admin = $this->getloginAdmin();
        $request = $this->getRequest();
        $adminMapper = AdminMapper::getInstance();
        $adminId = $admin->getId();

        if ($request->isPost()) {
            $oldPwd = $request->get('oldpwd', '');
            $newPwd = $request->get('newpwd', '');
            $renewPwd = $request->get('renewpwd', '');

            $errorMsg = array();
            if ($newPwd != $renewPwd) {
                $errorMsg['newpwd'] = '新密码不匹配';
            }
            if (strlen($newPwd) < 6) {
                $errorMsg['newpwd'] = '密码不能少于6位数';
            }
            if ($adminMapper->password($oldPwd) != $admin->getPassword()) {
                $errorMsg['oldpwd'] = '原密码输入不正确';
            }

            if ($errorMsg) {
                $this->showError($errorMsg);
            } else {
                $adminModel = $adminMapper->findById($adminId);
                $adminModel->setPassword($adminMapper->password($newPwd));
                try {
                    $id = $adminMapper->update($adminModel);
                    if($id) \Mapper\AdminlogModel::getInstance()->log('管理员ID：'.$this->getAdminId().'修改后台用户密码，ID：'.$id, \Mapper\AdminlogModel::MANAGE);
                    $this->alert('密码修改成功', '/admin/index/password/');
                } catch (\Exception $e) {
                    $this->alert($e->getMessage());
                }
            }
        }

        $this->assign('title', '密码修改');
    }

    public function adminlogAction(){
        $adminlogMapper = AdminlogMapper::getInstance();
        $page = intval($this->getParam('page',1));
        $type = intval($this->getParam('type',-1));
        $startTime = intval($this->getParam('start_time', 0));
        $endTime = intval($this->getParam('end_time', 0));
        $select = $adminlogMapper->sql()->select();
        $select->order("time desc");
        $where = array();
        if($type>-1){
            $where[] = "type = {$type}";
        }
        if($startTime && !$endTime) {
            $startime = date('YmdHis',$startTime);
            $where[] = "time >= {$startime}";
        }elseif($endTime && !$startTime) {
            $endtime = date('YmdHis',$endTime);
            $where[] = "time <= {$endtime}";
        }elseif($startTime && $endTime) {
            $starttime = date('YmdHis',$startTime);
            $endtime = date('YmdHis',$endTime);
            $where[] = "time >= {$starttime} AND time <= {$endtime}";
        }
        $select->where($where);
        $pager = new \Ku\Page($select, $page);
        $this->assign('pager', $pager);
        $this->assign('types', AdminlogMapper::$types);
        $this->assign('type', $type);
        $this->assign('startTime',$startTime ? date('Y-m-d H:i:s', $startTime):'');
        $this->assign('endTime', $endTime ? date('Y-m-d H:i:s', $endTime):'');
    }

}
