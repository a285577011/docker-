<?php

/**
 * 淘宝业务
 */
class TaobaoController extends \Base\AdminController {

    /**
     * 支付账单
     */
    public function payBillAction(){
        $dabModel = \Mapper\DeviceAlipayBillModel::getInstance();
        $order_sn = $this->getParam('order_sn');
        $amount_type = $this->getParam('amount_type');
        $time_range=$this->getParam('time_range');
        $startTime=$endTime='';
        if($time_range){
            list($startTime,$endTime)=explode('-',$time_range);
        }
        $imie = $this->getParam('imie');
        $page = abs((int)$this->getRequest()->get('page', 1));
        $limit=10;
        $where=[];
        if($order_sn){
            $where[] = "order_sn = {$order_sn}";
        }
        if($amount_type){
            $where[] = "amount_type = {$amount_type}";
        }
        if($imie){
            $where[] = "imie = {$imie}";
        }
        $startTime=strtotime($startTime);
        $endTime=strtotime($endTime);
        if($startTime && !$endTime) {
            $startTime=date('YmdHis',$startTime);
            $where[] = "pay_time >= {$startTime}";
        }elseif($endTime && !$startTime) {
            $endTime=date('YmdHis',$endTime);
            $where[] = "pay_time <= {$endTime}";
        }elseif($startTime && $endTime) {
            $startTime=date('YmdHis',$startTime);
            $endTime=date('YmdHis',$endTime);
            $where[] = "pay_time >= {$startTime} AND pay_time <= {$endTime}";
        }
        $offset=($page-1)*$limit;
        $data=$dabModel->fetchAllArray($where,'id desc',$limit,$offset);
        $amountTypeMap=[1=>'收入',2=>'支出',3=>'其他'];
        if($data){
            $arr=['1'=>'全部设备',2=>'指定设备'];
            $imieArr=array_column($data,'imie');
            $tbUser=\Mapper\TbuserModel::getInstance()->fetchAllArray(['imie'=>$imieArr]);
            $tbUser=array_column($tbUser,null,'imie');
            foreach ($data as $k=>$v){
                $data[$k]['pay_time']=date('Y-m-d H:i:s',strtotime($v['pay_time']));
                $data[$k]['amount_type_cn']=$amountTypeMap[$v['amount_type']];
                $data[$k]['detailArr']=json_decode($v['detail']);
                $data[$k]['userInfo']=$tbUser[$v['imie']];
            }
        }
        $total = (int)$dabModel->count($where);
        $totalPage = ceil($total / $limit);
        $this->assign('queryData', json_encode($this->getRequest()->getQuery()));
        $this->assign('datalist', json_encode($data));
        $this->assign('amountType', json_encode($amountTypeMap));
        $this->assign('page', $page);
        $this->assign('total', $total);
        $this->assign('totalPage', $totalPage);
        $this->assign('pageData', $data);
    }
}
