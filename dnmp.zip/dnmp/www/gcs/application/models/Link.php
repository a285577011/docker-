<?php

/**
 * 友链表
 * 
 * @Table Schema: gcs
 * @Table Name: link
 */
class LinkModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 标题
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_title = '';

    /**
     * 链接
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_url = '';

    /**
     * 链接内容
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_content = null;

    /**
     * 状态
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @var int
     */
    protected $_status = 0;

    /**
     * 添加时间
     * 
     * Column Type: bigint(14)
     * Default: 0
     * 
     * @var int
     */
    protected $_addtime = 0;

    /**
     * 更新时间
     * 
     * Column Type: bigint(14)
     * Default: 0
     * 
     * @var int
     */
    protected $_uptime = 0;

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \LinkModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 标题
     * 
     * Column Type: varchar(255)
     * 
     * @param string $title
     * @return \LinkModel
     */
    public function setTitle($title) {
        $this->_title = (string)$title;

        return $this;
    }

    /**
     * 标题
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getTitle() {
        return $this->_title;
    }

    /**
     * 链接
     * 
     * Column Type: varchar(255)
     * 
     * @param string $url
     * @return \LinkModel
     */
    public function setUrl($url) {
        $this->_url = (string)$url;

        return $this;
    }

    /**
     * 链接
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getUrl() {
        return $this->_url;
    }

    /**
     * 链接内容
     * 
     * Column Type: text
     * 
     * @param string $content
     * @return \LinkModel
     */
    public function setContent($content) {
        $this->_content = (string)$content;

        return $this;
    }

    /**
     * 链接内容
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getContent() {
        return $this->_content;
    }

    /**
     * 状态
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @param int $status
     * @return \LinkModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 状态
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * 添加时间
     * 
     * Column Type: bigint(14)
     * Default: 0
     * 
     * @param int $addtime
     * @return \LinkModel
     */
    public function setAddtime($addtime) {
        $this->_addtime = (int)$addtime;

        return $this;
    }

    /**
     * 添加时间
     * 
     * Column Type: bigint(14)
     * Default: 0
     * 
     * @return int
     */
    public function getAddtime() {
        return $this->_addtime;
    }

    /**
     * 更新时间
     * 
     * Column Type: bigint(14)
     * Default: 0
     * 
     * @param int $uptime
     * @return \LinkModel
     */
    public function setUptime($uptime) {
        $this->_uptime = (int)$uptime;

        return $this;
    }

    /**
     * 更新时间
     * 
     * Column Type: bigint(14)
     * Default: 0
     * 
     * @return int
     */
    public function getUptime() {
        return $this->_uptime;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'      => $this->_id,
            'title'   => $this->_title,
            'url'     => $this->_url,
            'content' => $this->_content,
            'status'  => $this->_status,
            'addtime' => $this->_addtime,
            'uptime'  => $this->_uptime
        );
    }

}
