<?php

/**
 * 网址信息表
 * 
 * @Table Schema: chajiechi
 * @Table Name: capture
 */
class CaptureModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 唯一值 md5(scheme://domain:port)
     * 
     * Column Type: varchar(32)
     * UNI
     * 
     * @var string
     */
    protected $_hash = null;

    /**
     * 全站唯一标识
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_object = null;

    /**
     * 顶级域名
     * 
     * Column Type: varchar(255)
     * MUL
     * 
     * @var string
     */
    protected $_domain = null;

    /**
     * 网页标题
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_title = null;

    /**
     * 网页关键字
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_keywords = null;

    /**
     * 网页描述
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_description = null;

    /**
     * 协议
     * 
     * Column Type: varchar(32)
     * Default: http
     * 
     * @var string
     */
    protected $_scheme = 'http';

    /**
     * 域名
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_host = null;

    /**
     * 端口
     * 
     * Column Type: smallint(5) unsigned
     * Default: 80
     * 
     * @var int
     */
    protected $_port = 80;

    /**
     * 路径
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_path = null;

    /**
     * 参数
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_query = null;

    /**
     * 定位
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_fragment = null;

    /**
     * 返回头部信息
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_header = null;

    /**
     * 跳转的地址
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_direct = null;

    /**
     * 缩略图1920*1080
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_thumbnail = null;

    /**
     * 截屏宽带1920
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_screen = null;

    /**
     * 网页源代码
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_source = null;

    /**
     * 返回码
     * 
     * Column Type: int(11) unsigned
     * 
     * @var int
     */
    protected $_code = null;

    /**
     * 外链
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_link = null;

    /**
     * 0启用 1禁用
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_status = 0;

    /**
     * 是否在最近访问中显示
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_visit = 0;

    /**
     * 是否在搜索中显示
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_search = 0;

    /**
     * 是否显示源码和截图
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_show = 0;

    /**
     * Addtime
     * 
     * Column Type: bigint(20) unsigned
     * 
     * @var int
     */
    protected $_addtime = null;

    /**
     * Uptime
     * 
     * Column Type: bigint(20) unsigned
     * 
     * @var int
     */
    protected $_uptime = null;

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \CaptureModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 唯一值 md5(scheme://domain:port)
     * 
     * Column Type: varchar(32)
     * UNI
     * 
     * @param string $hash
     * @return \CaptureModel
     */
    public function setHash($hash) {
        $this->_hash = (string)$hash;

        return $this;
    }

    /**
     * 唯一值 md5(scheme://domain:port)
     * 
     * Column Type: varchar(32)
     * UNI
     * 
     * @return string
     */
    public function getHash() {
        return $this->_hash;
    }

    /**
     * 全站唯一标识
     * 
     * Column Type: varchar(255)
     * 
     * @param string $object
     * @return \CaptureModel
     */
    public function setObject($object) {
        $this->_object = (string)$object;

        return $this;
    }

    /**
     * 全站唯一标识
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getObject() {
        return $this->_object;
    }

    /**
     * 顶级域名
     * 
     * Column Type: varchar(255)
     * MUL
     * 
     * @param string $domain
     * @return \CaptureModel
     */
    public function setDomain($domain) {
        $this->_domain = (string)$domain;

        return $this;
    }

    /**
     * 顶级域名
     * 
     * Column Type: varchar(255)
     * MUL
     * 
     * @return string
     */
    public function getDomain() {
        return $this->_domain;
    }

    /**
     * 网页标题
     * 
     * Column Type: text
     * 
     * @param string $title
     * @return \CaptureModel
     */
    public function setTitle($title) {
        $this->_title = (string)$title;

        return $this;
    }

    /**
     * 网页标题
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getTitle() {
        return $this->_title;
    }

    /**
     * 网页关键字
     * 
     * Column Type: text
     * 
     * @param string $keywords
     * @return \CaptureModel
     */
    public function setKeywords($keywords) {
        $this->_keywords = (string)$keywords;

        return $this;
    }

    /**
     * 网页关键字
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getKeywords() {
        return $this->_keywords;
    }

    /**
     * 网页描述
     * 
     * Column Type: text
     * 
     * @param string $description
     * @return \CaptureModel
     */
    public function setDescription($description) {
        $this->_description = (string)$description;

        return $this;
    }

    /**
     * 网页描述
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getDescription() {
        return $this->_description;
    }

    /**
     * 协议
     * 
     * Column Type: varchar(32)
     * Default: http
     * 
     * @param string $scheme
     * @return \CaptureModel
     */
    public function setScheme($scheme) {
        $this->_scheme = (string)$scheme;

        return $this;
    }

    /**
     * 协议
     * 
     * Column Type: varchar(32)
     * Default: http
     * 
     * @return string
     */
    public function getScheme() {
        return $this->_scheme;
    }

    /**
     * 域名
     * 
     * Column Type: varchar(255)
     * 
     * @param string $host
     * @return \CaptureModel
     */
    public function setHost($host) {
        $this->_host = (string)$host;

        return $this;
    }

    /**
     * 域名
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getHost() {
        return $this->_host;
    }

    /**
     * 端口
     * 
     * Column Type: smallint(5) unsigned
     * Default: 80
     * 
     * @param int $port
     * @return \CaptureModel
     */
    public function setPort($port) {
        $this->_port = (int)$port;

        return $this;
    }

    /**
     * 端口
     * 
     * Column Type: smallint(5) unsigned
     * Default: 80
     * 
     * @return int
     */
    public function getPort() {
        return $this->_port;
    }

    /**
     * 路径
     * 
     * Column Type: varchar(255)
     * 
     * @param string $path
     * @return \CaptureModel
     */
    public function setPath($path) {
        $this->_path = (string)$path;

        return $this;
    }

    /**
     * 路径
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getPath() {
        return $this->_path;
    }

    /**
     * 参数
     * 
     * Column Type: varchar(255)
     * 
     * @param string $query
     * @return \CaptureModel
     */
    public function setQuery($query) {
        $this->_query = (string)$query;

        return $this;
    }

    /**
     * 参数
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getQuery() {
        return $this->_query;
    }

    /**
     * 定位
     * 
     * Column Type: varchar(255)
     * 
     * @param string $fragment
     * @return \CaptureModel
     */
    public function setFragment($fragment) {
        $this->_fragment = (string)$fragment;

        return $this;
    }

    /**
     * 定位
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getFragment() {
        return $this->_fragment;
    }

    /**
     * 返回头部信息
     * 
     * Column Type: text
     * 
     * @param string $header
     * @return \CaptureModel
     */
    public function setHeader($header) {
        $this->_header = (string)$header;

        return $this;
    }

    /**
     * 返回头部信息
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getHeader() {
        return $this->_header;
    }

    /**
     * 跳转的地址
     * 
     * Column Type: varchar(255)
     * 
     * @param string $direct
     * @return \CaptureModel
     */
    public function setDirect($direct) {
        $this->_direct = (string)$direct;

        return $this;
    }

    /**
     * 跳转的地址
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getDirect() {
        return $this->_direct;
    }

    /**
     * 缩略图1920*1080
     * 
     * Column Type: varchar(255)
     * 
     * @param string $thumbnail
     * @return \CaptureModel
     */
    public function setThumbnail($thumbnail) {
        $this->_thumbnail = (string)$thumbnail;

        return $this;
    }

    /**
     * 缩略图1920*1080
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getThumbnail() {
        return $this->_thumbnail;
    }

    /**
     * 截屏宽带1920
     * 
     * Column Type: varchar(255)
     * 
     * @param string $screen
     * @return \CaptureModel
     */
    public function setScreen($screen) {
        $this->_screen = (string)$screen;

        return $this;
    }

    /**
     * 截屏宽带1920
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getScreen() {
        return $this->_screen;
    }

    /**
     * 网页源代码
     * 
     * Column Type: varchar(255)
     * 
     * @param string $source
     * @return \CaptureModel
     */
    public function setSource($source) {
        $this->_source = (string)$source;

        return $this;
    }

    /**
     * 网页源代码
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getSource() {
        return $this->_source;
    }

    /**
     * 返回码
     * 
     * Column Type: int(11) unsigned
     * 
     * @param int $code
     * @return \CaptureModel
     */
    public function setCode($code) {
        $this->_code = (int)$code;

        return $this;
    }

    /**
     * 返回码
     * 
     * Column Type: int(11) unsigned
     * 
     * @return int
     */
    public function getCode() {
        return $this->_code;
    }

    /**
     * 外链
     * 
     * Column Type: text
     * 
     * @param string $link
     * @return \CaptureModel
     */
    public function setLink($link) {
        $this->_link = (string)$link;

        return $this;
    }

    /**
     * 外链
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getLink() {
        return $this->_link;
    }

    /**
     * 0启用 1禁用
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * MUL
     * 
     * @param int $status
     * @return \CaptureModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 0启用 1禁用
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * 是否在最近访问中显示
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @param int $visit
     * @return \CaptureModel
     */
    public function setVisit($visit) {
        $this->_visit = (int)$visit;

        return $this;
    }

    /**
     * 是否在最近访问中显示
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getVisit() {
        return $this->_visit;
    }

    /**
     * 是否在搜索中显示
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @param int $search
     * @return \CaptureModel
     */
    public function setSearch($search) {
        $this->_search = (int)$search;

        return $this;
    }

    /**
     * 是否在搜索中显示
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getSearch() {
        return $this->_search;
    }

    /**
     * 是否显示源码和截图
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @param int $show
     * @return \CaptureModel
     */
    public function setShow($show) {
        $this->_show = (int)$show;

        return $this;
    }

    /**
     * 是否显示源码和截图
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getShow() {
        return $this->_show;
    }

    /**
     * Addtime
     * 
     * Column Type: bigint(20) unsigned
     * 
     * @param int $addtime
     * @return \CaptureModel
     */
    public function setAddtime($addtime) {
        $this->_addtime = (int)$addtime;

        return $this;
    }

    /**
     * Addtime
     * 
     * Column Type: bigint(20) unsigned
     * 
     * @return int
     */
    public function getAddtime() {
        return $this->_addtime;
    }

    /**
     * Uptime
     * 
     * Column Type: bigint(20) unsigned
     * 
     * @param int $uptime
     * @return \CaptureModel
     */
    public function setUptime($uptime) {
        $this->_uptime = (int)$uptime;

        return $this;
    }

    /**
     * Uptime
     * 
     * Column Type: bigint(20) unsigned
     * 
     * @return int
     */
    public function getUptime() {
        return $this->_uptime;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'          => $this->_id,
            'hash'        => $this->_hash,
            'object'      => $this->_object,
            'domain'      => $this->_domain,
            'title'       => $this->_title,
            'keywords'    => $this->_keywords,
            'description' => $this->_description,
            'scheme'      => $this->_scheme,
            'host'        => $this->_host,
            'port'        => $this->_port,
            'path'        => $this->_path,
            'query'       => $this->_query,
            'fragment'    => $this->_fragment,
            'header'      => $this->_header,
            'direct'      => $this->_direct,
            'thumbnail'   => $this->_thumbnail,
            'screen'      => $this->_screen,
            'source'      => $this->_source,
            'code'        => $this->_code,
            'link'        => $this->_link,
            'status'      => $this->_status,
            'visit'       => $this->_visit,
            'search'      => $this->_search,
            'show'        => $this->_show,
            'addtime'     => $this->_addtime,
            'uptime'      => $this->_uptime
        );
    }

}
