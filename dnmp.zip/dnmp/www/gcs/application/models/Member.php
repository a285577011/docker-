<?php

/**
 * Member
 * 
 * @Table Schema: gcs
 * @Table Name: member
 */
class MemberModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 用户名
     * 
     * Column Type: varchar(255)
     * MUL
     * 
     * @var string
     */
    protected $_username = '';

    /**
     * 名称
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_nickname = '';

    /**
     * 密码
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_password = '';

    /**
     * mobile
     * 
     * Column Type: varchar(25)
     * 
     * @var string
     */
    protected $_mobile = '';

    /**
     * 是否验证手机
     * 
     * Column Type: tinyint(1) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_mobileverify = 0;

    /**
     * 邮箱
     * 
     * Column Type: varchar(120)
     * MUL
     * 
     * @var string
     */
    protected $_email = '';

    /**
     * 是否验证邮箱
     * 
     * Column Type: tinyint(1) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_emailverify = 0;

    /**
     * 头像
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_avatar = '';

    /**
     * 禁止  1:禁止
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @var int
     */
    protected $_status = 0;

    /**
     * 时间
     * 
     * Column Type: bigint(20) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_addtime = 0;

    /**
     * 更新时间
     * 
     * Column Type: bigint(10)
     * Default: 0
     * 
     * @var int
     */
    protected $_uptime = 0;

    /**
     * Upip
     * 
     * Column Type: varchar(32)
     * 
     * @var string
     */
    protected $_upip = '';

    /**
     * 信用额度
     * 
     * Column Type: decimal(10,3) unsigned
     * Default: 0.000
     * 
     * @var float
     */
    protected $_freeze = 0.000;

    /**
     * 额度
     * 
     * Column Type: decimal(10,3) unsigned
     * Default: 0.000
     * 
     * @var float
     */
    protected $_point = 0.000;

    /**
     * 修改密码时间
     * 
     * Column Type: bigint(14) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_atime = 0;

    /**
     * 修改密码的用户id
     * 
     * Column Type: int(11) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_aid = 0;

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \MemberModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 用户名
     * 
     * Column Type: varchar(255)
     * MUL
     * 
     * @param string $username
     * @return \MemberModel
     */
    public function setUsername($username) {
        $this->_username = (string)$username;

        return $this;
    }

    /**
     * 用户名
     * 
     * Column Type: varchar(255)
     * MUL
     * 
     * @return string
     */
    public function getUsername() {
        return $this->_username;
    }

    /**
     * 名称
     * 
     * Column Type: varchar(255)
     * 
     * @param string $nickname
     * @return \MemberModel
     */
    public function setNickname($nickname) {
        $this->_nickname = (string)$nickname;

        return $this;
    }

    /**
     * 名称
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getNickname() {
        return $this->_nickname;
    }

    /**
     * 密码
     * 
     * Column Type: varchar(255)
     * 
     * @param string $password
     * @return \MemberModel
     */
    public function setPassword($password) {
        $this->_password = (string)$password;

        return $this;
    }

    /**
     * 密码
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getPassword() {
        return $this->_password;
    }

    /**
     * mobile
     * 
     * Column Type: varchar(25)
     * 
     * @param string $mobile
     * @return \MemberModel
     */
    public function setMobile($mobile) {
        $this->_mobile = (string)$mobile;

        return $this;
    }

    /**
     * mobile
     * 
     * Column Type: varchar(25)
     * 
     * @return string
     */
    public function getMobile() {
        return $this->_mobile;
    }

    /**
     * 是否验证手机
     * 
     * Column Type: tinyint(1) unsigned
     * Default: 0
     * 
     * @param int $mobileverify
     * @return \MemberModel
     */
    public function setMobileverify($mobileverify) {
        $this->_mobileverify = (int)$mobileverify;

        return $this;
    }

    /**
     * 是否验证手机
     * 
     * Column Type: tinyint(1) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getMobileverify() {
        return $this->_mobileverify;
    }

    /**
     * 邮箱
     * 
     * Column Type: varchar(120)
     * MUL
     * 
     * @param string $email
     * @return \MemberModel
     */
    public function setEmail($email) {
        $this->_email = (string)$email;

        return $this;
    }

    /**
     * 邮箱
     * 
     * Column Type: varchar(120)
     * MUL
     * 
     * @return string
     */
    public function getEmail() {
        return $this->_email;
    }

    /**
     * 是否验证邮箱
     * 
     * Column Type: tinyint(1) unsigned
     * Default: 0
     * 
     * @param int $emailverify
     * @return \MemberModel
     */
    public function setEmailverify($emailverify) {
        $this->_emailverify = (int)$emailverify;

        return $this;
    }

    /**
     * 是否验证邮箱
     * 
     * Column Type: tinyint(1) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getEmailverify() {
        return $this->_emailverify;
    }

    /**
     * 头像
     * 
     * Column Type: varchar(255)
     * 
     * @param string $avatar
     * @return \MemberModel
     */
    public function setAvatar($avatar) {
        $this->_avatar = (string)$avatar;

        return $this;
    }

    /**
     * 头像
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getAvatar() {
        return $this->_avatar;
    }

    /**
     * 禁止  1:禁止
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @param int $status
     * @return \MemberModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 禁止  1:禁止
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * 时间
     * 
     * Column Type: bigint(20) unsigned
     * Default: 0
     * 
     * @param int $addtime
     * @return \MemberModel
     */
    public function setAddtime($addtime) {
        $this->_addtime = (int)$addtime;

        return $this;
    }

    /**
     * 时间
     * 
     * Column Type: bigint(20) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getAddtime() {
        return $this->_addtime;
    }

    /**
     * 更新时间
     * 
     * Column Type: bigint(10)
     * Default: 0
     * 
     * @param int $uptime
     * @return \MemberModel
     */
    public function setUptime($uptime) {
        $this->_uptime = (int)$uptime;

        return $this;
    }

    /**
     * 更新时间
     * 
     * Column Type: bigint(10)
     * Default: 0
     * 
     * @return int
     */
    public function getUptime() {
        return $this->_uptime;
    }

    /**
     * Upip
     * 
     * Column Type: varchar(32)
     * 
     * @param string $upip
     * @return \MemberModel
     */
    public function setUpip($upip) {
        $this->_upip = (string)$upip;

        return $this;
    }

    /**
     * Upip
     * 
     * Column Type: varchar(32)
     * 
     * @return string
     */
    public function getUpip() {
        return $this->_upip;
    }

    /**
     * 信用额度
     * 
     * Column Type: decimal(10,3) unsigned
     * Default: 0.000
     * 
     * @param float $freeze
     * @return \MemberModel
     */
    public function setFreeze($freeze) {
        $this->_freeze = (float)$freeze;

        return $this;
    }

    /**
     * 信用额度
     * 
     * Column Type: decimal(10,3) unsigned
     * Default: 0.000
     * 
     * @return float
     */
    public function getFreeze() {
        return $this->_freeze;
    }

    /**
     * 额度
     * 
     * Column Type: decimal(10,3) unsigned
     * Default: 0.000
     * 
     * @param float $point
     * @return \MemberModel
     */
    public function setPoint($point) {
        $this->_point = (float)$point;

        return $this;
    }

    /**
     * 额度
     * 
     * Column Type: decimal(10,3) unsigned
     * Default: 0.000
     * 
     * @return float
     */
    public function getPoint() {
        return $this->_point;
    }

    /**
     * 修改密码时间
     * 
     * Column Type: bigint(14) unsigned
     * Default: 0
     * 
     * @param int $atime
     * @return \MemberModel
     */
    public function setAtime($atime) {
        $this->_atime = (int)$atime;

        return $this;
    }

    /**
     * 修改密码时间
     * 
     * Column Type: bigint(14) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getAtime() {
        return $this->_atime;
    }

    /**
     * 修改密码的用户id
     * 
     * Column Type: int(11) unsigned
     * Default: 0
     * 
     * @param int $aid
     * @return \MemberModel
     */
    public function setAid($aid) {
        $this->_aid = (int)$aid;

        return $this;
    }

    /**
     * 修改密码的用户id
     * 
     * Column Type: int(11) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getAid() {
        return $this->_aid;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'           => $this->_id,
            'username'     => $this->_username,
            'nickname'     => $this->_nickname,
            'password'     => $this->_password,
            'mobile'       => $this->_mobile,
            'mobileverify' => $this->_mobileverify,
            'email'        => $this->_email,
            'emailverify'  => $this->_emailverify,
            'avatar'       => $this->_avatar,
            'status'       => $this->_status,
            'addtime'      => $this->_addtime,
            'uptime'       => $this->_uptime,
            'upip'         => $this->_upip,
            'freeze'       => $this->_freeze,
            'point'        => $this->_point,
            'atime'        => $this->_atime,
            'aid'          => $this->_aid
        );
    }

}
