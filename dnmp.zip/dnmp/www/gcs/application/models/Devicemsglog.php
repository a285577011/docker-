<?php

/**
 * 设备消息记录
 * 
 * @Table Schema: gcs
 * @Table Name: device_msg_log
 */
class DevicemsglogModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Imie
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @var string
     */
    protected $_imie = null;

    /**
     * 1短信2alert通知
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @var int
     */
    protected $_type = 1;

    /**
     * Title
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_title = '';

    /**
     * Text
     * 
     * Column Type: varchar(500)
     * 
     * @var string
     */
    protected $_text = '';

    /**
     * App_name
     * 
     * Column Type: varchar(50)
     * 
     * @var string
     */
    protected $_app_name = '';

    /**
     * 消息内容
     * 
     * Column Type: json
     * 
     * @var string
     */
    protected $_content = null;

    /**
     * Msg_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_msg_time = 0;

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \DevicemsglogModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Imie
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @param string $imie
     * @return \DevicemsglogModel
     */
    public function setImie($imie) {
        $this->_imie = (string)$imie;

        return $this;
    }

    /**
     * Imie
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @return string
     */
    public function getImie() {
        return $this->_imie;
    }

    /**
     * 1短信2alert通知
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @param int $type
     * @return \DevicemsglogModel
     */
    public function setType($type) {
        $this->_type = (int)$type;

        return $this;
    }

    /**
     * 1短信2alert通知
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @return int
     */
    public function getType() {
        return $this->_type;
    }

    /**
     * Title
     * 
     * Column Type: varchar(255)
     * 
     * @param string $title
     * @return \DevicemsglogModel
     */
    public function setTitle($title) {
        $this->_title = (string)$title;

        return $this;
    }

    /**
     * Title
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getTitle() {
        return $this->_title;
    }

    /**
     * Text
     * 
     * Column Type: varchar(500)
     * 
     * @param string $text
     * @return \DevicemsglogModel
     */
    public function setText($text) {
        $this->_text = (string)$text;

        return $this;
    }

    /**
     * Text
     * 
     * Column Type: varchar(500)
     * 
     * @return string
     */
    public function getText() {
        return $this->_text;
    }

    /**
     * App_name
     * 
     * Column Type: varchar(50)
     * 
     * @param string $app_name
     * @return \DevicemsglogModel
     */
    public function setApp_name($app_name) {
        $this->_app_name = (string)$app_name;

        return $this;
    }

    /**
     * App_name
     * 
     * Column Type: varchar(50)
     * 
     * @return string
     */
    public function getApp_name() {
        return $this->_app_name;
    }

    /**
     * 消息内容
     * 
     * Column Type: json
     * 
     * @param string $content
     * @return \DevicemsglogModel
     */
    public function setContent($content) {
        $this->_content = (string)$content;

        return $this;
    }

    /**
     * 消息内容
     * 
     * Column Type: json
     * 
     * @return string
     */
    public function getContent() {
        return $this->_content;
    }

    /**
     * Msg_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @param int $msg_time
     * @return \DevicemsglogModel
     */
    public function setMsg_time($msg_time) {
        $this->_msg_time = (int)$msg_time;

        return $this;
    }

    /**
     * Msg_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getMsg_time() {
        return $this->_msg_time;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \DevicemsglogModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'       => $this->_id,
            'imie'     => $this->_imie,
            'type'     => $this->_type,
            'title'    => $this->_title,
            'text'     => $this->_text,
            'app_name' => $this->_app_name,
            'content'  => $this->_content,
            'msg_time' => $this->_msg_time,
            'c_time'   => $this->_c_time
        );
    }

}
