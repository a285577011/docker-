<?php

/**
 * 任务
 * 
 * @Table Schema: gcs
 * @Table Name: task
 */
class TaskModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 任务名称
     * 
     * Column Type: varchar(20)
     * 
     * @var string
     */
    protected $_name = null;

    /**
     * 任务key标识(对应的推送的分组标识)
     * 
     * Column Type: varchar(20)
     * MUL
     * 
     * @var string
     */
    protected $_key = null;

    /**
     * 任务参数json
     * 
     * Column Type: json
     * 
     * @var string
     */
    protected $_params_json = null;

    /**
     * 推送方式1全部2分组
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @var int
     */
    protected $_type = 1;

    /**
     * 1自动分配设备2手动分配设备
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @var int
     */
    protected $_auto = 1;

    /**
     * 备注
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_remark = '';

    /**
     * Admin_id
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_admin_id = '';

    /**
     * 独立设备重复任务的时间间隔(小时 0表示不可重复做)
     * 
     * Column Type: smallint(6)
     * Default: 1
     * 
     * @var int
     */
    protected $_time_limit = 1;

    /**
     * 任务数量（根据num_day 每几天执行的总数量 0代表到结束总数）-1不限制数量
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @var int
     */
    protected $_num = 0;

    /**
     * 限制IP段 X来表示限制
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_limit_ip = '';

    /**
     * 任务起始时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_s_time = 0;

    /**
     * 任务结束时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_e_time = 0;

    /**
     * 优先级 越大越高
     * 
     * Column Type: smallint(6)
     * Default: 0
     * 
     * @var int
     */
    protected $_sort = 0;

    /**
     * 1开启2关闭
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @var int
     */
    protected $_status = 1;

    /**
     * U_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * on update CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_u_time = 'CURRENT_TIMESTAMP';

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \TaskModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 任务名称
     * 
     * Column Type: varchar(20)
     * 
     * @param string $name
     * @return \TaskModel
     */
    public function setName($name) {
        $this->_name = (string)$name;

        return $this;
    }

    /**
     * 任务名称
     * 
     * Column Type: varchar(20)
     * 
     * @return string
     */
    public function getName() {
        return $this->_name;
    }

    /**
     * 任务key标识(对应的推送的分组标识)
     * 
     * Column Type: varchar(20)
     * MUL
     * 
     * @param string $key
     * @return \TaskModel
     */
    public function setKey($key) {
        $this->_key = (string)$key;

        return $this;
    }

    /**
     * 任务key标识(对应的推送的分组标识)
     * 
     * Column Type: varchar(20)
     * MUL
     * 
     * @return string
     */
    public function getKey() {
        return $this->_key;
    }

    /**
     * 任务参数json
     * 
     * Column Type: json
     * 
     * @param string $params_json
     * @return \TaskModel
     */
    public function setParams_json($params_json) {
        $this->_params_json = (string)$params_json;

        return $this;
    }

    /**
     * 任务参数json
     * 
     * Column Type: json
     * 
     * @return string
     */
    public function getParams_json() {
        return $this->_params_json;
    }

    /**
     * 推送方式1全部2分组
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @param int $type
     * @return \TaskModel
     */
    public function setType($type) {
        $this->_type = (int)$type;

        return $this;
    }

    /**
     * 推送方式1全部2分组
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @return int
     */
    public function getType() {
        return $this->_type;
    }

    /**
     * 1自动分配设备2手动分配设备
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @param int $auto
     * @return \TaskModel
     */
    public function setAuto($auto) {
        $this->_auto = (int)$auto;

        return $this;
    }

    /**
     * 1自动分配设备2手动分配设备
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @return int
     */
    public function getAuto() {
        return $this->_auto;
    }

    /**
     * 备注
     * 
     * Column Type: varchar(255)
     * 
     * @param string $remark
     * @return \TaskModel
     */
    public function setRemark($remark) {
        $this->_remark = (string)$remark;

        return $this;
    }

    /**
     * 备注
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getRemark() {
        return $this->_remark;
    }

    /**
     * Admin_id
     * 
     * Column Type: varchar(255)
     * 
     * @param string $admin_id
     * @return \TaskModel
     */
    public function setAdmin_id($admin_id) {
        $this->_admin_id = (string)$admin_id;

        return $this;
    }

    /**
     * Admin_id
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getAdmin_id() {
        return $this->_admin_id;
    }

    /**
     * 独立设备重复任务的时间间隔(小时 0表示不可重复做)
     * 
     * Column Type: smallint(6)
     * Default: 1
     * 
     * @param int $time_limit
     * @return \TaskModel
     */
    public function setTime_limit($time_limit) {
        $this->_time_limit = (int)$time_limit;

        return $this;
    }

    /**
     * 独立设备重复任务的时间间隔(小时 0表示不可重复做)
     * 
     * Column Type: smallint(6)
     * Default: 1
     * 
     * @return int
     */
    public function getTime_limit() {
        return $this->_time_limit;
    }

    /**
     * 任务数量（根据num_day 每几天执行的总数量 0代表到结束总数）-1不限制数量
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @param int $num
     * @return \TaskModel
     */
    public function setNum($num) {
        $this->_num = (int)$num;

        return $this;
    }

    /**
     * 任务数量（根据num_day 每几天执行的总数量 0代表到结束总数）-1不限制数量
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @return int
     */
    public function getNum() {
        return $this->_num;
    }

    /**
     * 限制IP段 X来表示限制
     * 
     * Column Type: varchar(255)
     * 
     * @param string $limit_ip
     * @return \TaskModel
     */
    public function setLimit_ip($limit_ip) {
        $this->_limit_ip = (string)$limit_ip;

        return $this;
    }

    /**
     * 限制IP段 X来表示限制
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getLimit_ip() {
        return $this->_limit_ip;
    }

    /**
     * 任务起始时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @param int $s_time
     * @return \TaskModel
     */
    public function setS_time($s_time) {
        $this->_s_time = (int)$s_time;

        return $this;
    }

    /**
     * 任务起始时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getS_time() {
        return $this->_s_time;
    }

    /**
     * 任务结束时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @param int $e_time
     * @return \TaskModel
     */
    public function setE_time($e_time) {
        $this->_e_time = (int)$e_time;

        return $this;
    }

    /**
     * 任务结束时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getE_time() {
        return $this->_e_time;
    }

    /**
     * 优先级 越大越高
     * 
     * Column Type: smallint(6)
     * Default: 0
     * 
     * @param int $sort
     * @return \TaskModel
     */
    public function setSort($sort) {
        $this->_sort = (int)$sort;

        return $this;
    }

    /**
     * 优先级 越大越高
     * 
     * Column Type: smallint(6)
     * Default: 0
     * 
     * @return int
     */
    public function getSort() {
        return $this->_sort;
    }

    /**
     * 1开启2关闭
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @param int $status
     * @return \TaskModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 1开启2关闭
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * U_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * on update CURRENT_TIMESTAMP
     * 
     * @param string $u_time
     * @return \TaskModel
     */
    public function setU_time($u_time) {
        $this->_u_time = (string)$u_time;

        return $this;
    }

    /**
     * U_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * on update CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getU_time() {
        return $this->_u_time;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \TaskModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'          => $this->_id,
            'name'        => $this->_name,
            'key'         => $this->_key,
            'params_json' => $this->_params_json,
            'type'        => $this->_type,
            'auto'        => $this->_auto,
            'remark'      => $this->_remark,
            'admin_id'    => $this->_admin_id,
            'time_limit'  => $this->_time_limit,
            'num'         => $this->_num,
            'limit_ip'    => $this->_limit_ip,
            's_time'      => $this->_s_time,
            'e_time'      => $this->_e_time,
            'sort'        => $this->_sort,
            'status'      => $this->_status,
            'u_time'      => $this->_u_time,
            'c_time'      => $this->_c_time
        );
    }

}
