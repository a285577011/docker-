<?php

/**
 * 积分流水表
 * 
 * @Table Schema: gcs
 * @Table Name: member_flow
 */
class MemberflowModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 分类
     * 
     * Column Type: varchar(64)
     * 
     * @var string
     */
    protected $_cate = null;

    /**
     * 操作对象id
     * 
     * Column Type: int(10) unsigned
     * MUL
     * 
     * @var int
     */
    protected $_mid = null;

    /**
     * 操作者id
     * 
     * Column Type: int(10) unsigned
     * MUL
     * 
     * @var int
     */
    protected $_aid = null;

    /**
     * 关联信息
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_attach = null;

    /**
     * 原冻结
     * 
     * Column Type: decimal(12,0)
     * 
     * @var float
     */
    protected $_freezeOld = null;

    /**
     * 新冻结
     * 
     * Column Type: decimal(12,0)
     * 
     * @var float
     */
    protected $_freezeNew = null;

    /**
     * 冻结改变值
     * 
     * Column Type: decimal(10,0)
     * 
     * @var float
     */
    protected $_freezeChange = null;

    /**
     * 原积分
     * 
     * Column Type: decimal(12,0)
     * 
     * @var float
     */
    protected $_pointOld = null;

    /**
     * 新积分
     * 
     * Column Type: decimal(12,0)
     * 
     * @var float
     */
    protected $_pointNew = null;

    /**
     * 积分改变值
     * 
     * Column Type: decimal(12,0)
     * 
     * @var float
     */
    protected $_pointChange = null;

    /**
     * ip地址
     * 
     * Column Type: varchar(32)
     * 
     * @var string
     */
    protected $_ip = null;

    /**
     * ip归属地
     * 
     * Column Type: varchar(64)
     * 
     * @var string
     */
    protected $_location = null;

    /**
     * 添加时间YYYYMMDDHHIISS
     * 
     * Column Type: bigint(14) unsigned
     * 
     * @var int
     */
    protected $_addtime = null;

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \MemberflowModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 分类
     * 
     * Column Type: varchar(64)
     * 
     * @param string $cate
     * @return \MemberflowModel
     */
    public function setCate($cate) {
        $this->_cate = (string)$cate;

        return $this;
    }

    /**
     * 分类
     * 
     * Column Type: varchar(64)
     * 
     * @return string
     */
    public function getCate() {
        return $this->_cate;
    }

    /**
     * 操作对象id
     * 
     * Column Type: int(10) unsigned
     * MUL
     * 
     * @param int $mid
     * @return \MemberflowModel
     */
    public function setMid($mid) {
        $this->_mid = (int)$mid;

        return $this;
    }

    /**
     * 操作对象id
     * 
     * Column Type: int(10) unsigned
     * MUL
     * 
     * @return int
     */
    public function getMid() {
        return $this->_mid;
    }

    /**
     * 操作者id
     * 
     * Column Type: int(10) unsigned
     * MUL
     * 
     * @param int $aid
     * @return \MemberflowModel
     */
    public function setAid($aid) {
        $this->_aid = (int)$aid;

        return $this;
    }

    /**
     * 操作者id
     * 
     * Column Type: int(10) unsigned
     * MUL
     * 
     * @return int
     */
    public function getAid() {
        return $this->_aid;
    }

    /**
     * 关联信息
     * 
     * Column Type: text
     * 
     * @param string $attach
     * @return \MemberflowModel
     */
    public function setAttach($attach) {
        $this->_attach = (string)$attach;

        return $this;
    }

    /**
     * 关联信息
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getAttach() {
        return $this->_attach;
    }

    /**
     * 原冻结
     * 
     * Column Type: decimal(12,0)
     * 
     * @param float $freezeOld
     * @return \MemberflowModel
     */
    public function setFreezeOld($freezeOld) {
        $this->_freezeOld = (float)$freezeOld;

        return $this;
    }

    /**
     * 原冻结
     * 
     * Column Type: decimal(12,0)
     * 
     * @return float
     */
    public function getFreezeOld() {
        return $this->_freezeOld;
    }

    /**
     * 新冻结
     * 
     * Column Type: decimal(12,0)
     * 
     * @param float $freezeNew
     * @return \MemberflowModel
     */
    public function setFreezeNew($freezeNew) {
        $this->_freezeNew = (float)$freezeNew;

        return $this;
    }

    /**
     * 新冻结
     * 
     * Column Type: decimal(12,0)
     * 
     * @return float
     */
    public function getFreezeNew() {
        return $this->_freezeNew;
    }

    /**
     * 冻结改变值
     * 
     * Column Type: decimal(10,0)
     * 
     * @param float $freezeChange
     * @return \MemberflowModel
     */
    public function setFreezeChange($freezeChange) {
        $this->_freezeChange = (float)$freezeChange;

        return $this;
    }

    /**
     * 冻结改变值
     * 
     * Column Type: decimal(10,0)
     * 
     * @return float
     */
    public function getFreezeChange() {
        return $this->_freezeChange;
    }

    /**
     * 原积分
     * 
     * Column Type: decimal(12,0)
     * 
     * @param float $pointOld
     * @return \MemberflowModel
     */
    public function setPointOld($pointOld) {
        $this->_pointOld = (float)$pointOld;

        return $this;
    }

    /**
     * 原积分
     * 
     * Column Type: decimal(12,0)
     * 
     * @return float
     */
    public function getPointOld() {
        return $this->_pointOld;
    }

    /**
     * 新积分
     * 
     * Column Type: decimal(12,0)
     * 
     * @param float $pointNew
     * @return \MemberflowModel
     */
    public function setPointNew($pointNew) {
        $this->_pointNew = (float)$pointNew;

        return $this;
    }

    /**
     * 新积分
     * 
     * Column Type: decimal(12,0)
     * 
     * @return float
     */
    public function getPointNew() {
        return $this->_pointNew;
    }

    /**
     * 积分改变值
     * 
     * Column Type: decimal(12,0)
     * 
     * @param float $pointChange
     * @return \MemberflowModel
     */
    public function setPointChange($pointChange) {
        $this->_pointChange = (float)$pointChange;

        return $this;
    }

    /**
     * 积分改变值
     * 
     * Column Type: decimal(12,0)
     * 
     * @return float
     */
    public function getPointChange() {
        return $this->_pointChange;
    }

    /**
     * ip地址
     * 
     * Column Type: varchar(32)
     * 
     * @param string $ip
     * @return \MemberflowModel
     */
    public function setIp($ip) {
        $this->_ip = (string)$ip;

        return $this;
    }

    /**
     * ip地址
     * 
     * Column Type: varchar(32)
     * 
     * @return string
     */
    public function getIp() {
        return $this->_ip;
    }

    /**
     * ip归属地
     * 
     * Column Type: varchar(64)
     * 
     * @param string $location
     * @return \MemberflowModel
     */
    public function setLocation($location) {
        $this->_location = (string)$location;

        return $this;
    }

    /**
     * ip归属地
     * 
     * Column Type: varchar(64)
     * 
     * @return string
     */
    public function getLocation() {
        return $this->_location;
    }

    /**
     * 添加时间YYYYMMDDHHIISS
     * 
     * Column Type: bigint(14) unsigned
     * 
     * @param int $addtime
     * @return \MemberflowModel
     */
    public function setAddtime($addtime) {
        $this->_addtime = (int)$addtime;

        return $this;
    }

    /**
     * 添加时间YYYYMMDDHHIISS
     * 
     * Column Type: bigint(14) unsigned
     * 
     * @return int
     */
    public function getAddtime() {
        return $this->_addtime;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'           => $this->_id,
            'cate'         => $this->_cate,
            'mid'          => $this->_mid,
            'aid'          => $this->_aid,
            'attach'       => $this->_attach,
            'freezeOld'    => $this->_freezeOld,
            'freezeNew'    => $this->_freezeNew,
            'freezeChange' => $this->_freezeChange,
            'pointOld'     => $this->_pointOld,
            'pointNew'     => $this->_pointNew,
            'pointChange'  => $this->_pointChange,
            'ip'           => $this->_ip,
            'location'     => $this->_location,
            'addtime'      => $this->_addtime
        );
    }

}
