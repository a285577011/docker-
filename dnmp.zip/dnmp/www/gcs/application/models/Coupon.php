<?php

/**
 * 优惠券券码表
 * 
 * @Table Schema: gcs
 * @Table Name: coupon
 */
class CouponModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 券码
     * 
     * Column Type: varchar(255)
     * UNI
     * 
     * @var string
     */
    protected $_code = null;

    /**
     * 1兑换券 2打折券 3满减券 4满送券
     * 
     * Column Type: tinyint(3) unsigned
     * 
     * @var int
     */
    protected $_type = null;

    /**
     * 1兑换券-兑换的积分 2打折券-金额打折数 3满减券-扣减的金额 4满送券-赠送积分
     * 
     * Column Type: decimal(10,2) unsigned
     * 
     * @var float
     */
    protected $_content = null;

    /**
     * 券码说明
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_intro = null;

    /**
     * 0有效 1无效
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 1
     * 
     * @var int
     */
    protected $_status = 1;

    /**
     * 最大使用次数
     * 
     * Column Type: int(10) unsigned
     * Default: 1
     * 
     * @var int
     */
    protected $_max = 1;

    /**
     * 已使用次数
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_use = 0;

    /**
     * 限制使用的用户id，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_mid = 0;

    /**
     * Total_fee
     * 
     * Column Type: decimal(10,2)
     * 
     * @var float
     */
    protected $_total_fee = null;

    /**
     * Pay_from
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_pay_from = null;

    /**
     * 使用开始时间限制，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_starttime = 0;

    /**
     * 使用结束时间限制，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_endtime = 0;

    /**
     * Addtime
     * 
     * Column Type: int(10) unsigned
     * 
     * @var int
     */
    protected $_addtime = null;

    /**
     * Uptime
     * 
     * Column Type: int(10) unsigned
     * 
     * @var int
     */
    protected $_uptime = null;

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \CouponModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 券码
     * 
     * Column Type: varchar(255)
     * UNI
     * 
     * @param string $code
     * @return \CouponModel
     */
    public function setCode($code) {
        $this->_code = (string)$code;

        return $this;
    }

    /**
     * 券码
     * 
     * Column Type: varchar(255)
     * UNI
     * 
     * @return string
     */
    public function getCode() {
        return $this->_code;
    }

    /**
     * 1兑换券 2打折券 3满减券 4满送券
     * 
     * Column Type: tinyint(3) unsigned
     * 
     * @param int $type
     * @return \CouponModel
     */
    public function setType($type) {
        $this->_type = (int)$type;

        return $this;
    }

    /**
     * 1兑换券 2打折券 3满减券 4满送券
     * 
     * Column Type: tinyint(3) unsigned
     * 
     * @return int
     */
    public function getType() {
        return $this->_type;
    }

    /**
     * 1兑换券-兑换的积分 2打折券-金额打折数 3满减券-扣减的金额 4满送券-赠送积分
     * 
     * Column Type: decimal(10,2) unsigned
     * 
     * @param float $content
     * @return \CouponModel
     */
    public function setContent($content) {
        $this->_content = (float)$content;

        return $this;
    }

    /**
     * 1兑换券-兑换的积分 2打折券-金额打折数 3满减券-扣减的金额 4满送券-赠送积分
     * 
     * Column Type: decimal(10,2) unsigned
     * 
     * @return float
     */
    public function getContent() {
        return $this->_content;
    }

    /**
     * 券码说明
     * 
     * Column Type: text
     * 
     * @param string $intro
     * @return \CouponModel
     */
    public function setIntro($intro) {
        $this->_intro = (string)$intro;

        return $this;
    }

    /**
     * 券码说明
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getIntro() {
        return $this->_intro;
    }

    /**
     * 0有效 1无效
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 1
     * 
     * @param int $status
     * @return \CouponModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 0有效 1无效
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 1
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * 最大使用次数
     * 
     * Column Type: int(10) unsigned
     * Default: 1
     * 
     * @param int $max
     * @return \CouponModel
     */
    public function setMax($max) {
        $this->_max = (int)$max;

        return $this;
    }

    /**
     * 最大使用次数
     * 
     * Column Type: int(10) unsigned
     * Default: 1
     * 
     * @return int
     */
    public function getMax() {
        return $this->_max;
    }

    /**
     * 已使用次数
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @param int $use
     * @return \CouponModel
     */
    public function setUse($use) {
        $this->_use = (int)$use;

        return $this;
    }

    /**
     * 已使用次数
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getUse() {
        return $this->_use;
    }

    /**
     * 限制使用的用户id，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @param int $mid
     * @return \CouponModel
     */
    public function setMid($mid) {
        $this->_mid = (int)$mid;

        return $this;
    }

    /**
     * 限制使用的用户id，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getMid() {
        return $this->_mid;
    }

    /**
     * Total_fee
     * 
     * Column Type: decimal(10,2)
     * 
     * @param float $total_fee
     * @return \CouponModel
     */
    public function setTotal_fee($total_fee) {
        $this->_total_fee = (float)$total_fee;

        return $this;
    }

    /**
     * Total_fee
     * 
     * Column Type: decimal(10,2)
     * 
     * @return float
     */
    public function getTotal_fee() {
        return $this->_total_fee;
    }

    /**
     * Pay_from
     * 
     * Column Type: varchar(255)
     * 
     * @param string $pay_from
     * @return \CouponModel
     */
    public function setPay_from($pay_from) {
        $this->_pay_from = (string)$pay_from;

        return $this;
    }

    /**
     * Pay_from
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getPay_from() {
        return $this->_pay_from;
    }

    /**
     * 使用开始时间限制，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @param int $starttime
     * @return \CouponModel
     */
    public function setStarttime($starttime) {
        $this->_starttime = (int)$starttime;

        return $this;
    }

    /**
     * 使用开始时间限制，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getStarttime() {
        return $this->_starttime;
    }

    /**
     * 使用结束时间限制，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @param int $endtime
     * @return \CouponModel
     */
    public function setEndtime($endtime) {
        $this->_endtime = (int)$endtime;

        return $this;
    }

    /**
     * 使用结束时间限制，0默认不限制
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getEndtime() {
        return $this->_endtime;
    }

    /**
     * Addtime
     * 
     * Column Type: int(10) unsigned
     * 
     * @param int $addtime
     * @return \CouponModel
     */
    public function setAddtime($addtime) {
        $this->_addtime = (int)$addtime;

        return $this;
    }

    /**
     * Addtime
     * 
     * Column Type: int(10) unsigned
     * 
     * @return int
     */
    public function getAddtime() {
        return $this->_addtime;
    }

    /**
     * Uptime
     * 
     * Column Type: int(10) unsigned
     * 
     * @param int $uptime
     * @return \CouponModel
     */
    public function setUptime($uptime) {
        $this->_uptime = (int)$uptime;

        return $this;
    }

    /**
     * Uptime
     * 
     * Column Type: int(10) unsigned
     * 
     * @return int
     */
    public function getUptime() {
        return $this->_uptime;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'        => $this->_id,
            'code'      => $this->_code,
            'type'      => $this->_type,
            'content'   => $this->_content,
            'intro'     => $this->_intro,
            'status'    => $this->_status,
            'max'       => $this->_max,
            'use'       => $this->_use,
            'mid'       => $this->_mid,
            'total_fee' => $this->_total_fee,
            'pay_from'  => $this->_pay_from,
            'starttime' => $this->_starttime,
            'endtime'   => $this->_endtime,
            'addtime'   => $this->_addtime,
            'uptime'    => $this->_uptime
        );
    }

}
