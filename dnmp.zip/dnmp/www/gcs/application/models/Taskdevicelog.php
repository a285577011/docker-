<?php

/**
 * 任务设备执行记录
 * 
 * @Table Schema: gcs
 * @Table Name: task_device_log
 */
class TaskdevicelogModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Device_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @var int
     */
    protected $_device_id = 0;

    /**
     * 任务执行记录
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @var int
     */
    protected $_task_id = 0;

    /**
     * 1设备已接受9取消10完成
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @var int
     */
    protected $_status = 1;

    /**
     * U_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @var int
     */
    protected $_u_time = 0;

    /**
     * C_time
     * 
     * Column Type: bigint(20)
     * MUL
     * 
     * @var int
     */
    protected $_c_time = null;

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \TaskdevicelogModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Device_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @param int $device_id
     * @return \TaskdevicelogModel
     */
    public function setDevice_id($device_id) {
        $this->_device_id = (int)$device_id;

        return $this;
    }

    /**
     * Device_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @return int
     */
    public function getDevice_id() {
        return $this->_device_id;
    }

    /**
     * 任务执行记录
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @param int $task_id
     * @return \TaskdevicelogModel
     */
    public function setTask_id($task_id) {
        $this->_task_id = (int)$task_id;

        return $this;
    }

    /**
     * 任务执行记录
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @return int
     */
    public function getTask_id() {
        return $this->_task_id;
    }

    /**
     * 1设备已接受9取消10完成
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @param int $status
     * @return \TaskdevicelogModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 1设备已接受9取消10完成
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * U_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @param int $u_time
     * @return \TaskdevicelogModel
     */
    public function setU_time($u_time) {
        $this->_u_time = (int)$u_time;

        return $this;
    }

    /**
     * U_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @return int
     */
    public function getU_time() {
        return $this->_u_time;
    }

    /**
     * C_time
     * 
     * Column Type: bigint(20)
     * MUL
     * 
     * @param int $c_time
     * @return \TaskdevicelogModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (int)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: bigint(20)
     * MUL
     * 
     * @return int
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'        => $this->_id,
            'device_id' => $this->_device_id,
            'task_id'   => $this->_task_id,
            'status'    => $this->_status,
            'u_time'    => $this->_u_time,
            'c_time'    => $this->_c_time
        );
    }

}
