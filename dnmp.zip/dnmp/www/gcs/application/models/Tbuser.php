<?php

/**
 * 淘宝用户信息
 * 
 * @Table Schema: gcs
 * @Table Name: tb_user
 */
class TbuserModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Imie
     * 
     * Column Type: varchar(20)
     * UNI
     * 
     * @var string
     */
    protected $_imie = '';

    /**
     * Account
     * 
     * Column Type: varchar(50)
     * 
     * @var string
     */
    protected $_account = '';

    /**
     * Nick
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_nick = '';

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \TbuserModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Imie
     * 
     * Column Type: varchar(20)
     * UNI
     * 
     * @param string $imie
     * @return \TbuserModel
     */
    public function setImie($imie) {
        $this->_imie = (string)$imie;

        return $this;
    }

    /**
     * Imie
     * 
     * Column Type: varchar(20)
     * UNI
     * 
     * @return string
     */
    public function getImie() {
        return $this->_imie;
    }

    /**
     * Account
     * 
     * Column Type: varchar(50)
     * 
     * @param string $account
     * @return \TbuserModel
     */
    public function setAccount($account) {
        $this->_account = (string)$account;

        return $this;
    }

    /**
     * Account
     * 
     * Column Type: varchar(50)
     * 
     * @return string
     */
    public function getAccount() {
        return $this->_account;
    }

    /**
     * Nick
     * 
     * Column Type: varchar(255)
     * 
     * @param string $nick
     * @return \TbuserModel
     */
    public function setNick($nick) {
        $this->_nick = (string)$nick;

        return $this;
    }

    /**
     * Nick
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getNick() {
        return $this->_nick;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \TbuserModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'      => $this->_id,
            'imie'    => $this->_imie,
            'account' => $this->_account,
            'nick'    => $this->_nick,
            'c_time'  => $this->_c_time
        );
    }

}
