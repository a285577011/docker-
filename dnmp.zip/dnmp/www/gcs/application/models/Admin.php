<?php

/**
 * 管理员
 * 
 * @Table Schema: gcs
 * @Table Name: admin
 */
class AdminModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: tinyint(3) unsigned
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Email
     * 
     * Column Type: varchar(64)
     * 
     * @var string
     */
    protected $_email = '';

    /**
     * Name
     * 
     * Column Type: varchar(45)
     * 
     * @var string
     */
    protected $_name = '';

    /**
     * Password
     * 
     * Column Type: varchar(128)
     * 
     * @var string
     */
    protected $_password = '';

    /**
     * 禁用
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @var int
     */
    protected $_disabled = 0;

    /**
     * Ip
     * 
     * Column Type: varchar(45)
     * 
     * @var string
     */
    protected $_ip = '';

    /**
     * Time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @var int
     */
    protected $_time = 0;

    /**
     * 管理员隶属组别
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_group_id = 0;

    /**
     * 最后登录时间
     * 
     * Column Type: bigint(16)
     * Default: 0
     * 
     * @var int
     */
    protected $_lastlogintime = 0;

    /**
     * Id
     * 
     * Column Type: tinyint(3) unsigned
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \AdminModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: tinyint(3) unsigned
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Email
     * 
     * Column Type: varchar(64)
     * 
     * @param string $email
     * @return \AdminModel
     */
    public function setEmail($email) {
        $this->_email = (string)$email;

        return $this;
    }

    /**
     * Email
     * 
     * Column Type: varchar(64)
     * 
     * @return string
     */
    public function getEmail() {
        return $this->_email;
    }

    /**
     * Name
     * 
     * Column Type: varchar(45)
     * 
     * @param string $name
     * @return \AdminModel
     */
    public function setName($name) {
        $this->_name = (string)$name;

        return $this;
    }

    /**
     * Name
     * 
     * Column Type: varchar(45)
     * 
     * @return string
     */
    public function getName() {
        return $this->_name;
    }

    /**
     * Password
     * 
     * Column Type: varchar(128)
     * 
     * @param string $password
     * @return \AdminModel
     */
    public function setPassword($password) {
        $this->_password = (string)$password;

        return $this;
    }

    /**
     * Password
     * 
     * Column Type: varchar(128)
     * 
     * @return string
     */
    public function getPassword() {
        return $this->_password;
    }

    /**
     * 禁用
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @param int $disabled
     * @return \AdminModel
     */
    public function setDisabled($disabled) {
        $this->_disabled = (int)$disabled;

        return $this;
    }

    /**
     * 禁用
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @return int
     */
    public function getDisabled() {
        return $this->_disabled;
    }

    /**
     * Ip
     * 
     * Column Type: varchar(45)
     * 
     * @param string $ip
     * @return \AdminModel
     */
    public function setIp($ip) {
        $this->_ip = (string)$ip;

        return $this;
    }

    /**
     * Ip
     * 
     * Column Type: varchar(45)
     * 
     * @return string
     */
    public function getIp() {
        return $this->_ip;
    }

    /**
     * Time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @param int $time
     * @return \AdminModel
     */
    public function setTime($time) {
        $this->_time = (int)$time;

        return $this;
    }

    /**
     * Time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @return int
     */
    public function getTime() {
        return $this->_time;
    }

    /**
     * 管理员隶属组别
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @param int $group_id
     * @return \AdminModel
     */
    public function setGroup_id($group_id) {
        $this->_group_id = (int)$group_id;

        return $this;
    }

    /**
     * 管理员隶属组别
     * 
     * Column Type: tinyint(3) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getGroup_id() {
        return $this->_group_id;
    }

    /**
     * 最后登录时间
     * 
     * Column Type: bigint(16)
     * Default: 0
     * 
     * @param int $lastlogintime
     * @return \AdminModel
     */
    public function setLastlogintime($lastlogintime) {
        $this->_lastlogintime = (int)$lastlogintime;

        return $this;
    }

    /**
     * 最后登录时间
     * 
     * Column Type: bigint(16)
     * Default: 0
     * 
     * @return int
     */
    public function getLastlogintime() {
        return $this->_lastlogintime;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'            => $this->_id,
            'email'         => $this->_email,
            'name'          => $this->_name,
            'password'      => $this->_password,
            'disabled'      => $this->_disabled,
            'ip'            => $this->_ip,
            'time'          => $this->_time,
            'group_id'      => $this->_group_id,
            'lastlogintime' => $this->_lastlogintime
        );
    }

}
