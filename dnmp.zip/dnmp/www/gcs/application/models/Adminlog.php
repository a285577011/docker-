<?php

/**
 * 后台日志
 * 
 * @Table Schema: gcs
 * @Table Name: admin_log
 */
class AdminlogModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Log
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_log = null;

    /**
     * Time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @var int
     */
    protected $_time = 0;

    /**
     * 日志类型 
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @var int
     */
    protected $_type = 0;

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \AdminlogModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Log
     * 
     * Column Type: text
     * 
     * @param string $log
     * @return \AdminlogModel
     */
    public function setLog($log) {
        $this->_log = (string)$log;

        return $this;
    }

    /**
     * Log
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getLog() {
        return $this->_log;
    }

    /**
     * Time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @param int $time
     * @return \AdminlogModel
     */
    public function setTime($time) {
        $this->_time = (int)$time;

        return $this;
    }

    /**
     * Time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @return int
     */
    public function getTime() {
        return $this->_time;
    }

    /**
     * 日志类型 
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @param int $type
     * @return \AdminlogModel
     */
    public function setType($type) {
        $this->_type = (int)$type;

        return $this;
    }

    /**
     * 日志类型 
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @return int
     */
    public function getType() {
        return $this->_type;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'   => $this->_id,
            'log'  => $this->_log,
            'time' => $this->_time,
            'type' => $this->_type
        );
    }

}
