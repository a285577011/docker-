<?php

/**
 * 任务执行记录
 * 
 * @Table Schema: gcs
 * @Table Name: task_log
 */
class TasklogModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Task_id
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @var int
     */
    protected $_task_id = 0;

    /**
     * 执行状态0,未发送1发送成功
     * 
     * Column Type: tinyint(4)
     * Default: 0
     * 
     * @var int
     */
    protected $_status = 0;

    /**
     * C_timestamp
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @var int
     */
    protected $_c_timestamp = 0;

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \TasklogModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Task_id
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @param int $task_id
     * @return \TasklogModel
     */
    public function setTask_id($task_id) {
        $this->_task_id = (int)$task_id;

        return $this;
    }

    /**
     * Task_id
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @return int
     */
    public function getTask_id() {
        return $this->_task_id;
    }

    /**
     * 执行状态0,未发送1发送成功
     * 
     * Column Type: tinyint(4)
     * Default: 0
     * 
     * @param int $status
     * @return \TasklogModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 执行状态0,未发送1发送成功
     * 
     * Column Type: tinyint(4)
     * Default: 0
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * C_timestamp
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @param int $c_timestamp
     * @return \TasklogModel
     */
    public function setC_timestamp($c_timestamp) {
        $this->_c_timestamp = (int)$c_timestamp;

        return $this;
    }

    /**
     * C_timestamp
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @return int
     */
    public function getC_timestamp() {
        return $this->_c_timestamp;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \TasklogModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'          => $this->_id,
            'task_id'     => $this->_task_id,
            'status'      => $this->_status,
            'c_timestamp' => $this->_c_timestamp,
            'c_time'      => $this->_c_time
        );
    }

}
