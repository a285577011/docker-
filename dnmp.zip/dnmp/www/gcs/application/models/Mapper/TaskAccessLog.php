<?php
namespace Mapper;

class TaskAccessLogModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'task_access_log';
}