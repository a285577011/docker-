<?php
namespace Mapper;

class TbuserModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'tb_user';
}