<?php
namespace Mapper;

class CaptureModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'capture';
}