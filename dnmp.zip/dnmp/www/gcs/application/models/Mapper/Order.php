<?php
namespace Mapper;

class OrderModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'order';
}