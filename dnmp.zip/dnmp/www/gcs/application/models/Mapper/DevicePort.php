<?php
namespace Mapper;

class DevicePortModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'device_port';
}