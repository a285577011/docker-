<?php

namespace Mapper;

/**
 * 用户
 */
class AdmingroupModel extends \Mapper\AbstractModel {

   use \Base\Model\InstanceModel;
   protected $table = 'admin_group';

    /**
     * 获取所有管理员组
     * @return array
     */
    public function getAll(){
        $records = $this->fetchAll();
        $all = array();
        foreach ($records as $model){
            $all[$model->getId()] = $model->getGroup_name();
        }
        return $all;
    }

}
