<?php
namespace Mapper;

class DeviceModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'device';
}