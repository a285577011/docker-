<?php
namespace Mapper;

class DevicetaskModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'device_task';
}