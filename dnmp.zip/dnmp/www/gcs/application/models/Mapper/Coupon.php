<?php
namespace Mapper;

class CouponModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'coupon';
}