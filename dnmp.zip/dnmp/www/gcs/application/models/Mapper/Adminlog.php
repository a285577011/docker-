<?php

namespace Mapper;

/**
 * 管理员日志
 */
class AdminlogModel extends \Mapper\AbstractModel {

    use \Base\Model\InstanceModel;

    const UNKNOW = 0x00;
    const LOGIN = 0x01;
    const MANAGE = 0x02;
    const MENBER = 0x03;
    const GROUP = 0x04;

    public static $types = [
        self::UNKNOW=>'未知',
        self::LOGIN=>'登录',
        self::MANAGE=>'系统管理',
        self::MENBER=>'用户管理',
        self::GROUP=>'群组管理'
    ];

    protected $table = 'admin_log';


    //日志
    public function log($message, $type = self::UNKNOW){
        $log = new \AdminlogModel();
        $log->setType($type);
        $log->setLog($message);
        $log->setTime(date('YmdHis', time()));
        try{
            $this->insert($log);
            return true;
        }catch (\ErrorException $e){
            return false;
        }
    }
}
