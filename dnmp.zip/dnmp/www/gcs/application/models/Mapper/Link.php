<?php
namespace Mapper;

class LinkModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'link';
}