<?php
namespace Mapper;

class DeviceMsgLogModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'device_msg_log';
}