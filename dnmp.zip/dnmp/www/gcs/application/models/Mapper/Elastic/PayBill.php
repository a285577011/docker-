<?php

namespace Mapper\Elastic;


use Es\ElasticBaseModel;

/**
 */
class PayBillModel extends ElasticBaseModel
{
    protected $esIndexName = 'device_alipay_bill';

    public function search($conditions = array(), $offset = 0, $limit = 20, $columns = array(), $order = array('field' => 'userid', 'sort' => 'desc'))
    {
        $es = new \Es\ElasticBaseModel();
        $data = $es->searchQuery($conditions, $offset, $columns, $order);
        return $data;
    }
}

?>