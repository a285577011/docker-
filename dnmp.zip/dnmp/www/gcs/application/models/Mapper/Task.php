<?php

namespace Mapper;

class TaskModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;
    const JP_APPKEY = '34b7940d1028ac36ce2911c9';
    const JP_APPSECRET = '215aa47e28e5f4054521e76c';
    const TASK_STATUS=['tb_order'=>[0=>'任务发送失败',1=>'任务已发送',2=>'任务完成']];
    protected $table = 'task';
}