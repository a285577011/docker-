<?php
namespace Mapper;

class memberflowModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'member_flow';
}