<?php
namespace Mapper;

class TaskresulturlModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'task_result_url';
}