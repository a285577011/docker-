<?php
namespace Mapper;

class TaskDeviceLogModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'task_device_log';
}