<?php

namespace Mapper;

class MemberModel extends \Mapper\AbstractModel {
    
    use \Base\Model\InstanceModel;
    
    protected $table = 'member';
    
    
    
    /**
     * 用户最后登录
     *
     * @param \MemberModel $memberModel
     * @return int
     */
    public function updateLogin(\MemberModel $memberModel) {
        $memberModel->setUpip(\Ku\Tool::getClientIp(false, true));
        $memberModel->setUptime(date('YmdHis'));

        try {
            $effer = $this->update($memberModel);
        } catch (\Exception $ex) {
            $effer = 0;
        }

        return $effer;
    }

    /**
     * Member 用户注册
     *
     * @param \MemberModel $memberModel
     * @return int
     */
    public function reg(\MemberModel $memberModel) {
        $this->begin();
        $lastIp = $memberModel->getUpip();

        if (empty($lastIp)) {
            $memberModel->setUpip(\Ku\Tool::getClientIp(false, true));
        }

        $memberModel->setAddtime(date('YmdHis'));
        $memberModel->setUptime(date('YmdHis'));
        
        try {
            $mid = $this->insert($memberModel);
            $this->commit();
        } catch (\Exception $ex) {
            $this->rollback();
            return 0;
        }
        return $mid;
    }


    /**
     * 更新用户资料
     *
     * @param \MemberModel $model
     * @return boolean
     */
    public function updateProfile(\MemberModel $model) {
        $model->setUptime(date("YmdHis"));

        $this->begin();

        try {
            $effer = (int) ($this->update($model));
        } catch (\Exception $ex) {
            $effer = 0;
        }

        ($effer === 1) ? $this->commit() : $this->rollback();

        return ($effer === 1) ? true : false;
    }
    
    /**
     * 三级修改状态
     * @param type $status 原值，0启用，其他值为禁用
     * @param type $s1 系统，true启用，false禁用，null默认
     * @param type $s2 总代理，true启用，false禁用，null默认
     * @param type $s3 代理，true启用，false禁用，null默认
     * @return type
     */
    public function status3Change($status=0, $s1=null, $s2=null, $s3=null) {
        $data = (~$status & 0b111);
        if($s1===true){
            $data = $data | 0b100;
        }elseif($s1===false){
            $data = $data & 0b011;
        }
        if($s2===true){
            $data = $data | 0b10;
        }elseif($s2===false){
            $data = $data & 0b101;
        }
        if($s3===true){
            $data = $data | 0b1;
        }elseif($s3===false){
            $data = $data & 0b110;
        }
        return (~$data & 0b111);
    }
    
    /**
     * 三级状态返回
     * @param type $status
     * @return type 返回系统，总代理，代理：true启用，false禁用
     */
    public function status3($status) {
            $s1 = ($status & 0b100) > 0 ? false : true;
            $s2 = ($status & 0b10) > 0 ? false : true;
            $s3 = ($status & 0b1) > 0 ? false : true;
  
            return [$s1,$s2,$s3];
    }

}

