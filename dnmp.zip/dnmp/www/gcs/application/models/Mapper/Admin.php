<?php

namespace Mapper;
use Ku\Tool;

/**
 * 用户
 */
class AdminModel extends \Mapper\AbstractModel {

    use \Base\Model\InstanceModel;

    protected $table = 'admin';
    

    /**
     * 更新用户的登录信息
     *
     * @param \AdminModel $adminModel
     * @return boolean
     */
    public function upLoginInfo(\AdminModel $adminModel) {
        $adminModel->setLastlogintime(date('YmdHis'));
        $adminModel->setIp(Tool::getClientIp());
        try {
            $this->update($adminModel);
        } catch (\Exception $exc) {
            return false;
        }
        return true;
    }

    /**
     * 加密密码
     *
     * @param string $password  未加密的密码
     * @return string
     */
    static public function password($password) {
        return password_hash($password, PASSWORD_DEFAULT);
    }

}
