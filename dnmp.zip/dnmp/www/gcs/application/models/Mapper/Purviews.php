<?php

namespace Mapper;
/**
 * 权限模型
 */
class PurviewsModel extends \Mapper\AbstractModel {
     use \Base\Model\InstanceModel;
    
    protected $table = 'purviews';

    protected $admingroupModel = null;


    public function setAdminGroupModel($admingroupModel){
        $this->admingroupModel = $admingroupModel;
        return $this;
    }

    /**
     * 获取当前菜单的所有子菜单选项
     * @param int $parentid
     * @param array $menus
     * @param string $tag 显示标签
     * @return array
     */
    public function menus($parentid = 0, $menus = array(),$tag = '|-') {
        $result = $this->fetchAll(array('parent' => $parentid), array('reorder DESC'));
        if ($result) {
            foreach ($result as $record) {
                $menus[$record->getId()] = $tag.$record->getMenu_name();
                $menus = $this->menus($record->getId(), $menus,'&nbsp;&nbsp;&nbsp;&nbsp;'.$tag);
            }
        }
        return $menus;
    }

    /**
     * 获取当前菜单的所有子菜单选项
     * @param int $parentid
     * @param array $menus
     * @return array
     */
    public function findChirdren($parentid = 0, $menus = array(),$level = 0) {
        $result = $this->fetchAll(array('parent = ?' => $parentid), array('reorder DESC'));
        if ($result) {
            foreach ($result as $key =>$record){
                $tag = '';
                if($level){
                    for($i = 1;$i<=$level;$i++){
                        if($i<$level){
                            $tag.='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;│';
                        }
                        if($i == $level){
                            if( $key+1 == count($result)){
                                $tag .= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─';
                            }else{
                                $tag .= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;├─';
                            }
                        }
                    }
                }
                $record->setMenu_name($tag.$record->getMenu_name());
                $menus[] = $record;
                $menus = $this->findChirdren($record->getId(), $menus,$level+1);
            }
        }
        return $menus;
    }
    

    public function getAll($parentid = 0,$menus = array(),$level = 1){
       $result = $this->fetchAll(array('parent = ?' => $parentid), array('reorder DESC'));
        if ($result) {
            foreach ($result as $key =>$record){
                $recordArr = $record->toArray();
                $recordArr['level'] = $level;
                $menus[] = $recordArr;
                $menus = $this->getAll($record->getId(), $menus,$level+1);
            }
        }
        return $menus;
    }

    /**
     * 获取展示菜单
     */
    public function getMenus($isHidden = 1){
        $result = $this->getAll();
        $menus = [];
        if(!$this->admingroupModel instanceof \AdmingroupModel){
            return $menus;
        }
        if ($result) {
            $purviewArr = \json_decode($this->admingroupModel->getPurview(), true);
            foreach ($result as $key =>$record){
                if($isHidden == 1 && $record['isshow'] == 0){
                    continue;
                }
                if($this->admingroupModel->getId() != 1 && !in_array($record['id'], $purviewArr))
                    continue;
                if($record['level'] == 1){
                    $menus[] = $record;
                }else if($record['level'] == 2){
                    $k1 = count($menus)-1;
                    $level2 = isset($menus[$k1]['son'])?$menus[$k1]['son']:[];
                    $menus[$k1]['son'] = array_merge($level2, [$record]);
                }else if($record['level'] == 3){
                    $k1 = count($menus)-1;
                    $k2 = count($menus[$k1]['son'])-1;
                    $level3 = isset($menus[$k1]['son'][$k2]['son'])?$menus[$k1]['son'][$k2]['son']:[];
                    $menus[$k1]['son'][$k2]['son'] = array_merge($level3, [$record]);
                }
            }
        }
        return $menus;
    }

    /**
     * 是否权限
     */
    public function isPurview($module, $controller, $action){
        if(!$this->admingroupModel instanceof \AdmingroupModel){
            return false;
        }
        if($this->admingroupModel->getId() == 1){
            return true;
        }
        $purviewArr = \json_decode($this->admingroupModel->getPurview(), true);
        $purviewsModel = $this->fetch(['module'=>$module, 'controller'=>$controller, 'action'=>$action]);
        if($purviewsModel instanceof \purviewsModel){
            $purviewArr = \json_decode($this->admingroupModel->getPurview(), true);
            if(in_array($purviewsModel->getId(), $purviewArr))
                return true;
        }
        return false;
    }

}