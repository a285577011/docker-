<?php
namespace Mapper;

class DeviceAlipayBillModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'device_alipay_bill';
}