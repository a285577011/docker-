<?php
namespace Mapper;

class TaskLogModel extends \Mapper\AbstractModel
{
    use \Base\Model\InstanceModel;

    protected $table = 'task_log';
}