<?php

/**
 * 手机设备数据
 * 
 * @Table Schema: gcs
 * @Table Name: device
 */
class DeviceModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 名称
     * 
     * Column Type: varchar(50)
     * 
     * @var string
     */
    protected $_name = '';

    /**
     * 设备唯一标识
     * 
     * Column Type: varchar(20)
     * UNI
     * 
     * @var string
     */
    protected $_imie = '';

    /**
     * 推送唯一ID
     * 
     * Column Type: varchar(33)
     * 
     * @var string
     */
    protected $_reg_id = '';

    /**
     * Ip
     * 
     * Column Type: varchar(16)
     * 
     * @var string
     */
    protected $_ip = '';

    /**
     * Phone
     * 
     * Column Type: varchar(20)
     * 
     * @var string
     */
    protected $_phone = '';

    /**
     * 上次任务执行时间（判断权重）
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @var int
     */
    protected $_task_time = 0;

    /**
     * 1任务空闲2任务繁忙
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @var int
     */
    protected $_task_status = 1;

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \DeviceModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 名称
     * 
     * Column Type: varchar(50)
     * 
     * @param string $name
     * @return \DeviceModel
     */
    public function setName($name) {
        $this->_name = (string)$name;

        return $this;
    }

    /**
     * 名称
     * 
     * Column Type: varchar(50)
     * 
     * @return string
     */
    public function getName() {
        return $this->_name;
    }

    /**
     * 设备唯一标识
     * 
     * Column Type: varchar(20)
     * UNI
     * 
     * @param string $imie
     * @return \DeviceModel
     */
    public function setImie($imie) {
        $this->_imie = (string)$imie;

        return $this;
    }

    /**
     * 设备唯一标识
     * 
     * Column Type: varchar(20)
     * UNI
     * 
     * @return string
     */
    public function getImie() {
        return $this->_imie;
    }

    /**
     * 推送唯一ID
     * 
     * Column Type: varchar(33)
     * 
     * @param string $reg_id
     * @return \DeviceModel
     */
    public function setReg_id($reg_id) {
        $this->_reg_id = (string)$reg_id;

        return $this;
    }

    /**
     * 推送唯一ID
     * 
     * Column Type: varchar(33)
     * 
     * @return string
     */
    public function getReg_id() {
        return $this->_reg_id;
    }

    /**
     * Ip
     * 
     * Column Type: varchar(16)
     * 
     * @param string $ip
     * @return \DeviceModel
     */
    public function setIp($ip) {
        $this->_ip = (string)$ip;

        return $this;
    }

    /**
     * Ip
     * 
     * Column Type: varchar(16)
     * 
     * @return string
     */
    public function getIp() {
        return $this->_ip;
    }

    /**
     * Phone
     * 
     * Column Type: varchar(20)
     * 
     * @param string $phone
     * @return \DeviceModel
     */
    public function setPhone($phone) {
        $this->_phone = (string)$phone;

        return $this;
    }

    /**
     * Phone
     * 
     * Column Type: varchar(20)
     * 
     * @return string
     */
    public function getPhone() {
        return $this->_phone;
    }

    /**
     * 上次任务执行时间（判断权重）
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @param int $task_time
     * @return \DeviceModel
     */
    public function setTask_time($task_time) {
        $this->_task_time = (int)$task_time;

        return $this;
    }

    /**
     * 上次任务执行时间（判断权重）
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @return int
     */
    public function getTask_time() {
        return $this->_task_time;
    }

    /**
     * 1任务空闲2任务繁忙
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @param int $task_status
     * @return \DeviceModel
     */
    public function setTask_status($task_status) {
        $this->_task_status = (int)$task_status;

        return $this;
    }

    /**
     * 1任务空闲2任务繁忙
     * 
     * Column Type: tinyint(4)
     * Default: 1
     * 
     * @return int
     */
    public function getTask_status() {
        return $this->_task_status;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \DeviceModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'          => $this->_id,
            'name'        => $this->_name,
            'imie'        => $this->_imie,
            'reg_id'      => $this->_reg_id,
            'ip'          => $this->_ip,
            'phone'       => $this->_phone,
            'task_time'   => $this->_task_time,
            'task_status' => $this->_task_status,
            'c_time'      => $this->_c_time
        );
    }

}
