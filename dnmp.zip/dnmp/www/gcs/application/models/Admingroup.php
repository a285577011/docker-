<?php

/**
 * 管理员组role
 * 
 * @Table Schema: gcs
 * @Table Name: admin_group
 */
class AdmingroupModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(3) unsigned
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Group_name
     * 
     * Column Type: varchar(45)
     * 
     * @var string
     */
    protected $_group_name = '';

    /**
     * 禁用
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @var int
     */
    protected $_disabled = 0;

    /**
     * 权限ID
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_purview = '';

    /**
     * Id
     * 
     * Column Type: int(3) unsigned
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \AdmingroupModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(3) unsigned
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Group_name
     * 
     * Column Type: varchar(45)
     * 
     * @param string $group_name
     * @return \AdmingroupModel
     */
    public function setGroup_name($group_name) {
        $this->_group_name = (string)$group_name;

        return $this;
    }

    /**
     * Group_name
     * 
     * Column Type: varchar(45)
     * 
     * @return string
     */
    public function getGroup_name() {
        return $this->_group_name;
    }

    /**
     * 禁用
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @param int $disabled
     * @return \AdmingroupModel
     */
    public function setDisabled($disabled) {
        $this->_disabled = (int)$disabled;

        return $this;
    }

    /**
     * 禁用
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @return int
     */
    public function getDisabled() {
        return $this->_disabled;
    }

    /**
     * 权限ID
     * 
     * Column Type: varchar(255)
     * 
     * @param string $purview
     * @return \AdmingroupModel
     */
    public function setPurview($purview) {
        $this->_purview = (string)$purview;

        return $this;
    }

    /**
     * 权限ID
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getPurview() {
        return $this->_purview;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'         => $this->_id,
            'group_name' => $this->_group_name,
            'disabled'   => $this->_disabled,
            'purview'    => $this->_purview
        );
    }

}
