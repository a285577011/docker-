<?php

/**
 * 权限表
 * 
 * @Table Schema: gcs
 * @Table Name: purviews
 */
class PurviewsModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 菜单名称
     * 
     * Column Type: varchar(45)
     * 
     * @var string
     */
    protected $_menu_name = '';

    /**
     * Module
     * 
     * Column Type: varchar(20)
     * 
     * @var string
     */
    protected $_module = '';

    /**
     * 排序
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @var int
     */
    protected $_reorder = 0;

    /**
     * Controller
     * 
     * Column Type: varchar(40)
     * 
     * @var string
     */
    protected $_controller = '';

    /**
     * Action
     * 
     * Column Type: varchar(40)
     * 
     * @var string
     */
    protected $_action = '';

    /**
     * 功能组
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @var int
     */
    protected $_parent = 0;

    /**
     * 是否显示在菜单栏
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @var int
     */
    protected $_isshow = 0;

    /**
     * Css
     * 
     * Column Type: varchar(20)
     * 
     * @var string
     */
    protected $_css = '';

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \PurviewsModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 菜单名称
     * 
     * Column Type: varchar(45)
     * 
     * @param string $menu_name
     * @return \PurviewsModel
     */
    public function setMenu_name($menu_name) {
        $this->_menu_name = (string)$menu_name;

        return $this;
    }

    /**
     * 菜单名称
     * 
     * Column Type: varchar(45)
     * 
     * @return string
     */
    public function getMenu_name() {
        return $this->_menu_name;
    }

    /**
     * Module
     * 
     * Column Type: varchar(20)
     * 
     * @param string $module
     * @return \PurviewsModel
     */
    public function setModule($module) {
        $this->_module = (string)$module;

        return $this;
    }

    /**
     * Module
     * 
     * Column Type: varchar(20)
     * 
     * @return string
     */
    public function getModule() {
        return $this->_module;
    }

    /**
     * 排序
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @param int $reorder
     * @return \PurviewsModel
     */
    public function setReorder($reorder) {
        $this->_reorder = (int)$reorder;

        return $this;
    }

    /**
     * 排序
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @return int
     */
    public function getReorder() {
        return $this->_reorder;
    }

    /**
     * Controller
     * 
     * Column Type: varchar(40)
     * 
     * @param string $controller
     * @return \PurviewsModel
     */
    public function setController($controller) {
        $this->_controller = (string)$controller;

        return $this;
    }

    /**
     * Controller
     * 
     * Column Type: varchar(40)
     * 
     * @return string
     */
    public function getController() {
        return $this->_controller;
    }

    /**
     * Action
     * 
     * Column Type: varchar(40)
     * 
     * @param string $action
     * @return \PurviewsModel
     */
    public function setAction($action) {
        $this->_action = (string)$action;

        return $this;
    }

    /**
     * Action
     * 
     * Column Type: varchar(40)
     * 
     * @return string
     */
    public function getAction() {
        return $this->_action;
    }

    /**
     * 功能组
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @param int $parent
     * @return \PurviewsModel
     */
    public function setParent($parent) {
        $this->_parent = (int)$parent;

        return $this;
    }

    /**
     * 功能组
     * 
     * Column Type: int(11)
     * Default: 0
     * 
     * @return int
     */
    public function getParent() {
        return $this->_parent;
    }

    /**
     * 是否显示在菜单栏
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @param int $isshow
     * @return \PurviewsModel
     */
    public function setIsshow($isshow) {
        $this->_isshow = (int)$isshow;

        return $this;
    }

    /**
     * 是否显示在菜单栏
     * 
     * Column Type: tinyint(1)
     * Default: 0
     * 
     * @return int
     */
    public function getIsshow() {
        return $this->_isshow;
    }

    /**
     * Css
     * 
     * Column Type: varchar(20)
     * 
     * @param string $css
     * @return \PurviewsModel
     */
    public function setCss($css) {
        $this->_css = (string)$css;

        return $this;
    }

    /**
     * Css
     * 
     * Column Type: varchar(20)
     * 
     * @return string
     */
    public function getCss() {
        return $this->_css;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'         => $this->_id,
            'menu_name'  => $this->_menu_name,
            'module'     => $this->_module,
            'reorder'    => $this->_reorder,
            'controller' => $this->_controller,
            'action'     => $this->_action,
            'parent'     => $this->_parent,
            'isshow'     => $this->_isshow,
            'css'        => $this->_css
        );
    }

}
