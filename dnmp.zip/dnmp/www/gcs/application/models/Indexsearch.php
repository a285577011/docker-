<?php

/**
 * 记录搜索引擎索引最后更新id
 * 
 * @Table Schema: chajiechi
 * @Table Name: indexsearch
 */
class IndexsearchModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 搜索的库名
     * 
     * Column Type: varchar(255)
     * UNI
     * 
     * @var string
     */
    protected $_project = null;

    /**
     * 最后更新的id
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_lastid = 0;

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * PRI
     * 
     * @param int $id
     * @return \IndexsearchModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10) unsigned
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 搜索的库名
     * 
     * Column Type: varchar(255)
     * UNI
     * 
     * @param string $project
     * @return \IndexsearchModel
     */
    public function setProject($project) {
        $this->_project = (string)$project;

        return $this;
    }

    /**
     * 搜索的库名
     * 
     * Column Type: varchar(255)
     * UNI
     * 
     * @return string
     */
    public function getProject() {
        return $this->_project;
    }

    /**
     * 最后更新的id
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @param int $lastid
     * @return \IndexsearchModel
     */
    public function setLastid($lastid) {
        $this->_lastid = (int)$lastid;

        return $this;
    }

    /**
     * 最后更新的id
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getLastid() {
        return $this->_lastid;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'      => $this->_id,
            'project' => $this->_project,
            'lastid'  => $this->_lastid
        );
    }

}
