<?php

/**
 * 任务上报记录
 * 
 * @Table Schema: gcs
 * @Table Name: task_access_log
 */
class TaskaccesslogModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Device_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @var int
     */
    protected $_device_id = 0;

    /**
     * 任务记录ID
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @var int
     */
    protected $_task_device_log_id = 0;

    /**
     * Status
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @var int
     */
    protected $_status = 0;

    /**
     * Remark
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_remark = '';

    /**
     * C_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @var int
     */
    protected $_c_time = 0;

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \TaskaccesslogModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Device_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @param int $device_id
     * @return \TaskaccesslogModel
     */
    public function setDevice_id($device_id) {
        $this->_device_id = (int)$device_id;

        return $this;
    }

    /**
     * Device_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @return int
     */
    public function getDevice_id() {
        return $this->_device_id;
    }

    /**
     * 任务记录ID
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @param int $task_device_log_id
     * @return \TaskaccesslogModel
     */
    public function setTask_device_log_id($task_device_log_id) {
        $this->_task_device_log_id = (int)$task_device_log_id;

        return $this;
    }

    /**
     * 任务记录ID
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @return int
     */
    public function getTask_device_log_id() {
        return $this->_task_device_log_id;
    }

    /**
     * Status
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @param int $status
     * @return \TaskaccesslogModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * Status
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * Remark
     * 
     * Column Type: varchar(255)
     * 
     * @param string $remark
     * @return \TaskaccesslogModel
     */
    public function setRemark($remark) {
        $this->_remark = (string)$remark;

        return $this;
    }

    /**
     * Remark
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getRemark() {
        return $this->_remark;
    }

    /**
     * C_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @param int $c_time
     * @return \TaskaccesslogModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (int)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: bigint(20)
     * Default: 0
     * 
     * @return int
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'                 => $this->_id,
            'device_id'          => $this->_device_id,
            'task_device_log_id' => $this->_task_device_log_id,
            'status'             => $this->_status,
            'remark'             => $this->_remark,
            'c_time'             => $this->_c_time
        );
    }

}
