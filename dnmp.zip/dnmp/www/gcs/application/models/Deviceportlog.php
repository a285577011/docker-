<?php

/**
 * 设备端口连接记录表
 * 
 * @Table Schema: gcs
 * @Table Name: device_port_log
 */
class DeviceportlogModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Device_port_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @var int
     */
    protected $_device_port_id = 0;

    /**
     * Port
     * 
     * Column Type: mediumint(8)
     * Default: 0
     * 
     * @var int
     */
    protected $_port = 0;

    /**
     * 所属frps服务,stf服务器
     * 
     * Column Type: varchar(50)
     * 
     * @var string
     */
    protected $_server = '';

    /**
     * 1客户机连接frps2stf连接frps
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @var int
     */
    protected $_type = 0;

    /**
     * 1连接2断开连接
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @var int
     */
    protected $_status = 0;

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \DeviceportlogModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Device_port_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @param int $device_port_id
     * @return \DeviceportlogModel
     */
    public function setDevice_port_id($device_port_id) {
        $this->_device_port_id = (int)$device_port_id;

        return $this;
    }

    /**
     * Device_port_id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @return int
     */
    public function getDevice_port_id() {
        return $this->_device_port_id;
    }

    /**
     * Port
     * 
     * Column Type: mediumint(8)
     * Default: 0
     * 
     * @param int $port
     * @return \DeviceportlogModel
     */
    public function setPort($port) {
        $this->_port = (int)$port;

        return $this;
    }

    /**
     * Port
     * 
     * Column Type: mediumint(8)
     * Default: 0
     * 
     * @return int
     */
    public function getPort() {
        return $this->_port;
    }

    /**
     * 所属frps服务,stf服务器
     * 
     * Column Type: varchar(50)
     * 
     * @param string $server
     * @return \DeviceportlogModel
     */
    public function setServer($server) {
        $this->_server = (string)$server;

        return $this;
    }

    /**
     * 所属frps服务,stf服务器
     * 
     * Column Type: varchar(50)
     * 
     * @return string
     */
    public function getServer() {
        return $this->_server;
    }

    /**
     * 1客户机连接frps2stf连接frps
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @param int $type
     * @return \DeviceportlogModel
     */
    public function setType($type) {
        $this->_type = (int)$type;

        return $this;
    }

    /**
     * 1客户机连接frps2stf连接frps
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @return int
     */
    public function getType() {
        return $this->_type;
    }

    /**
     * 1连接2断开连接
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @param int $status
     * @return \DeviceportlogModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 1连接2断开连接
     * 
     * Column Type: tinyint(3)
     * Default: 0
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \DeviceportlogModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'             => $this->_id,
            'device_port_id' => $this->_device_port_id,
            'port'           => $this->_port,
            'server'         => $this->_server,
            'type'           => $this->_type,
            'status'         => $this->_status,
            'c_time'         => $this->_c_time
        );
    }

}
