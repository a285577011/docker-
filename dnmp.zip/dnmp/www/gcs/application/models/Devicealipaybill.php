<?php

/**
 * 设备支付宝账单
 * 
 * @Table Schema: gcs
 * @Table Name: device_alipay_bill
 */
class DevicealipaybillModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Imie
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @var string
     */
    protected $_imie = '';

    /**
     * 订单编号
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @var string
     */
    protected $_order_sn = null;

    /**
     * 金额
     * 
     * Column Type: decimal(12,2) unsigned
     * 
     * @var float
     */
    protected $_amount = null;

    /**
     * 金额类型1支付2收入3未知
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @var int
     */
    protected $_amount_type = 1;

    /**
     * 交易对象
     * 
     * Column Type: varchar(50)
     * 
     * @var string
     */
    protected $_trade_to = null;

    /**
     * 交易时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_pay_time = 0;

    /**
     * Detail
     * 
     * Column Type: json
     * 
     * @var string
     */
    protected $_detail = null;

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \DevicealipaybillModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Imie
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @param string $imie
     * @return \DevicealipaybillModel
     */
    public function setImie($imie) {
        $this->_imie = (string)$imie;

        return $this;
    }

    /**
     * Imie
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @return string
     */
    public function getImie() {
        return $this->_imie;
    }

    /**
     * 订单编号
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @param string $order_sn
     * @return \DevicealipaybillModel
     */
    public function setOrder_sn($order_sn) {
        $this->_order_sn = (string)$order_sn;

        return $this;
    }

    /**
     * 订单编号
     * 
     * Column Type: varchar(50)
     * MUL
     * 
     * @return string
     */
    public function getOrder_sn() {
        return $this->_order_sn;
    }

    /**
     * 金额
     * 
     * Column Type: decimal(12,2) unsigned
     * 
     * @param float $amount
     * @return \DevicealipaybillModel
     */
    public function setAmount($amount) {
        $this->_amount = (float)$amount;

        return $this;
    }

    /**
     * 金额
     * 
     * Column Type: decimal(12,2) unsigned
     * 
     * @return float
     */
    public function getAmount() {
        return $this->_amount;
    }

    /**
     * 金额类型1支付2收入3未知
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @param int $amount_type
     * @return \DevicealipaybillModel
     */
    public function setAmount_type($amount_type) {
        $this->_amount_type = (int)$amount_type;

        return $this;
    }

    /**
     * 金额类型1支付2收入3未知
     * 
     * Column Type: tinyint(3)
     * Default: 1
     * 
     * @return int
     */
    public function getAmount_type() {
        return $this->_amount_type;
    }

    /**
     * 交易对象
     * 
     * Column Type: varchar(50)
     * 
     * @param string $trade_to
     * @return \DevicealipaybillModel
     */
    public function setTrade_to($trade_to) {
        $this->_trade_to = (string)$trade_to;

        return $this;
    }

    /**
     * 交易对象
     * 
     * Column Type: varchar(50)
     * 
     * @return string
     */
    public function getTrade_to() {
        return $this->_trade_to;
    }

    /**
     * 交易时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @param int $pay_time
     * @return \DevicealipaybillModel
     */
    public function setPay_time($pay_time) {
        $this->_pay_time = (int)$pay_time;

        return $this;
    }

    /**
     * 交易时间
     * 
     * Column Type: bigint(20)
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getPay_time() {
        return $this->_pay_time;
    }

    /**
     * Detail
     * 
     * Column Type: json
     * 
     * @param string $detail
     * @return \DevicealipaybillModel
     */
    public function setDetail($detail) {
        $this->_detail = (string)$detail;

        return $this;
    }

    /**
     * Detail
     * 
     * Column Type: json
     * 
     * @return string
     */
    public function getDetail() {
        return $this->_detail;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \DevicealipaybillModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'          => $this->_id,
            'imie'        => $this->_imie,
            'order_sn'    => $this->_order_sn,
            'amount'      => $this->_amount,
            'amount_type' => $this->_amount_type,
            'trade_to'    => $this->_trade_to,
            'pay_time'    => $this->_pay_time,
            'detail'      => $this->_detail,
            'c_time'      => $this->_c_time
        );
    }

}
