<?php

/**
 * 设备对应任务组(多对多)
 * 
 * @Table Schema: gcs
 * @Table Name: device_task
 */
class DevicetaskModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Task_id
     * 
     * Column Type: int(11)
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_task_id = 0;

    /**
     * Device_id
     * 
     * Column Type: int(11)
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_device_id = 0;

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \DevicetaskModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Task_id
     * 
     * Column Type: int(11)
     * Default: 0
     * MUL
     * 
     * @param int $task_id
     * @return \DevicetaskModel
     */
    public function setTask_id($task_id) {
        $this->_task_id = (int)$task_id;

        return $this;
    }

    /**
     * Task_id
     * 
     * Column Type: int(11)
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getTask_id() {
        return $this->_task_id;
    }

    /**
     * Device_id
     * 
     * Column Type: int(11)
     * Default: 0
     * MUL
     * 
     * @param int $device_id
     * @return \DevicetaskModel
     */
    public function setDevice_id($device_id) {
        $this->_device_id = (int)$device_id;

        return $this;
    }

    /**
     * Device_id
     * 
     * Column Type: int(11)
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getDevice_id() {
        return $this->_device_id;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \DevicetaskModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'        => $this->_id,
            'task_id'   => $this->_task_id,
            'device_id' => $this->_device_id,
            'c_time'    => $this->_c_time
        );
    }

}
