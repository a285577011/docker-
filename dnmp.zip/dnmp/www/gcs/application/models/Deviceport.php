<?php

/**
 * 设备对应端口数据
 * 
 * @Table Schema: gcs
 * @Table Name: device_port
 */
class DeviceportModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * 所属frps服务,stf服务器
     * 
     * Column Type: varchar(50)
     * 
     * @var string
     */
    protected $_server = '';

    /**
     * 设备id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @var int
     */
    protected $_device_id = 0;

    /**
     * Port
     * 
     * Column Type: int(10)
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_port = 0;

    /**
     * 1未连接2已连接frps3已连接stf
     * 
     * Column Type: int(10)
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_status = 0;

    /**
     * U_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * on update CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_u_time = 'CURRENT_TIMESTAMP';

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @var string
     */
    protected $_c_time = 'CURRENT_TIMESTAMP';

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \DeviceportModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(10)
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * 所属frps服务,stf服务器
     * 
     * Column Type: varchar(50)
     * 
     * @param string $server
     * @return \DeviceportModel
     */
    public function setServer($server) {
        $this->_server = (string)$server;

        return $this;
    }

    /**
     * 所属frps服务,stf服务器
     * 
     * Column Type: varchar(50)
     * 
     * @return string
     */
    public function getServer() {
        return $this->_server;
    }

    /**
     * 设备id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @param int $device_id
     * @return \DeviceportModel
     */
    public function setDevice_id($device_id) {
        $this->_device_id = (int)$device_id;

        return $this;
    }

    /**
     * 设备id
     * 
     * Column Type: int(10)
     * Default: 0
     * 
     * @return int
     */
    public function getDevice_id() {
        return $this->_device_id;
    }

    /**
     * Port
     * 
     * Column Type: int(10)
     * Default: 0
     * MUL
     * 
     * @param int $port
     * @return \DeviceportModel
     */
    public function setPort($port) {
        $this->_port = (int)$port;

        return $this;
    }

    /**
     * Port
     * 
     * Column Type: int(10)
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getPort() {
        return $this->_port;
    }

    /**
     * 1未连接2已连接frps3已连接stf
     * 
     * Column Type: int(10)
     * Default: 0
     * MUL
     * 
     * @param int $status
     * @return \DeviceportModel
     */
    public function setStatus($status) {
        $this->_status = (int)$status;

        return $this;
    }

    /**
     * 1未连接2已连接frps3已连接stf
     * 
     * Column Type: int(10)
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * U_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * on update CURRENT_TIMESTAMP
     * 
     * @param string $u_time
     * @return \DeviceportModel
     */
    public function setU_time($u_time) {
        $this->_u_time = (string)$u_time;

        return $this;
    }

    /**
     * U_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * on update CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getU_time() {
        return $this->_u_time;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @param string $c_time
     * @return \DeviceportModel
     */
    public function setC_time($c_time) {
        $this->_c_time = (string)$c_time;

        return $this;
    }

    /**
     * C_time
     * 
     * Column Type: datetime
     * Default: CURRENT_TIMESTAMP
     * 
     * @return string
     */
    public function getC_time() {
        return $this->_c_time;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'        => $this->_id,
            'server'    => $this->_server,
            'device_id' => $this->_device_id,
            'port'      => $this->_port,
            'status'    => $this->_status,
            'u_time'    => $this->_u_time,
            'c_time'    => $this->_c_time
        );
    }

}
