<?php

/**
 * Order
 * 
 * @Table Schema: gcs
 * @Table Name: order
 */
class OrderModel extends \Base\Model\AbstractModel {

    /**
     * Sn
     * 
     * Column Type: varchar(16)
     * PRI
     * 
     * @var string
     */
    protected $_sn = null;

    /**
     * 标题
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_subject = '';

    /**
     * Body
     * 
     * Column Type: varchar(800)
     * 
     * @var string
     */
    protected $_body = '';

    /**
     * Pay_from
     * 
     * Column Type: enum('unknow','weixinpay','alipay','companypay','alipaypage','alipaywap','coupon')
     * Default: unknow
     * 
     * @var string
     */
    protected $_pay_from = 'unknow';

    /**
     * Total_fee
     * 
     * Column Type: decimal(8,2)
     * Default: 0.00
     * 
     * @var float
     */
    protected $_total_fee = 0.00;

    /**
     * 兑换积分量
     * 
     * Column Type: decimal(8,0) unsigned
     * Default: 0
     * 
     * @var float
     */
    protected $_point = 0;

    /**
     * 券码
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_coupon = '';

    /**
     * Addtime
     * 
     * Column Type: int(10) unsigned
     * 
     * @var int
     */
    protected $_addtime = null;

    /**
     * Status
     * 
     * Column Type: enum('refund','payed','pending')
     * Default: pending
     * 
     * @var string
     */
    protected $_status = 'pending';

    /**
     * Mark
     * 
     * Column Type: varchar(200)
     * 
     * @var string
     */
    protected $_mark = '';

    /**
     * Uptime
     * 
     * Column Type: int(10) unsigned
     * 
     * @var int
     */
    protected $_uptime = null;

    /**
     * Mid
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * MUL
     * 
     * @var int
     */
    protected $_mid = 0;

    /**
     * 支付反馈的信息
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_payinfo = null;

    /**
     * Sn
     * 
     * Column Type: varchar(16)
     * PRI
     * 
     * @param string $sn
     * @return \OrderModel
     */
    public function setSn($sn) {
        $this->_sn = (string)$sn;

        return $this;
    }

    /**
     * Sn
     * 
     * Column Type: varchar(16)
     * PRI
     * 
     * @return string
     */
    public function getSn() {
        return $this->_sn;
    }

    /**
     * 标题
     * 
     * Column Type: varchar(255)
     * 
     * @param string $subject
     * @return \OrderModel
     */
    public function setSubject($subject) {
        $this->_subject = (string)$subject;

        return $this;
    }

    /**
     * 标题
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getSubject() {
        return $this->_subject;
    }

    /**
     * Body
     * 
     * Column Type: varchar(800)
     * 
     * @param string $body
     * @return \OrderModel
     */
    public function setBody($body) {
        $this->_body = (string)$body;

        return $this;
    }

    /**
     * Body
     * 
     * Column Type: varchar(800)
     * 
     * @return string
     */
    public function getBody() {
        return $this->_body;
    }

    /**
     * Pay_from
     * 
     * Column Type: enum('unknow','weixinpay','alipay','companypay','alipaypage','alipaywap','coupon')
     * Default: unknow
     * 
     * @param string $pay_from
     * @return \OrderModel
     */
    public function setPay_from($pay_from) {
        $this->_pay_from = (string)$pay_from;

        return $this;
    }

    /**
     * Pay_from
     * 
     * Column Type: enum('unknow','weixinpay','alipay','companypay','alipaypage','alipaywap','coupon')
     * Default: unknow
     * 
     * @return string
     */
    public function getPay_from() {
        return $this->_pay_from;
    }

    /**
     * Total_fee
     * 
     * Column Type: decimal(8,2)
     * Default: 0.00
     * 
     * @param float $total_fee
     * @return \OrderModel
     */
    public function setTotal_fee($total_fee) {
        $this->_total_fee = (float)$total_fee;

        return $this;
    }

    /**
     * Total_fee
     * 
     * Column Type: decimal(8,2)
     * Default: 0.00
     * 
     * @return float
     */
    public function getTotal_fee() {
        return $this->_total_fee;
    }

    /**
     * 兑换积分量
     * 
     * Column Type: decimal(8,0) unsigned
     * Default: 0
     * 
     * @param float $point
     * @return \OrderModel
     */
    public function setPoint($point) {
        $this->_point = (float)$point;

        return $this;
    }

    /**
     * 兑换积分量
     * 
     * Column Type: decimal(8,0) unsigned
     * Default: 0
     * 
     * @return float
     */
    public function getPoint() {
        return $this->_point;
    }

    /**
     * 券码
     * 
     * Column Type: varchar(255)
     * 
     * @param string $coupon
     * @return \OrderModel
     */
    public function setCoupon($coupon) {
        $this->_coupon = (string)$coupon;

        return $this;
    }

    /**
     * 券码
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getCoupon() {
        return $this->_coupon;
    }

    /**
     * Addtime
     * 
     * Column Type: int(10) unsigned
     * 
     * @param int $addtime
     * @return \OrderModel
     */
    public function setAddtime($addtime) {
        $this->_addtime = (int)$addtime;

        return $this;
    }

    /**
     * Addtime
     * 
     * Column Type: int(10) unsigned
     * 
     * @return int
     */
    public function getAddtime() {
        return $this->_addtime;
    }

    /**
     * Status
     * 
     * Column Type: enum('refund','payed','pending')
     * Default: pending
     * 
     * @param string $status
     * @return \OrderModel
     */
    public function setStatus($status) {
        $this->_status = (string)$status;

        return $this;
    }

    /**
     * Status
     * 
     * Column Type: enum('refund','payed','pending')
     * Default: pending
     * 
     * @return string
     */
    public function getStatus() {
        return $this->_status;
    }

    /**
     * Mark
     * 
     * Column Type: varchar(200)
     * 
     * @param string $mark
     * @return \OrderModel
     */
    public function setMark($mark) {
        $this->_mark = (string)$mark;

        return $this;
    }

    /**
     * Mark
     * 
     * Column Type: varchar(200)
     * 
     * @return string
     */
    public function getMark() {
        return $this->_mark;
    }

    /**
     * Uptime
     * 
     * Column Type: int(10) unsigned
     * 
     * @param int $uptime
     * @return \OrderModel
     */
    public function setUptime($uptime) {
        $this->_uptime = (int)$uptime;

        return $this;
    }

    /**
     * Uptime
     * 
     * Column Type: int(10) unsigned
     * 
     * @return int
     */
    public function getUptime() {
        return $this->_uptime;
    }

    /**
     * Mid
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * MUL
     * 
     * @param int $mid
     * @return \OrderModel
     */
    public function setMid($mid) {
        $this->_mid = (int)$mid;

        return $this;
    }

    /**
     * Mid
     * 
     * Column Type: int(10) unsigned
     * Default: 0
     * MUL
     * 
     * @return int
     */
    public function getMid() {
        return $this->_mid;
    }

    /**
     * 支付反馈的信息
     * 
     * Column Type: text
     * 
     * @param string $payinfo
     * @return \OrderModel
     */
    public function setPayinfo($payinfo) {
        $this->_payinfo = (string)$payinfo;

        return $this;
    }

    /**
     * 支付反馈的信息
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getPayinfo() {
        return $this->_payinfo;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'sn'        => $this->_sn,
            'subject'   => $this->_subject,
            'body'      => $this->_body,
            'pay_from'  => $this->_pay_from,
            'total_fee' => $this->_total_fee,
            'point'     => $this->_point,
            'coupon'    => $this->_coupon,
            'addtime'   => $this->_addtime,
            'status'    => $this->_status,
            'mark'      => $this->_mark,
            'uptime'    => $this->_uptime,
            'mid'       => $this->_mid,
            'payinfo'   => $this->_payinfo
        );
    }

}
