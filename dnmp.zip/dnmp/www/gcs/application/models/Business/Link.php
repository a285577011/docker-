<?php
namespace Business;

class LinkModel extends \Business\AbstractModel
{

    use \Base\Model\InstanceModel;

    protected $_resultPlus = 60000;

    protected $_resultMsg = array(
        0 => '未知错误',
        1 => '数据错误',
        2 => '数据不在范围内',
        3 => '未找到类',
        80 => '获取成功',
    );

    public function getData()
    {
        $protocol = $_SERVER['REQUEST_SCHEME'] ? $_SERVER['REQUEST_SCHEME'] : strtolower(explode('/', $_SERVER['SERVER_PROTOCOL'])[0]);//协议
        $url = $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

        if (strpos($url, '?') !== false) { //去除?号
            $url = explode('?', $url)[0];
        }

        $where = ['url' => $url, 'status' => 0];
        $redisKey = $this->cacheId(['link', $where]);
        $linkArray = $this->getCache($redisKey);
        if (!$linkArray) {
            $mapper = \Mapper\LinkModel::getInstance();
            $linkArray = $mapper->fetchArray($where);
            $this->setCache($redisKey, $linkArray, 7200);
        }
        return $this->setResult(80, $linkArray);
    }


}