<?php
namespace Business;

class ToolModel extends \Business\AbstractModel
{
    use \Base\Model\InstanceModel;


    // 错误信息
    protected $_resultPlus = 1300;
    protected $_resultMsg = array(
        0 => '未知',
        1 => '网址有误',
        80 => '成功',
    );

    /**
     * 获取域名信息
     * @param $url
     */
    public function getUrlInfo($url){
        $url = strtolower($url);
        if(strpos($url, '.')===false){
            return $this->setResult(1, $url);
        }
        if(strpos($url, 'http')!==0){
            $url = 'http://'.$url;
        }
        if(!\Ku\Verify::isUrl($url)) {
            return $this->setResult(1, $url);
        }

        $data = parse_url($url);
        $info = [
            'scheme' => isset($data['scheme']) ? $data['scheme'] : 'http',
            'host' => isset($data['host']) ? $data['host'] : '',
            'port' => isset($data['port']) ? $data['port'] : '80',
            'path' => isset($data['path']) ? $data['path'] : '',
            'query' => isset($data['query']) ? $data['query'] : '',
            'fragment' => isset($data['fragment']) ? $data['fragment'] : '',
        ];
        if(empty($info['host']) || !\Ku\Verify::isDomain($info['host'])){
            return $this->setResult(1);
        }

        $info['url'] = $info['scheme'].'://'.$info['host'].($info['port']==80?'':':'.$info['port']).$info['path'].(empty($info['query'])?'':'?'.$info['query']).(empty($info['fragment'])?'':'#'.$info['fragment']);
        $info['uri'] = $info['scheme'].'://'.$info['host'].($info['port']==80?'':':'.$info['port']);
        $info['object'] = $info['host'].($info['port']==80?'':':'.$info['port']);
        $info['hash'] = md5($info['host'].':'.$info['port']);//https和http视为同等网站
        $info['domain'] = $this->domain($info['host']);

        return $this->setResult(80, $info);
    }

    public static $_erArr = array('com.cn',
        'net.cn',
        'gov.cn',
        'edu.cn',
        'ac.cn',
        'bj.cn',
        'sh.cn',
        'tj.cn',
        'cq.cn',
        'he.cn',
        'sx.cn',
        'nm.cn',
        'ln.cn',
        'jl.cn',
        'hl.cn',
        'js.cn',
        'zj.cn',
        'ah.cn',
        'fj.cn',
        'jx.cn',
        'sd.cn',
        'ha.cn',
        'hb.cn',
        'hn.cn',
        'gd.cn',
        'gx.cn',
        'hi.cn',
        'sc.cn',
        'xz.cn',
        'gs.cn',
        'qh.cn',
        'nx.cn',
        'tw.cn',
        'hk.cn',
        'mo.cn',
        'hk.cn',
        'gz.cn',
        'yn.cn',
        'sn.cn',
        'xj.cn',
        'co.uk',
        'co.nz',
        'co.jp',
        'co.kr',
        'co.com',
        'com.tw',
        'com.hk',
        'me.uk',
        'org.uk',
        'ltd.uk',
        'plc.uk',
        'com.co',
        'net.co',
        'nom.co',
        'com.ag',
        'net.ag',
        'org.ag',
        'com.bz',
        'net.bz',
        'net.br',
        'com.br',
        'com.es',
        'nom.es',
        'org.es',
        'co.in',
        'firm.in',
        'gen.in',
        'ind.in',
        'net.in',
        'org.in',
        'com.mx',
        'net.nz',
        'org.nz',
        'org.tw',
        'idv.tw',
        'com.jp',
    );

    /**
     * 获取域名主后缀
     * https://publicsuffix.org/list/public_suffix_list.dat
     */
    public static function domain($fullDomain) {
        $domain = $fullDomain;
        if (\Ku\Verify::isDomain($fullDomain)) {
            $arr = array_filter(explode('.', $fullDomain));
            $num = count($arr);
            if ($num > 2) {
                $ext = $arr[$num - 2] . '.' . $arr[$num - 1];
                if (in_array($ext, self::$_erArr) || in_array($arr[$num - 2], array('com', 'net', 'org', 'edu', 'gov', 'co'))) {
                    $domain = $arr[$num - 3] . '.' . $arr[$num - 2] . '.' . $arr[$num - 1];
                } else {
                    $domain = $arr[$num - 2] . '.' . $arr[$num - 1];
                }
            }
        }

        return $domain;
    }

    public function charsetConvert($content, $charset='GBK'){
        if($charset=='UTF-8' || $charset==''){
            return $content;
        }
        return mb_convert_encoding($content, 'UTF-8', $charset);
    }

    public function pathFile($file, $url=false){
        $config = \Yaf\Registry::get('config');
        $dir = substr($file, 0, 8) > 20190101 && substr($file, 0, 8) < 30190101 ? substr($file, 0, 6) . '/' . substr($file, 6, 2) . '/' . substr($file, 8, 2) :  substr($file, 0, 1) . '/' . substr($file, 1, 2);
        $urlHost = $config->get('resources.tencentCos.urlHost');
        if($config->get('resources.tencentCos.use')){
            $path =  '/' . $dir . '/' . $file;
            if($url){
                $path = $urlHost.$path;
            }
        }else{
            if($url){
                $path = $urlHost.'/data/cache/' . $dir . '/' . $file;
            }else{
                $path = APPLICATION_PATH . DS . 'public' . DS . 'data' . DS . 'cache' . DS . str_replace('/', DS, $dir) . DS . $file;
            }
        }
        return $path;
    }

    public function saveFile($file, $content, $gzip = false){
        $config = \Yaf\Registry::get('config');
        if($config->get('resources.tencentCos.use')){
            
            //引入腾讯云COS对象存储类库
            require_once APPLICATION_PATH . DS . 'application' . DS .'library' . DS .'Ku' . DS .'cos-sdk-v5.phar';
            //初始化类库
            $secretId = $config->get('resources.tencentCos.secretId'); //"云 API 密钥 SecretId";
            $secretKey = $config->get('resources.tencentCos.secretKey'); //"云 API 密钥 SecretKey";
            $region = $config->get('resources.tencentCos.region'); //设置一个默认的存储桶地域
            $bucket = $config->get('resources.tencentCos.bucket'); //存储桶名称 格式：BucketName-APPID
            if(empty($secretId) || empty($secretKey) || empty($region)){
                return $this->setResult('tencentCos配置错误');
            }
            $cosClient = new \Qcloud\Cos\Client(
                array(
                    'region' => $region,
                    'schema' => 'https', //协议头部，默认为http
                    'credentials'=> array(
                        'secretId'  => $secretId ,
                        'secretKey' => $secretKey
                    )
                )
            );
            //上传文件流
            try {
                $path = $this->pathFile($file, false);
                $param = array(
                    'Bucket' => $bucket,
                    'Key' => $path,
                    'Body' => $content,
                );
                if($gzip){
                    $param['ContentEncoding'] = 'gzip';
                }
                $result = $cosClient->putObject($param)->toArray();
            } catch (\Exception $e) {
                return $this->setResult('保存文件错误'.$file);
            }
        }else{
            $path = $this->pathFile($file, false);
            if(!is_writable(dirname($path))){
                mkdir(dirname($path), 0777, true);
            }

            $fp = fopen($path, "w");
            if(!$fp){
                return $this->setResult('文件打开错误');
            }
            if($gzip){
                $content = gzdecode($content);
            }
            $result = fwrite($fp, $content);
            fclose($fp);
            if(!$result){
                return $this->setResult('文件写入错误');
            }
        }
        return $this->setResult(80, $result);
    }

    public function openFile($file){
        $config = \Yaf\Registry::get('config');
        if($config->get('resources.tencentCos.use')){
            //引入腾讯云COS对象存储类库
            require_once APPLICATION_PATH . DS . 'application' . DS .'library' . DS .'Ku' . DS .'cos-sdk-v5.phar';
            //初始化类库
            $secretId = $config->get('resources.tencentCos.secretId'); //"云 API 密钥 SecretId";
            $secretKey = $config->get('resources.tencentCos.secretKey'); //"云 API 密钥 SecretKey";
            $region = $config->get('resources.tencentCos.region'); //设置一个默认的存储桶地域
            $bucket = $config->get('resources.tencentCos.bucket'); //存储桶名称 格式：BucketName-APPID
            if(empty($secretId) || empty($secretKey) || empty($region)){
                return $this->setResult('tencentCos配置错误');
            }
            $cosClient = new \Qcloud\Cos\Client(
                array(
                    'region' => $region,
                    'schema' => 'https', //协议头部，默认为http
                    'credentials'=> array(
                        'secretId'  => $secretId ,
                        'secretKey' => $secretKey
                    )
                )
            );
            //上传文件流
            try {
                $path = $this->pathFile($file, false);
                $result = $cosClient->getObject(array(
                        'Bucket' => $bucket,
                        'Key' => $path,
                ));
                ob_start();
                echo $result['Body'];
                $content = ob_get_contents();
                ob_end_clean();
                if($result['ContentEncoding']=='gzip'){
                    $content = gzdecode($content);
                }
            } catch (\Exception $e) {
                return $this->setResult('获取文件错误'.$file);
            }
        }else{
            $path = $this->pathFile($file, false);
            if(!file_exists($path)){
                return $this->setResult('文件不存在');
            }
            $fp = fopen($path, "r");
            if(!$fp){
                return $this->setResult('文件打开错误');
            }
            $content = fread($fp, filesize($path));
            fclose($fp);
            if(!$content){
                return $this->setResult('文件读取错误');
            }
        }
        return $this->setResult(80, $content);
    }

    /**
     * 编码内容和解析短码
     * 短码冒号:开头，共6位
     */
    public function short($target){
        $redis = $this->getredis();
        $baseBs = new \Ku\Base32("xfs");
        if(strpos($target, ':')===0){
            $short = substr($target, 1);
            $key = '_short:'.$short;
            $encode = $redis->get($key);
            if(empty($encode)){
                return $this->setResult('短码不存在');
            }
            $decode = $baseBs->authCode($encode, "DECODE", true, 2, 1);
            if(empty($decode)){
                return $this->setResult('短码解码失败');
            }
            return $this->setResult(80, $decode);
        }else{
            while (true) {
                $encode = $baseBs->authCode($target, "ENCODE", 172800, 2, 1);//有效期两天
                $short = substr($encode, 0, 5);
                $key = '_short:'.$short;
                if($redis->exists($key)){
                    continue;
                }
                $redis->set($key, $encode, 259200);//存储三天
                break;
            }
            return $this->setResult(80, $short);
        }
    }
}