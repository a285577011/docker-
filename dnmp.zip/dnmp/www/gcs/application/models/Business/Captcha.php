<?php

/**
 * Description of Captcha
 *
 */

namespace Business;

class CaptchaModel extends \Business\AbstractModel {

    use \Base\Model\InstanceModel;

    // 免验证码次数
    const CAPTCHA_AVOID_NUM = 'captcha.avoid.num.%s';
    // 存储验证码
    const CAPTCHA_CODE = 'captcha.code.%s';
    // 存储验证码使用次数
    const CAPTCHA_CODE_NUM = 'captcha.code.num.%s';

    //错误
    protected $_resultPlus = 10100;
    protected $_resultMsg = array(
        0 => '验证通过',
        1 => '验证码错误',
        2 => '验证码不存在或者过期需要更换',
        3 => '验证码错误并且需要更换',
    );

    /**
     * 是否使用图形验证码
     *
     * @param string $channel
     * @param int $limit 免图形验证码次数
     * @return boolean
     */
    public function isCaptcha($channel = null, $limit = 3) {
        if ($limit < 1) {
            return true;
        }

        $redis = $this->getRedis();
        $clientIp = \Ku\Tool::getClientIp(true, true);
        $key = sprintf(self::CAPTCHA_AVOID_NUM, $channel . $clientIp);
        if ($redis->get($key) > $limit) {
            return true;
        }
        return false;
    }

    /**
     * 减少免验证码的次数
     * @param type $channel
     * @param type $expire
     * @return boolean
     */
    public function incrCaptcha($channel = null, $expire = 3600) {
        $redis = $this->getRedis();
        $clientIp = \Ku\Tool::getClientIp(true, true);
        $key = sprintf(self::CAPTCHA_AVOID_NUM, $channel . $clientIp);
        $redis->incr($key);
        $redis->expire($key, $expire);
        return false;
    }

    /**
     * 生成验证码图片
     * 调用此函数后不能再有任何输出
     * 
     * @param type $channel
     * @param type $expire
     */
    public function captcha($channel = null, $expire = 300) {
        $clientIp = \Ku\Tool::getClientIp(true, true);

        //生成验证码
        $captcha = \Ku\Captcha\Captcha::getInstance();
        $captcha->setHeight(40)->setWidth(98);
        $captcha->setInterfere('pixel')->setRandLength(4)->create();
        $code = $captcha->getCaptcha();

        //存验证码
        $redis = $this->getRedis();
        $key = sprintf(self::CAPTCHA_CODE, $channel . $clientIp);
        $redis->set($key, $code);
        $redis->expire($key, $expire);

        //显示验证码
        $captcha->show();
    }

    /**
     * 检查验证码
     *
     * @param string $captcha
     * @param string $channel 验证码频道，单个验证码最多使用十次
     * @return int
     */
    public function checkCaptcha($code, $channel = null, $limit = 10) {
        if (empty($code)) {
            return $this->setResult(1);
        }

        $redis = $this->getRedis();
        $clientIp = \Ku\Tool::getClientIp(true, true);
        $key = sprintf(self::CAPTCHA_CODE, $channel . $clientIp);
        $codeData = $redis->get($key);
        //验证码不存在或者过期
        if ($codeData == null) {
            return $this->setResult(2);
        }

        //验证码错误
        $numKey = sprintf(self::CAPTCHA_CODE_NUM, $channel . $clientIp);
        if (!(strcasecmp($codeData, $code) === 0)) {
            $num = $redis->incr($numKey);
            if ($num == 1) {
                $redis->expire($numKey, $redis->ttl($key));
            }
            if ($num > $limit) {
                $redis->del($numKey);
                $redis->del($key);
                return $this->setResult(3);
            }
            return $this->setResult(1);
        }

        $redis->del($key);
        $redis->del($numKey);
        return true;
    }

}
