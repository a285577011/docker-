<?php

namespace Business;

class AbstractModel
{

    //外部错误编码前缀（外部错误编码=外部错误编码前缀+内部错误编码）
    protected $_resultPlus = 100;
    //内部错编码, >=80用于成功
    protected $_resultCode = 0;
    //错误编码消息
    protected $_resultMsg = array(
        0 => '错误',
        80 => '成功'
    );
    //错误的数据
    protected $_resultData = null;
    /**
     * 设置错误
     * @param type $code
     * @return boolean
     */
    public function setResult($code = 0, $data = null)
    {
        $this->_resultCode = $code;
        $this->_resultData = $data;
        return is_int($code) && $code >= 80 ? true : false;
    }
    /**
     * 获取错误消息
     * @return type
     */
    public function getResultMsg()
    {
        $resultMsg = is_int($this->_resultCode) && isset($this->_resultMsg[$this->_resultCode]) ? $this->_resultMsg[$this->_resultCode] : $this->_resultCode;
        if (isset($this->_resultData['assign'])) {
            $resultMsg = vsprintf($resultMsg, $this->_resultData['assign']);
        }
        return $resultMsg;
    }
    /**
     * 获取外部错误编码
     * @return int
     */
    public function getResultCode()
    {
        return is_int($this->_resultCode) ? ($this->_resultPlus + $this->_resultCode) : $this->_resultPlus;
    }
    /**
     * 获取外部错误编码
     * @return int
     */
    public function getResultData()
    {
        $data = (array)$this->_resultData;
        $result = [];
        foreach($data as $key=>$value){
            if ($key != 'assign' || !(empty($key) && empty($value))) {
                $result[$key] = $value;
            }
        }

        return $result;
    }

    /**
     * 返回 Redis 实例
     *
     * @return \Redis|null
     */
    public function getRedis()
    {
        static $_redis = null;

        return $_redis ? : \Yaf\Registry::get('redis');
    }

    /**
     * 获取缓存id
     * @param type $params
     * @return type
     */
    public function cacheId($params)
    {
        if (!is_array($params)) {
            $params = array($params);
        }
        foreach ($params as &$param) {
            if (is_numeric($param)) {
                $param = intval($param);
            } elseif (is_bool($param)) {
                $param = $param ? 1 : 0;
            }
        }
        ksort($params);

        return md5(json_encode($params));
    }

    /**
     * 获取缓存
     * @param type $cacheId
     * @param type $hashId
     * @return boolean
     */
    public function getCache($cacheId, $hashId = '')
    {
        $request = \Yaf\Dispatcher::getInstance()->getRequest();
        if (isset($_GET['no_cache']) || $request->getParam('no_cache', null) == 1) {
            return false;
        }
        $redis = $this->getRedis();
        if ($hashId != '') {
            $data = $hashId === 'hgetall' ? $redis->hgetall($cacheId) : $redis->hget($cacheId, $hashId);
        } else {
            $data = $redis->get($cacheId);
        }
        return $data ? (is_array($data) ? array_map('unserialize', $data) : unserialize($data)) : false;
    }


    /**
     * 设置缓存
     * @param type $cacheId
     * @param type $data
     * @param type $expire
     * @param type $hashId
     * @return boolean
     */
    public function setCache($cacheId, $data, $expire = 1800, $hashId = '')
    {
        $redis = $this->getRedis();
        if ($data) {
            if ($hashId != '') {
                $data = $redis->hset($cacheId, $hashId, serialize($data));
            } else {
                $redis->set($cacheId, serialize($data));
            }
            if ($expire > 0) {
                $redis->EXPIRE($cacheId, $expire);
            }
            return true;
        } else {
            return $redis->del($cacheId);
        }
    }
}
