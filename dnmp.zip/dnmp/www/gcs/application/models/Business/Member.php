<?php

/**
 * Description of Member
 *
 */

namespace Business;

class MemberModel extends \Business\AbstractModel {

    protected $_member = null;
    //允许登陆的最大客户端数量
    protected $_allow_login_agent_num = 0;
    //服务端存储的登陆状态，账户key，内容为数组，账户的每个客户端对应一个键值对，sign(memberInfo)=>memberInfo
    protected $_allow_login_agent_key = '_m_d:%d';
    //cookie或者header存储
    protected $_allow_login_agent_tokenKey = 'token';
    protected $_allow_login_agent_token = null;
    protected $_allow_login_agent_time = 864000;

    //错误
    protected $_resultPlus = 10200;
    protected $_resultMsg = array(
        0 => '未知错误',
        1 => '密码必须大于6位',
        2 => '手机验证码不正确',
        3 => '邮箱验证码不正确',
        4 => '邀请码不正确',
        5 => '账号格式不正确',
        6 => '该账号已被注册',
        7 => '账号或密码不能为空',
        8 => '账号或密码错误',
        9 => '账号已被%s禁用',
        10 => '账号未登陆',
        11 => '旧密码不正确',
        12 => '账号错误',
        13 => '密码错误',
        14 => '资金不足',
        15 => '充值失败',
        16 => '账号不存在',
        17 => '任务更新失败',
        80 => '成功',
    );

    //临时参数
    protected $_params = [];


    public function __construct($agent_num = 0) {
        $this->_allow_login_agent_num = $agent_num;
    }

    //重置临时参数
    public function resetParam(){
        $this->_params = [];
    }

    public function setParam($key, $value = null){
        if(is_array($key) && $value==null){
            $this->_params = array_merge_recursive($this->_params, $key);
        }else{
            $this->_params[$key] = $value;
        }
    }

    public function getParam($key){
        if(isset($this->_params[$key])){
            return $this->_params[$key];
        }
        return null;
    }

    /**
     * 获取登陆用户的mid
     */
    public function getMid($status = null) {
        //session
        $session = \Yaf\Session::getInstance();
        $mid = $session->get('mid');
        $agent = $session->get('agent');

        //cookie或者header
        if ($mid < 1 && (isset($_COOKIE[$this->_allow_login_agent_tokenKey]) || isset($_SERVER['HTTP_'.strtoupper($this->_allow_login_agent_tokenKey)]))) {
            $umdata = isset($_COOKIE[$this->_allow_login_agent_tokenKey])  ? $_COOKIE[$this->_allow_login_agent_tokenKey] : $_SERVER['HTTP_'.strtoupper($this->_allow_login_agent_tokenKey)];
            $string = \Ku\Tool::authCode($umdata, 'DECODE');
            $data = array();
            parse_str($string, $data);
            if (isset($data['mid']) && isset($data['agent']) && isset($data['rand']) && isset($data['time']) && isset($data['sign'])) {
                $sign = $data['sign'];
                unset($data['sign']);
                //签名判断
                if (\Ku\Tool::sign($data) == $sign) {
                    $mid = $data['mid'];
                    $agent = $sign;

                    $session->set('mid', $mid);
                    $session->set('agent', $agent);
                }
            }else{
                unset($_COOKIE[$this->_allow_login_agent_tokenKey]);
            }
        }

        //多端登录判断
        if ($mid > 0 && $this->_allow_login_agent_num > 0) {
            $redis = $this->getRedis();
            $key = '_m_d:' . $mid;
            if(!$redis->hExists($key, $agent)){
                $mid = 0;
            }
        }
        
        //实时判断用户状态
        if($mid>0 && $status!==null){
            $memberMp = \Mapper\MemberModel::getInstance();
            $memberMdl = $memberMp->findById($mid);
            if ($memberMdl instanceof \MemberModel) {
                if(is_int($status) && $status==$memberMdl->getStatus()){
                    //单状态判断
                }elseif(is_array($status) && in_array($memberMdl->getStatus(), $status)){
                    //多状态判断
                }else{
                    $this->logout();
                    $mid = 0;
                }
            }else{
                $mid = 0;
            }
        }

        return $mid;
    }

    /**
     * 当前登录用户
     *
     * @return \MemberModel|null
     */
    public function getMember($status = null) {
        if (!$this->_member instanceof \MemberModel || $status !== null) {
            $mid = $this->getMid($status);
            if ($mid > 0) {
                $memberMp = \Mapper\MemberModel::getInstance();
                $memberMdl = $memberMp->findById($mid);
                if ($memberMdl instanceof \MemberModel) {
                    $this->_member = $memberMdl;
                }
            }
        }
        return $this->_member;
    }

    public function getMemberInfo() {
        $memberMdl = $this->getMember();
        if (!$memberMdl instanceof \MemberModel) {
            return $this->setResult(10);
        }

        return array(
            'mid' => $memberMdl->getId(),
            'username' => $memberMdl->getUsername(),
            'nickname' => $memberMdl->getNickname(),
            'mobile' => $memberMdl->getMobile(),
            'email' => $memberMdl->getEmail(),
            'freeze' => $memberMdl->getFreeze(),
            'point' => $memberMdl->getPoint(),
            'avatar' => $memberMdl->getAvatar(),
        );
    }

 
    public function findMemberByUser($user, $allowTypes = array('mobile', 'email', 'username')) {
        $memberMp = \Mapper\MemberModel::getInstance();
        //获取用户
        if (in_array('mobile', $allowTypes) && \Ku\Verify::isMobile($user)) {
            return $memberMp->findByMobile($user);
        } elseif (in_array('email', $allowTypes) && \Ku\Verify::isEmail($user)) {
            return $memberMp->findByEmail($user);
        } elseif (in_array('username', $allowTypes) && \Ku\Verify::isUsername($user)) {
            return $memberMp->findByUsername($user);
        }
        return false;
    }
    
    public function findMemberByMid($mid) {
        $memberMp = \Mapper\MemberModel::getInstance();
        //获取用户
        return $memberMp->findById($mid);
    }

    /**
     * 登陆
     */
    public function login($user, $password, $remember = false, $secure = null, $allowTypes = array('mobile', 'email', 'username')) {
        if (empty($user) || empty($password)) {
            return $this->setResult(7);
        }

        $memberMp = \Mapper\MemberModel::getInstance();
        //获取用户
        if (in_array('mobile', $allowTypes) && \Ku\Verify::isMobile($user)) {
            $memberMdl = $memberMp->fetch(['mobile'=>$user, 'mobileverify'=>1]);
        } elseif (in_array('email', $allowTypes) && \Ku\Verify::isEmail($user)) {
            $memberMdl = $memberMp->fetch(['email'=>$user, 'emailverify'=>1]);
        } elseif (in_array('username', $allowTypes) && \Ku\Verify::isUsername($user)) {
            $memberMdl = $memberMp->findByUsername($user);
        } else {
            return $this->setResult(5);
        }

        //检查用户
        if (!$memberMdl instanceof \MemberModel) {
            return $this->setResult(12);
        }
        if (\Ku\Tool::valid($password, $memberMdl->getPassword(), $secure) === false) {
            return $this->setResult(13);
        }

        //是否被禁用
        if ($memberMdl->getStatus() > 0) {
            return $this->setResult(9, ['assign'=>['系统']]);
        }

        //更新用户登录
        $memberMp->updateLogin($memberMdl);

        //设置用户登录
        return $this->setLogin($memberMdl, $remember);
    }

    /**
     * 存储登陆状态
     * @param \MemberModel $memberMdl
     * @param boolean|int $remember 是否在cookie记住登陆状态，如果为数字则为记住状态的时间
     */
    public function setLogin($memberMdl, $remember = false) {
        if (!$memberMdl instanceof \MemberModel) {
            return $this->setResult(12);
        }

        //数据
        $data = array();
        $data['mid'] = $memberMdl->getId();
        $data['agent'] = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unkwon';
        $data['rand'] = mt_rand(1000, 9999);
        $data['time'] = microtime(true);;
        $sign = \Ku\Tool::sign($data);
        $data['sign'] = $sign;
        //加密数据
        $umdata = \Ku\Tool::authCode(http_build_query($data), 'encode');
        //签名内容也作为登录端key
        $agent = $sign;

        //session
        $mid = $memberMdl->getId();
        $session = \Yaf\Session::getInstance();
        $session->set('mid', $mid);
        $session->set('agent', $agent);

        //cookie
        if ($remember) {
            header("P3P: CP='CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR'");
            $rememberTime = is_int($remember) && $remember > 60 ? intval($remember) : $this->_allow_login_agent_time;
            setcookie($this->_allow_login_agent_tokenKey, $umdata, time() + $rememberTime, '/', null, false, true);
        }

        //token
        $this->_allow_login_agent_token = $umdata;

        //多端登录
        if ($this->_allow_login_agent_num > 0) {
            $redis = $this->getRedis();

            //删除超出的登录端
            $key = sprintf($this->_allow_login_agent_key, $mid);
            $agents = $redis->hKeys($key);
            while ($redis->hLen($key) >= $this->_allow_login_agent_num) {
                $redis->hDel($key, array_shift($agents));
            }

            //设置多端登录
            $redis->hSet($key, $agent, $umdata);
            $redis->expire($key, $this->_allow_login_agent_time);
        }

        $referer = '/';
        if(isset($_COOKIE['referer'])){
            $referer = $_COOKIE['referer'];
            setcookie('referer', "", time() - 3600, '/', '', false, true);
        }

        return $this->setResult(80, ['url'=>$referer, $this->_allow_login_agent_tokenKey => $this->_allow_login_agent_token]);
    }

    public function logout() {
        $mid = $this->getMid();

        $session = \Yaf\Session::getInstance();

        //删除多端登录
        if ($this->_allow_login_agent_num > 0) {
            $redis = $this->getRedis();
            $key = sprintf($this->_allow_login_agent_key, $mid);
            $agent = $session->get('agent');
            $redis->hDel($key, $agent);
        }

        //session
        $session->del('mid');
        $session->del('agent');

        //cookie
        if (isset($_COOKIE[$this->_allow_login_agent_tokenKey])) {
            header("P3P: CP='CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR'");
            setcookie($this->_allow_login_agent_tokenKey, null, time() - 1, '/', null, false, true);
        }

        return $this->setResult(80, ['url'=>'/']);
    }

    public function reg($user, $password, $code, $allowTypes = array('mobile', 'email', 'username')) {
        if (strlen($password) < 6) {
            return $this->setResult(1);
        }

        $memberMp = \Mapper\MemberModel::getInstance();

        //检查类型和验证码
        if (in_array('mobile', $allowTypes) && \Ku\Verify::isMobile($user)) {
            $memberMdl = $memberMp->findByMobile($user);
            //短信验证码处理
            if (\Ku\Sender\Compare::sms($user, 'reg', $code) === false) {
                return $this->setResult(2);
            }
            $type = 'mobile';
            $nickname = 'm_' . $user;
        } elseif (in_array('email', $allowTypes) && \Ku\Verify::isEmail($user)) {
            $memberMdl = $memberMp->findByEmail($user);
            //邮箱验证码处理
            if (\Ku\Sender\Compare::email($user, 'reg', 0, $code) === false) {
                return $this->setResult(3);
            }
            $type = 'email';
            $nickname = 'e_' . \crc32($user);
        } elseif (in_array('username', $allowTypes) && \Ku\Verify::isUsername($user)) {
            $memberMdl = $memberMp->findByUsername($user);
            $type = 'username';
            $nickname = 'u_'.$user;
        } else {
            return $this->setResult(5);
        }

        //检查邀请验证码
        //return $this->setResult(4);
        //检查是否存在
        if ($memberMdl instanceof \MemberModel) {
            return $this->setResult(6);
        }

        //增加会员
        $memberMp = \Mapper\MemberModel::getInstance();
        $model = new \MemberModel();
        $funName = 'set' . ucfirst($type);
        $funVerify = 'set' . ucfirst($type) . 'verify';
        $model->$funName($user);
        if(method_exists($model, $funVerify)){
            $model->$funVerify(1);
        }
        $model->setPassword(\Ku\Tool::encryption($password));
        $model->setNickname($nickname);
        $model->setAtime(date('YmdHis'));
        $mid = $memberMp->reg($model);
        if ($mid > 0) {
            $this->login($user, $password);
            return $this->setResult(80, ['url'=>'/#login']);
        }

        return $this->setResult(0);
    }

    public function findPassword($user, $password, $code, $allowTypes = array('mobile', 'email')) {
        if (strlen($password) < 6) {
            return $this->setResult(1);
        }

        $memberMp = \Mapper\MemberModel::getInstance();

        //检查类型和验证码
        if (in_array('mobile', $allowTypes) && \Ku\Verify::isMobile($user)) {
            $memberMdl = $memberMp->findByMobile($user);
            //短信验证码处理
            if (\Ku\Sender\Compare::sms($user, 'resetpassword', $code) === false) {
                return $this->setResult(2);
            }
            $type = 'mobile';
        } elseif (in_array('email', $allowTypes) && \Ku\Verify::isEmail($user)) {
            $memberMdl = $memberMp->findByEmail($user);
            //邮箱验证码处理
            if (\Ku\Sender\Compare::email($user, 'resetpassword', 0, $code) === false) {
                return $this->setResult(3);
            }
            $type = 'email';
        } else {
            return $this->setResult(5);
        }

        //检查是否存在
        if (!$memberMdl instanceof \MemberModel) {
            return $this->setResult(16);
        }

        $memberMdl->setPassword(\Ku\Tool::encryption($password));
        if($memberMp->updateProfile($memberMdl)){
            return $this->setResult(80, ['url'=>'/#login']);
        }
        return $this->setResult(0);
    }

    public function changePassword($password) {
        if (strlen($password) < 6) {
            return $this->setResult(1);
        }

        $mid = $this->getMid(0);
        if ($mid < 1) {
            return $this->setResult(10);
        }

        $memberMp = \Mapper\MemberModel::getInstance();
        $memberMdl = $this->getMember(0);
        if (!$memberMdl instanceof \MemberModel) {
            return $this->setResult(10);
        }
        $memberMdl->setPassword(\Ku\Tool::encryption($password));
        //修改密码时 修改密码的用户id 和时间
        $memberMdl->setAid($memberMdl->getId());
        $memberMdl->setAtime(date('YmdHis'));
     
        if($memberMp->updateProfile($memberMdl)){
            return $this->setResult(80, ['url'=>'/#login']);
        }
        return $this->setResult(0);
    }

    public function checkPassword($password, $secure = null) {
        $mid = $this->getMid(0);
        if ($mid < 1) {
            return $this->setResult(10);
        }

        $memberMdl = $this->getMember(0);
        
        //检查用户
        if (!$memberMdl instanceof \MemberModel || \Ku\Tool::valid($password, $memberMdl->getPassword(), $secure) === false) {
            return $this->setResult(11);
        }

        return $this->setResult(80);
    }

    /**
     * 对账户进行充值
     * @param type $amount
     * @param type $callback 内部不允许出现事务
     * @return boolean
     * @throws \Exception
     */
    public function income($mid, $amount, $callback = null){
        $memberMp = \Mapper\MemberModel::getInstance();
        //旧资金
        $memberOld = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberOld)){
            return $this->setResult(16, $memberOld);
        }
        //充值
        $sql = 'update '.$memberMp->getTable().' set point = point+' . $amount . ' where id=' . $mid;
        $memberMp->begin();
        try {
            $resultObj = $memberMp->query($sql);
            $effectedRows = $resultObj->getAffectedRows();
            if ($effectedRows == 1 || $amount==0) {
                $result = true;
            } else {
                throw new \Ku\Exception('充值失败');
            }
        } catch (\Exception $ex) {
            $this->setResult(15, $memberOld);
            $result = false;
        }
        //新资金
        $memberNew = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberNew)){
            $this->setResult(15, $memberNew);
            $result = false;
        }
        //做回调
        if ($result === true && is_callable($callback) && call_user_func_array($callback, array($this)) === false) {
            $this->setResult(15, 'callback');
            $result = false;
        }
        //记录日志
        $cate = isset($this->_params['cate']) ? $this->_params['cate'] : 'income';
        $aid = isset($this->_params['aid']) ? $this->_params['aid'] : 0;
        $attach = isset($this->_params['attach']) ? $this->_params['attach'] : '';
        if ($result === true && $this->addFlow($mid, $cate, $aid, $attach, $memberOld['freeze'], $memberNew['freeze'], $memberOld['point'], $memberNew['point']) === true) {
            $memberMp->commit();
            return true;
        }
        //失败回滚
        $memberMp->rollback();
        return false;
    }

    /**
     * 对账户进行扣款
     * @param type $amount
     * @param type $callback 内部不允许出现事务
     * @return boolean
     * @throws \Exception
     */
    public function payout($mid, $amount, $callback=null){
        $memberMp = \Mapper\MemberModel::getInstance();
        //旧资金
        $memberOld = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberOld)){
            return false;
        }
        //扣款
        $sql = 'update '.$memberMp->getTable().' set point = point-' . $amount . ' where id=' . $mid . ' AND point >= '.$amount;
        $memberMp->begin();
        try {
            $resultObj = $memberMp->query($sql);
            $effectedRows = $resultObj->getAffectedRows();
            if ($effectedRows == 1 || $amount==0) {
                $result = true;
            } else {
                throw new \Ku\Exception('扣钱失败');
            }
        } catch (\Exception $ex) {
            $this->setResult(14, $memberOld);
            $result = false;
        }
        //新资金
        $memberNew = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberNew)){
            $this->setResult(14, $memberNew);
            $result = false;
        }
        //做回调
        if ($result === true && is_callable($callback) && call_user_func_array($callback, array($this)) === false) {
            $this->setResult(14, 'callback');
            $result = false;
        }
        //记录日志
        $cate = isset($this->_params['cate']) ? $this->_params['cate'] : 'payout';
        $aid = isset($this->_params['aid']) ? $this->_params['aid'] : 0;
        $attach = isset($this->_params['attach']) ? $this->_params['attach'] : '';
        if ($result === true && $this->addFlow($mid, $cate, $aid, $attach, $memberOld['freeze'], $memberNew['freeze'], $memberOld['point'], $memberNew['point']) === true) {
            $memberMp->commit();
            return true;
        }
        //失败回滚
        $memberMp->rollback();
        return false;
    }

    /**
     * 对账户进行冻结扣款
     * @param type $amount
     * @param type $callback 内部不允许出现事务
     * @return boolean
     * @throws \Exception
     */
    public function freeze($mid, $amount, $callback=null){
        $memberMp = \Mapper\MemberModel::getInstance();
        //旧资金
        $memberOld = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberOld)){
            return false;
        }
        //扣款
        $sql = 'update '.$memberMp->getTable().' set freeze=freeze+' . $amount . ',point=point-' . $amount . ' where id=' . $mid . ' AND point >= '.$amount;
        $memberMp->begin();
        try {
            $resultObj = $memberMp->query($sql);
            $effectedRows = $resultObj->getAffectedRows();
            if ($effectedRows == 1 || $amount==0) {
                $result = true;
            } else {
                throw new \Ku\Exception('冻结失败');
            }
        } catch (\Exception $ex) {
            $this->setResult(14);
            $result = false;
        }
        //新资金
        $memberNew = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberNew)){
            $this->setResult(14, $memberNew);
            $result = false;
        }
        //做回调
        if ($result === true && is_callable($callback) && call_user_func_array($callback, array($this)) === false) {
            $this->setResult(14, 'callback');
            $result = false;
        }
        //记录日志
        $cate = isset($this->_params['cate']) ? $this->_params['cate'] : 'freeze';
        $aid = isset($this->_params['aid']) ? $this->_params['aid'] : 0;
        $attach = isset($this->_params['attach']) ? $this->_params['attach'] : '';
        if ($result === true && $this->addFlow($mid, $cate, $aid, $attach, $memberOld['freeze'], $memberNew['freeze'], $memberOld['point'], $memberNew['point']) === true) {
            $memberMp->commit();
            return true;
        }
        //失败回滚
        $memberMp->rollback();
        return false;
    }

    /**
     * 对账户进行取消冻结扣款，从冻结款中付款
     * @param type $freeze 冻结款
     * @param type $amount 冻结款付款
     * @param type $callback 内部不允许出现事务
     * @return boolean
     * @throws \Exception
     */
    public function freePayout($mid, $freeze, $amount, $callback=null){
        if($amount > $freeze){
            $amount = $freeze;
        }
        //取消冻结的付款
        $freeAmount = $freeze - $amount;

        $memberMp = \Mapper\MemberModel::getInstance();
        //旧资金
        $memberOld = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberOld) || $amount > $memberOld['freeze']){
            return false;
        }
        //扣款
        $sql = 'update '.$memberMp->getTable().' set freeze=freeze-' . $freeze . ',point=point+' . $freeAmount . ' where id=' . $mid . ' AND freeze >= '.$freeze;
        $memberMp->begin();
        try {
            $resultObj = $memberMp->query($sql);
            $effectedRows = $resultObj->getAffectedRows();
            if ($effectedRows == 1 || $amount==0) {
                $result = true;
            } else {
                throw new \Ku\Exception('使用冻结付款失败');
            }
        } catch (\Exception $ex) {
            $this->setResult(14);
            $result = false;
        }
        //新资金
        $memberNew = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberNew)){
            $this->setResult(14, $memberNew);
            $result = false;
        }
        //做回调
        if ($result === true && is_callable($callback) && call_user_func_array($callback, array($this)) === false) {
            $this->setResult(14, 'callback');
            $result = false;
        }
        //记录日志
        $cate = isset($this->_params['cate']) ? $this->_params['cate'] : 'freePayout';
        $aid = isset($this->_params['aid']) ? $this->_params['aid'] : 0;
        $attach = isset($this->_params['attach']) ? $this->_params['attach'] : '';
        if ($result === true && $this->addFlow($mid, $cate, $aid, $attach, $memberOld['freeze'], $memberNew['freeze'], $memberOld['point'], $memberNew['point']) === true) {
            $memberMp->commit();
            return true;
        }
        //失败回滚
        $memberMp->rollback();
        return false;
    }

    /**
     * 对账户积分进行修改
     * @param type $freeze 冻结款
     * @param type $amount 冻结款付款
     * @param type $callback 内部不允许出现事务
     * @return boolean
     * @throws \Exception
     */
    public function changePoint($mid, $pointChange, $freezeChange, $callback=null){
        $memberMp = \Mapper\MemberModel::getInstance();
        //旧资金
        $memberOld = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberOld)){
            return false;
        }
        //修改
        $sql = 'update '.$memberMp->getTable().' set freeze=freeze' . ($freezeChange>0?'+':'-') . abs($freezeChange) . ',point=point' . ($pointChange>0?'+':'-') . abs($pointChange) . ' where id=' . $mid . ($freezeChange>0?'':' AND freeze>='.abs($freezeChange)) . ($pointChange>0?'':' AND point>='.abs($pointChange));
        $memberMp->begin();
        try {
            $resultObj = $memberMp->query($sql);
            $effectedRows = $resultObj->getAffectedRows();
            if ($effectedRows == 1 || ($pointChange==0 && $freezeChange==0)) {
                $result = true;
            } else {
                throw new \Ku\Exception('修改失败');
            }
        } catch (\Exception $ex) {
            $this->setResult(14);
            $result = false;
        }

        //新资金
        $memberNew = $memberMp->fetchArray(['id'=>$mid], null, 0, ['freeze', 'point']);
        if(empty($memberNew)){
            $this->setResult(14, $memberNew);
            $result = false;
        }
        //做回调
        if ($result === true && is_callable($callback) && call_user_func_array($callback, array($this)) === false) {
            $this->setResult(14, 'callback');
            $result = false;
        }
        //记录日志
        $cate = isset($this->_params['cate']) ? $this->_params['cate'] : 'changePoint';
        $aid = isset($this->_params['aid']) ? $this->_params['aid'] : 0;
        $attach = isset($this->_params['attach']) ? $this->_params['attach'] : '';
        if ($result === true && $this->addFlow($mid, $cate, $aid, $attach, $memberOld['freeze'], $memberNew['freeze'], $memberOld['point'], $memberNew['point']) === true) {
            $memberMp->commit();
            return true;
        }
        //失败回滚
        $memberMp->rollback();
        return false;
    }

    static public $_payCates = [
        'unknow'=>'未支付完成', 
        'alipaypage'=>'支付宝', 
        'weixinpay'=>'微信支付', 
        'companypay'=>'转账支付',
        'coupon'=>'兑换券',
    ];

    static public $_couponTypes = [
        1=>'兑换券',
        2=>'打折券',
        3=>'满减券',
        4=>'满送券',
    ];

    static public $_flowCates = [
        'income'=>'收入',
        'freeze'=>'冻结',
        'payout'=>'支出',
        'freePayout'=>'冻结款支出',
        'changePoint'=>'修改',
        
        'task'=>'任务相关',
        'prepay'=>'预扣款',
        'rechange'=>'充值',
        'deduction'=>'扣款',
    ];

    /**
     * 用户资金流水表
     * 
     * @param type $mid 被操作者id
     * @param type $cate 分类
     * @param type $aid 操作者id
     * @param type $attach 操作附带参数
     * @param type $freezeOld 旧冻结
     * @param type $freezeNew 新冻结
     * @param type $pointOld 旧积分
     * @param type $pointNew 新积分
     */
    public function addFlow($mid, $cate, $aid, $attach, $freezeOld, $freezeNew, $pointOld, $pointNew) {        
        $freezeChange = bcsub($freezeNew, $freezeOld, 3);
        $pointChange = bcsub($pointNew, $pointOld, 3);
        if($freezeChange==0 && $pointChange==0){
            return true;
        }

        $time = date('YmdHis');
        $ip = \Ku\Tool::getClientIp(FALSE, TRUE);
        $location = '';
        $ip138Token = \Yaf\Registry::get('config')->get('ip138token');
        if (strlen($ip138Token)>0) {
            $url = 'http://api.ip138.com/query/?ip=' . $ip . '&datatype=jsonp';
            $http = new \Ku\Http();
            $http->setUrl($url);
            $http->setHttpheader(array('token: '.$ip138Token));
            $ip138Data = \json_decode($http->send(), true);
            if (isset($ip138Data['ret']) && $ip138Data['ret'] == 'ok') {
                 $location = implode('', $ip138Data['data']);
            }
        }

        $memberFlowMp = \Mapper\MemberflowModel::getInstance();
        $memberFlowMdl = new \MemberflowModel();
       
        $memberFlowMdl->setMid($mid);
        $memberFlowMdl->setCate($cate);
        $memberFlowMdl->setAid($aid);
        $memberFlowMdl->setAttach($attach);
        $memberFlowMdl->setFreezeOld($freezeOld);
        $memberFlowMdl->setFreezeNew($freezeNew);
        $memberFlowMdl->setPointOld($pointOld);
        $memberFlowMdl->setPointNew($pointNew);
        $memberFlowMdl->setFreezeChange($freezeChange);
        $memberFlowMdl->setPointChange($pointChange);
        $memberFlowMdl->setAddtime($time);
        $memberFlowMdl->setIp($ip);
        $memberFlowMdl->setLocation($location);

        $result = $memberFlowMp->insert($memberFlowMdl);
        return $result > 0 ? true : false;
    }

}
