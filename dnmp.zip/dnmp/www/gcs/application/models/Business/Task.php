<?php
namespace Business;

class TaskModel extends \Business\AbstractModel
{
    use \Base\Model\InstanceModel;

    // 错误信息
    protected $_resultPlus = 1100;
    protected $_resultMsg = array(
        0 => '未知',
        1 => '失败',
        2 => '任务不存在',
        3 => '任务频道不存在',
        4 => '任务运营商不存在',
        5 => '任务类型不存在',
        6 => '任务参数不正确',
        7 => '域名 %s 不允许添加',
        8 => '%s 任务渠道已满%s个',
        9 => '15分钟内禁止重复提交任务',
        80 => '成功',
    );

    // redis队列
    protected $_redis;
    protected $_time;

    // 频道前缀
    public $_redisPrefix = 'task:channel:';

    // 域名黑名单
    const BLACKDOMAINS = 'blackdomain';

    function __construct(){
        //parent::__construct();
        $this->_redis = $this->getRedis();
        $this->_time = time();
    }

    //增加一个任务进数据库
    public function push($mid, $type, $param, $action, $channels, $require){
        $YmdHis = date('YmdHis');
        $redis = $this->getRedis();
        //获取参数
        if($type!='url'){
            return $this->setResult(6, ['type'=>$type]);
        }
        if(!is_array($param) || !isset($param['url'])){
            return $this->setResult(6, ['param'=>$param]);
        }
        if(strpos($param['url'], 'http')!==0){
            $param['url'] = 'http://'.$param['url'];
        }
        $toolBs = \Business\ToolModel::getInstance();
        if(!$toolBs->getUrlInfo($param['url'])){
            return $this->setResult(6, ['url'=>$param['url']]);
        }
        $urlInfo = $toolBs->getResultData();
        //禁止重复提交
        $repeatKey = 'repeat:'.$mid.':'.md5($urlInfo['url']);
        if($redis->get($repeatKey)){
            return $this->setResult(9);
        }

        if(empty($urlInfo['path'])&&empty($urlInfo['query'])&&empty($urlInfo['fragment'])){
            $param['url'] = $param['url'].'/';
        }
        foreach($param as $key=>$value){
            if(!isset($this->_params[$key])){
                return $this->setResult(6, ['param'=>$key]);
            }
        }

        //黑名单
        $blackDomains = $redis->ZRANGE(self::BLACKDOMAINS, 0, -1);
        if(in_array($urlInfo['host'], $blackDomains)){
            return $this->setResult(7, ['assign'=>$urlInfo['host']]);
        }
        foreach($blackDomains as $blackDomain){
            if(strpos($blackDomain, '*')!==false && strpos(strrev($urlInfo['host']), strrev(ltrim($blackDomain, '*')))===0){
                return $this->setResult(7, ['assign'=>$urlInfo['host']]);
            }
        }

        //获取内容
        if(!is_array($action)){
            $action = [];
        }
        if(!in_array('title', $action)){
            $action[] = 'title';
        }
        if(!in_array('keywords', $action)){
            $action[] = 'keywords';
        }
        if(!in_array('description', $action)){
            $action[] = 'description';
        }
        if(!in_array('originsource', $action)){
            $action[] = 'originsource';
        }
        foreach($action as $value){
            if(!isset($this->_actions[$value])){
                return $this->setResult(6, ['action'=>$value]);
            }
        }

        //获取频道
        if(!is_array($channels) || empty($channels)){
            return $this->setResult(6, ['channels'=>$channels]);
        }
        $channelNum = 0;
        $cityFlag = null;
        $operatorFlag = null;
        //频道处理
        foreach($channels as $channel=>$num){
            $country = substr($channel, 0, 2);
            $city = substr($channel, 2, 6);
            if($city==='000000'){
                $cityFlagTmp = 1;//地区随机
            }elseif(in_array($city, ['110000', '120000', '310000', '500000', '810000', '820000'])){
                $cityFlagTmp = 4;//特殊随地区
            }elseif(substr($city, 2, 4)==='0000'){
                $cityFlagTmp = 2;//分省
            }elseif(substr($city, 4, 2)==='00'){
                $cityFlagTmp = 3;//分市
            }else{
                return $this->setResult(6);//分县区
            }
            //var_dump([$cityFlag, $cityFlagTmp]);
            if($cityFlag===null){
                $cityFlag = $cityFlagTmp;
            }elseif($cityFlagTmp===4 && in_array($cityFlag, [2, 3])){

            }elseif($cityFlag===4 && in_array($cityFlagTmp, [2, 3])){
                $cityFlag = $cityFlagTmp;
            }elseif($cityFlag != $cityFlagTmp){
                return $this->setResult(6, [$cityFlag, $cityFlagTmp]);
            }

            $operator = substr($channel, 8, 2);
            if($operatorFlag == null){
                $operatorFlag = $operator=='qb' ? 1 : 2;
            }elseif($operatorFlag != ($operator=='qb' ? 1 : 2)){
                return $this->setResult(6, 'operatorFlag');
            }

            if(!isset($this->_areas[$country][$city]) || !isset($this->_operators[$operator])){
                return $this->setResult(6, ['channels'=>$channel]);
            }
            if(!is_numeric($num) || $num<1){
                return $this->setResult(6, ['channels'=>$channel]);
            }
            $channelNum += $num;
        }
        if(!is_array($require)){
            $require = [];
        }
        //exit;
        //生成任务
        $taskMdl = new \TaskModel;
        $taskMdl->setMid($mid);
        $taskMdl->setType('url');
        $taskMdl->setParam(\json_encode($param));
        $taskMdl->setAction(\json_encode($action));
        $taskMdl->setChannel(\json_encode($channels));
        $taskMdl->setnum($channelNum);
        $taskMdl->setFinish(0);
        $taskMdl->setPoint(0);
        $taskMdl->setRequire(\json_encode($require));
        $taskMdl->setStatus(0);//未付款
        $taskMdl->setAddtime($YmdHis);
        $taskMdl->setUptime($YmdHis);
        //计算积分
        $freeze = $this->payCount($taskMdl);
        $taskMdl->setFreeze($freeze);

        //预付款
        $amount = $taskMdl->getFreeze();
        $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
        $result = $memberBs->freeze($mid, $amount, function($memberBs)use($mid, &$taskMdl, $redis, $YmdHis, $repeatKey){
            $taskMdl->setUptime($YmdHis);
            $taskMdl->setStatus(1);//等待频道分发
    
            $taskMp = \Mapper\TaskModel::getInstance();
            $tid = $taskMp->insert($taskMdl);
            if(!$tid){
                return $memberBs->setResult(0, '任务生成失败');
            }
            $taskMdl->setId($tid);

            //$redis->del($repeatKey);
            $redis->set($repeatKey, 1);
            $redis->expire($repeatKey, 900);

            //流水日志参数
            $memberBs->resetParam();
            $memberBs->setParam([
                'cate' => 'prepay',
                'aid' => $mid,
                'attach' => $taskMdl->getId(),
            ]);

            return true;
        });
        if(!$result){
            return $this->setResult($memberBs->getResultMsg(), $memberBs->getResultData());
        }

        return $this->setResult(80, $this->parseTask($taskMdl));
    }

    //为任务预付款
    public function prepay($mid, $id){
        $YmdHis = date('YmdHis');

        $taskMp = \Mapper\TaskModel::getInstance();
        $taskMdl = $taskMp->fetch(['id'=>$id, 'status'=>0], 'id ASC');
        if(!$taskMdl instanceof \TaskModel){
            return $this->setResult(1);
        }

        $amount = $taskMdl->getFreeze();
        $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
        $result = $memberBs->freeze($mid, $amount, function($memberBs)use($mid, &$taskMdl, $YmdHis){
            $taskMdl->setUptime($YmdHis);
            $taskMdl->setStatus(1);//等待频道分发
    
            $taskMp = \Mapper\TaskModel::getInstance();
            if(!$taskMp->update($taskMdl)){
                return $memberBs->setResult(17);
            }

            //流水日志参数
            $memberBs->resetParam();
            $memberBs->setParam([
                'cate' => 'prepay',
                'aid' => $mid,
                'attach' => $taskMdl->getId(),
            ]);

            return true;
        });
        if(!$result){
            return $this->setResult($memberBs->getResultMsg(), $memberBs->getResultData());
        }
        
        return $this->setResult(80, $this->parseTask($taskMdl));
    }

    //从任务数据库取任务放入频道
    public function processTask(){
        $YmdHis = date('YmdHis');
        $redis = $this->_redis;

        $taskMp = \Mapper\TaskModel::getInstance();
        $taskMdl = $taskMp->fetch(['status'=>1], 'id ASC');
        if(!$taskMdl instanceof \TaskModel){
            return $this->setResult(2);
        }
        $tid = $taskMdl->getId();
        //获取等待下发的渠道
        $channels = \json_decode($taskMdl->getChannel(), true);
        if(!is_array($channels)){
            return $this->setResult(2);
        }
        //渠道已满暂时下发
        foreach($channels as $channel=>$num){
            $country = substr($channel, 0, 2);
            $city = substr($channel, 2, 6);
            $operator = substr($channel, 8, 2);
            if(isset($this->_areas[$country][$city]) && isset($this->_operators[$operator])){
                $channelKey = $this->_redisPrefix.$country.$city;
                /**
                 * https://blog.ernest.me/post/redis-hgetall-order-issue
                 * https://blog.51cto.com/fulin0532/2347485
                 * 创建空白哈希表时， 程序默认使用 REDIS_ENCODING_ZIPLIST 编码， 当以下任何一个条件被满足时， 程序将编码从 REDIS_ENCODING_ZIPLIST 切换为 REDIS_ENCODING_HT ：
                 * 哈希表中某个键或某个值的长度大于 server.hash_max_ziplist_value （默认值为 64 ）。
                 * 压缩列表中的节点数量大于 server.hash_max_ziplist_entries （默认值为 512 ）。
                 * ziplist 是一个双向链表，所以是顺序的
                 * hashtable的编码格式。是无序的
                 * 等待的数量过大无法及时完成，造成大量失败结束
                 */
                if($redis->HLEN($channelKey)>300){
                    return $this->setResult(8, ['assign'=>[$channelKey, 300]]);
                }
            }
        }

        //修改并下发
        $taskMp = \Mapper\TaskModel::getInstance();
        $taskMdl->setUptime($YmdHis);
        $taskMdl->setStatus(2);//等待回收
        if($taskMp->update($taskMdl)){
            foreach($channels as $channel=>$num){
                $country = substr($channel, 0, 2);
                $city = substr($channel, 2, 6);
                $operator = substr($channel, 8, 2);
                if(isset($this->_areas[$country][$city]) && isset($this->_operators[$operator])){
                    //任务放入每个频道
                    $channelKey = $this->_redisPrefix.$country.$city;
                    $operatorTid = $operator.$tid;
                    if(!$redis->HEXISTS($channelKey, $operatorTid)){
                        $redis->hset($channelKey, $operatorTid, $num);
                    }
                }else{
                    var_dump([__CLASS__, __METHOD__, '非法渠道', $this->_redisPrefix.$country.$city, $operator.$tid, $num]);
                }
            }
            return $this->setResult(80, $this->parseTask($taskMdl));
        }
        return $this->setResult(0);
    }

    //从频道中取任务
    public function pop($ext, $area, $operator){
        $redis = $this->_redis;
        //目前频道只支持到市级
        $area = substr($area, 0, 6).'00';

        //任务渠道频道
        $country = substr($area, 0, 2);
        $city = substr($area, 2, 6);
        if(!isset($this->_areas[$country][$city])){
            return $this->setResult(3, $area);
        }
        //任务运营商
        if(!isset($this->_operators[$operator])){
            return $this->setResult(4, $operator);
        }

        //符合地区条件的频道
        $channelKeys  = array_unique([
            $this->_redisPrefix.$area,//县
            $this->_redisPrefix.substr($area, 0, 6).'00',//市
            $this->_redisPrefix.substr($area, 0, 4).'0000',//省
            $this->_redisPrefix.substr($area, 0, 2).'000000',//国家
        ]);

        $taskMdl = null;
        foreach($channelKeys as $channelKey){
            //频道暂未被标记
            if($redis->EXISTS($channelKey) && !$redis->SISMEMBER('task:channels', $channelKey)){
                //标记频道
                $redis->SADD('task:channels', $channelKey);
                //频道内符合运营商条件的任务
                $operatorTids = $redis->HGETALL($channelKey);
                //var_dump([$channelKey, $operatorTids]);
                if(!empty($operatorTids)){
                    foreach($operatorTids as $operatorTid => $num){
                        //判断运营商
                        if(!in_array(substr($operatorTid, 0, 2), ['qb', $operator])){
                            continue;
                        }
                        //判断重复取任务
                        $tid = substr($operatorTid, 2);
                        if($redis->EXISTS('task:pending:'.$tid)){
                            //同插件不允许重复取的任务
                            $pendingExt = $redis->HGET('task:pending:'.$tid, $ext);
                            if($pendingExt!==false && $pendingExt < 0){
                                continue;
                            }

                            //同地区运营商不允许重复取的任务
                            $pendingChannel = $redis->HGET('task:pending:'.$tid, $area.$operator);
                            if($pendingChannel!==false && $pendingChannel < 0){
                                continue;
                            }
                        }
                        
                        //获取任务
                        $taskMp = \Mapper\TaskModel::getInstance();
                        $taskMdl = $taskMp->fetch(['id'=>$tid, 'status'=>2]);
                        if(!$taskMdl instanceof \TaskModel){
                            $redis->HDEL($channelKey, $operatorTid);
                            continue;
                        }
                        
                        //任务剩余量
                        $num = $redis->HINCRBY($channelKey, $operatorTid, -1);
                        if($num <= 0){
                            $redis->HDEL($channelKey, $operatorTid);
                        }
                        //任务参数获取
                        $params = \json_decode($taskMdl->getParam(), true);

                        //等待完成任务，同时记录同插件是否允许重复取
                        $allowRepeat = 1;//正数允许重复取任务
                        if(is_array($params) && isset($params['allowrepeat']) && $params['allowrepeat']==false){
                            $allowRepeat = -1;//负数不允许重复取任务
                        }
                        if($redis->EXISTS('task:pending:'.$tid)){
                            $redis->HINCRBY('task:pending:'.$tid, $ext, $allowRepeat);
                        }else{
                            $redis->HSET('task:pending:'.$tid, $ext, $allowRepeat);
                            $redis->EXPIRE('task:pending:'.$tid, 86400);//保存一天，超过一小时的$this->processPending()会处理
                        }

                        //同地区运营商是否允许重复取
                        $allowRepeatChannel = 1;//正数允许重复取任务
                        if(is_array($params) && isset($params['allowrepeatchannel']) && $params['allowrepeatchannel']==false){
                            $allowRepeatChannel = -1;//负数不允许重复取任务
                        }
                        if($redis->EXISTS('task:pending:'.$tid)){
                            $redis->HINCRBY('task:pending:'.$tid, $area.$operator, $allowRepeatChannel);
                        }else{
                            $redis->HSET('task:pending:'.$tid, $area.$operator, $allowRepeatChannel);
                            $redis->EXPIRE('task:pending:'.$tid, 86400);//保存一天，超过一小时的$this->processPending()会处理
                        } 

                        //获取频道任务
                        $channel = str_replace( $this->_redisPrefix, '', $channelKey).substr($operatorTid, 0, 2);
                        break;
                    }
                }
                
                //取消标记频道
                $redis->SREM('task:channels', $channelKey);
                //已经获取任务
                if($taskMdl instanceof \TaskModel){
                    break;
                }
            }
        }
        if($taskMdl instanceof \TaskModel){
            return $this->setResult(80, ['task'=>$this->parseTask($taskMdl), 'channel'=>$channel, 'info'=>[$ext, $area, $operator]]);
        }

        return $this->setResult(2);
    }

    //处理长时间(20分钟)等待完成的任务
    public function processPending(){
        $YmdHis = date('YmdHis');
        $redis = $this->_redis;

        $results = [];
        $taskMp = \Mapper\TaskModel::getInstance();
        $taskBs = \Business\TaskModel::getInstance();
        $taskMdls = $taskMp->fetchAll(['status'=>2, 'uptime < ?'=>date('YmdHis', time()-1200)],['id desc']);
        $memberBs = new \Business\MemberModel(\Base\ApplicationController::$_allow_login_agent_num);
        $resultMp = \Mapper\TaskresulturlModel::getInstance();
        foreach($taskMdls as $taskMdl){
            //用户
            $mid = $taskMdl->getMid();
            //冻结的积分
            $freeze = $taskMdl->getFreeze();
            //需要扣除的积分
            $channelNum = $resultMp->count(['tid'=>$taskMdl->getId()]);
            $amount = $this->payCount($taskMdl, $channelNum);
            if($amount>$freeze){
                $amount = $freeze;
            }
            //从冻结中扣除积分，剩余的取消冻结
            $result = $memberBs->freePayout($mid, $freeze, $amount, function($memberBs)use($mid, $taskMp, $taskBs, &$taskMdl, $channelNum, $amount, $YmdHis, $redis){
                //设置结果
                $status = $channelNum==$taskMdl->getNum()?3:4;
                $taskMdl->setUptime($YmdHis);
                $taskMdl->setStatus($status);//失败
                $taskMdl->setFinish($channelNum);
                $taskMdl->setPoint($amount);
                if(!$taskMp->update($taskMdl)){
                    return $memberBs->setResult(17);
                }

                //删除任务队列
                $task = $taskBs->parseTask($taskMdl);
                foreach($task['channel'] as $channel => $num){
                    $countryArea = substr($channel, 0, 8);
                    $countryAreaKey = $this->_redisPrefix.$countryArea;
                    $operator = substr($channel, 8, 2);
                    $tid = $task['id'];
                    $operatorTid = $operator.$tid;
                    $redis->hdel($countryAreaKey, $operatorTid);
                }
    
                //流水日志参数
                $memberBs->resetParam();
                $memberBs->setParam([
                    'cate' => 'deduction',
                    'aid' => $mid,
                    'attach' => $taskMdl->getId(),
                ]);
    
                return true;
            });

            //结束完成发送短信通知
            if($result){
                $memberMp = \mapper\MemberModel::getInstance();
                $memberMdl = $memberMp->fetch(['id'=>$taskMdl->getMid()]);
                if($memberMdl instanceof \memberModel){
                    $toolBs = \Business\ToolModel::getInstance();
                    $toolBs->short($taskMdl->getId());
                    $short = $toolBs->getResultData()[0];

                    $msg = '{"time":"' . date('Y-m-d H:i:s', strtotime($taskMdl->getUptime())) . '","name":"' . $short . '"}';
                    $smser = new \Ku\Sms\Adapter('alisms');
                    $driver = $smser->getDriver();
                    $driver->setMsg($msg);
                    $driver->setChannel('short');
                    $driver->setPhones($memberMdl->getMobile());
                    $driver->send();
                }
            }  

            $results[$taskMdl->getId()] = $result;
        }
        return $results;
    }

    //计算任务所需积分
    public function payCount(\taskModel $taskMdl, $channelNum = null){
        $point = 0;

        $task = $this->parseTask($taskMdl);
        if($task['type']=='url'){
            //基础扣费
            $basePoint = 20;
            //参数扣费
            if(isset($task['param']['delay']) && $task['param']['delay']>10){
                $basePoint += ($task['param']['delay']-10)*1;
            }
            if(isset($task['param']['allowrepeat']) && $task['param']['allowrepeat']==false){
                $basePoint += 0;
            }
            
            //功能扣费
            $basePoint += count($task['action'])*10;
            if(in_array('title', $task['action'])){
                $basePoint -= 10;
            }
            if(in_array('keywords', $task['action'])){
                $basePoint -= 10;
            }
            if(in_array('description', $task['action'])){
                $basePoint -= 10;
            }
            if(in_array('originsource', $task['action'])){
                $basePoint -= 10;
            }
            if(in_array('screen', $task['action'])){
                $basePoint += 10;
            }
            //要求扣费
            $basePoint += count($task['require'])*1;
           
            //频道扣费
            if($channelNum===null){
                foreach($task['channel'] as $channel=>$num){
                    $point += $basePoint*$num;
                }
            }else{
                $point += $basePoint*$channelNum;
            }
        }

        return $point > 0 ? $point : 0;
    }

    public function check($tid, $ext, $area, $operator){
        $redis = $this->_redis;

        //存在等待返回
        $pending = $redis->HGET('task:pending:'.$tid, $ext);
        if($pending!==false){
            return $this->setResult(80);
        }

        return $this->setResult(2, [$tid, $ext, $area, $operator]);
    }

    public function finish($tid, $ext, $area, $operator){
        return $this->setResult(80);
    }

    //任务提交，失败处理
    public function fail($tid, $ext, $area, $operator){
        $redis = $this->_redis;

        $channel = $area;
        $operatorTid = $operator.$tid;
        $redis->HINCRBY($channel, $operatorTid, 1);

        return $this->setResult(80);
    }

    public function parseTask(\TaskModel $taskMdl){
        $task = $taskMdl->toArray();
        $task['channel'] = \json_decode($taskMdl->getChannel(), true);
        $task['param'] = \json_decode($taskMdl->getParam(), true);
        $task['action'] = \json_decode($taskMdl->getAction(), true);
        $task['require'] = \json_decode($taskMdl->getRequire(), true);
        return $task;
    }

    //根据ip获取渠道，只精确到市
    public function getIpChannel($ip){
        $cacheId = $this->cacheId([__CLASS__, __METHOD__, $ip]);
        $channel = $this->getCache($cacheId);
        if(!$channel){
            //默认值
            $country = '';
            $province = '';
            $city = '';
            $operator = '';
            //远程获取
            $http = new \Ku\Http;
            $http->setUrl('http://api.ip138.com/query/?ip='.$ip.'&token=19582512049c5773e9d637778d66ddb8');
            $areaInfo = \json_decode($http->send(), true);
            if(isset($areaInfo['ret']) && $areaInfo['ret']=='ok' && isset($areaInfo['data'][0]) && isset($areaInfo['data'][2])  && isset($areaInfo['data'][3])){
                if(strpos($areaInfo['data'][0], '中国')!==false){
                    $country = 'cn';
                    foreach($this->_areas[$country] as $k => $v){
                        if(strpos($v, $areaInfo['data'][1])!==false){
                            $province = $k;
                        }
                        if(strpos($v, $areaInfo['data'][2])!==false){
                            $city = $k;
                        }
                    }
                }
                $operator = array_search($areaInfo['data'][3], $this->_operators); 
                $channel = ($country?$country:'no').($city?$city:($province?$province:'999999')).($operator?$operator:'no');
                $this->setCache($cacheId, $channel);
            }
        }

        if($channel){
            return $this->setResult(80, $channel);
        }

        return $this->setResult(0);
    }

    //根据ip获取归属地
    public function getIpLocation($ip){
        if(empty($ip)){
            return $this->setResult(0);
        }
        $cacheId = $this->cacheId([__CLASS__, __METHOD__, $ip]);
        $location = $this->getCache($cacheId);
        if(!$location || true){
            //远程获取
            $http = new \Ku\Http;
            $http->setUrl('http://api.ip138.com/query/?ip='.$ip.'&token=19582512049c5773e9d637778d66ddb8');
            $areaInfo = \json_decode($http->send(), true);
            if(isset($areaInfo['ret']) && $areaInfo['ret']=='ok' && isset($areaInfo['data'][1]) && isset($areaInfo['data'][2])  && isset($areaInfo['data'][3])){
                $location = ($areaInfo['data'][0]=='中国'?'':$areaInfo['data'][0]).$areaInfo['data'][1].$areaInfo['data'][2].$areaInfo['data'][3];
                $this->setCache($cacheId, $location);
            }
        }

        if($location){
            return $this->setResult(80, $location);
        }
        

        return $this->setResult(0);
    }

    /**
     * 频道长度状态
     */
    public function status(){
        $status = [];
        $redis = $this->_redis;
        foreach($this->_areas as $country=>$areas){
            foreach($areas as $city=>$name){
                $countryCity = $country.$city;
                $channelKey = $this->_redisPrefix.$countryCity;
                $status[$countryCity] = $redis->HLEN($channelKey);
            }
        }
        return $this->setResult(80, $status);
    }

    public $_statuses = [0=>'未付款', 1=>'等待分发', 2=>'等待接收', 3=>'结束', 4=>'结束'];

    public $_params = ['url'=>'网址', 'referer'=>'来源', 'delay'=>'延迟时间', 'allowrepeat'=>'插件重复任务', 'allowrepeatchannel'=>'地区运营商重复任务',];

    public $_actions = ['title'=>'标题', 'keywords'=>'关键词', 'description'=>'描述', 'originsource'=>'渲染前源码', 'source'=>'渲染后源码', 'screen'=>'截图',];

    public $_countrys = ['cn'=>'中国'];

    public $_operators = ['qb'=>'随机运营商', 'yd'=>'移动', 'lt'=>'联通', 'dx'=>'电信'];

    public $_areas = ['cn'=>['000000'=>'随机地区','110000'=>'北京市','120000'=>'天津市','130000'=>'河北省','130100'=>'石家庄市','130200'=>'唐山市','130300'=>'秦皇岛市','130400'=>'邯郸市','130500'=>'邢台市','130600'=>'保定市','130700'=>'张家口市','130800'=>'承德市','130900'=>'沧州市','131000'=>'廊坊市','131100'=>'衡水市','140000'=>'山西省','140100'=>'太原市','140200'=>'大同市','140300'=>'阳泉市','140400'=>'长治市','140500'=>'晋城市','140600'=>'朔州市','140700'=>'晋中市','140800'=>'运城市','140900'=>'忻州市','141000'=>'临汾市','141100'=>'吕梁市','150000'=>'内蒙古自治区','150100'=>'呼和浩特市','150200'=>'包头市','150300'=>'乌海市','150400'=>'赤峰市','150500'=>'通辽市','150600'=>'鄂尔多斯市','150700'=>'呼伦贝尔市','150800'=>'巴彦淖尔市','150900'=>'乌兰察布市','152200'=>'兴安盟','152500'=>'锡林郭勒盟','152900'=>'阿拉善盟','210000'=>'辽宁省','210100'=>'沈阳市','210200'=>'大连市','210300'=>'鞍山市','210400'=>'抚顺市','210500'=>'本溪市','210600'=>'丹东市','210700'=>'锦州市','210800'=>'营口市','210900'=>'阜新市','211000'=>'辽阳市','211100'=>'盘锦市','211200'=>'铁岭市','211300'=>'朝阳市','211400'=>'葫芦岛市','220000'=>'吉林省','220100'=>'长春市','220200'=>'吉林市','220300'=>'四平市','220400'=>'辽源市','220500'=>'通化市','220600'=>'白山市','220700'=>'松原市','220800'=>'白城市','222400'=>'延边朝鲜族自治州','230000'=>'黑龙江省','230100'=>'哈尔滨市','230200'=>'齐齐哈尔市','230300'=>'鸡西市','230400'=>'鹤岗市','230500'=>'双鸭山市','230600'=>'大庆市','230700'=>'伊春市','230800'=>'佳木斯市','230900'=>'七台河市','231000'=>'牡丹江市','231100'=>'黑河市','231200'=>'绥化市','232700'=>'大兴安岭地区','310000'=>'上海市','320000'=>'江苏省','320100'=>'南京市','320200'=>'无锡市','320300'=>'徐州市','320400'=>'常州市','320500'=>'苏州市','320600'=>'南通市','320700'=>'连云港市','320800'=>'淮安市','320900'=>'盐城市','321000'=>'扬州市','321100'=>'镇江市','321200'=>'泰州市','321300'=>'宿迁市','330000'=>'浙江省','330100'=>'杭州市','330200'=>'宁波市','330300'=>'温州市','330400'=>'嘉兴市','330500'=>'湖州市','330600'=>'绍兴市','330700'=>'金华市','330800'=>'衢州市','330900'=>'舟山市','331000'=>'台州市','331100'=>'丽水市','340000'=>'安徽省','340100'=>'合肥市','340200'=>'芜湖市','340300'=>'蚌埠市','340400'=>'淮南市','340500'=>'马鞍山市','340600'=>'淮北市','340700'=>'铜陵市','340800'=>'安庆市','341000'=>'黄山市','341100'=>'滁州市','341200'=>'阜阳市','341300'=>'宿州市','341500'=>'六安市','341600'=>'亳州市','341700'=>'池州市','341800'=>'宣城市','350000'=>'福建省','350100'=>'福州市','350200'=>'厦门市','350300'=>'莆田市','350400'=>'三明市','350500'=>'泉州市','350600'=>'漳州市','350700'=>'南平市','350800'=>'龙岩市','350900'=>'宁德市','360000'=>'江西省','360100'=>'南昌市','360200'=>'景德镇市','360300'=>'萍乡市','360400'=>'九江市','360500'=>'新余市','360600'=>'鹰潭市','360700'=>'赣州市','360800'=>'吉安市','360900'=>'宜春市','361000'=>'抚州市','361100'=>'上饶市','370000'=>'山东省','370100'=>'济南市','370200'=>'青岛市','370300'=>'淄博市','370400'=>'枣庄市','370500'=>'东营市','370600'=>'烟台市','370700'=>'潍坊市','370800'=>'济宁市','370900'=>'泰安市','371000'=>'威海市','371100'=>'日照市','371200'=>'莱芜市','371300'=>'临沂市','371400'=>'德州市','371500'=>'聊城市','371600'=>'滨州市','371700'=>'菏泽市','410000'=>'河南省','410100'=>'郑州市','410200'=>'开封市','410300'=>'洛阳市','410400'=>'平顶山市','410500'=>'安阳市','410600'=>'鹤壁市','410700'=>'新乡市','410800'=>'焦作市','410900'=>'濮阳市','411000'=>'许昌市','411100'=>'漯河市','411200'=>'三门峡市','411300'=>'南阳市','411400'=>'商丘市','411500'=>'信阳市','411600'=>'周口市','411700'=>'驻马店市','420000'=>'湖北省','420100'=>'武汉市','420200'=>'黄石市','420300'=>'十堰市','420500'=>'宜昌市','420600'=>'襄阳市','420700'=>'鄂州市','420800'=>'荆门市','420900'=>'孝感市','421000'=>'荆州市','421100'=>'黄冈市','421200'=>'咸宁市','421300'=>'随州市','422800'=>'恩施土家族苗族自治州','430000'=>'湖南省','430100'=>'长沙市','430200'=>'株洲市','430300'=>'湘潭市','430400'=>'衡阳市','430500'=>'邵阳市','430600'=>'岳阳市','430700'=>'常德市','430800'=>'张家界市','430900'=>'益阳市','431000'=>'郴州市','431100'=>'永州市','431200'=>'怀化市','431300'=>'娄底市','433100'=>'湘西土家族苗族自治州','440000'=>'广东省','440100'=>'广州市','440200'=>'韶关市','440300'=>'深圳市','440400'=>'珠海市','440500'=>'汕头市','440600'=>'佛山市','440700'=>'江门市','440800'=>'湛江市','440900'=>'茂名市','441200'=>'肇庆市','441300'=>'惠州市','441400'=>'梅州市','441500'=>'汕尾市','441600'=>'河源市','441700'=>'阳江市','441800'=>'清远市','441900'=>'东莞市','442000'=>'中山市','445100'=>'潮州市','445200'=>'揭阳市','445300'=>'云浮市','450000'=>'广西壮族自治区','450100'=>'南宁市','450200'=>'柳州市','450300'=>'桂林市','450400'=>'梧州市','450500'=>'北海市','450600'=>'防城港市','450700'=>'钦州市','450800'=>'贵港市','450900'=>'玉林市','451000'=>'百色市','451100'=>'贺州市','451200'=>'河池市','451300'=>'来宾市','451400'=>'崇左市','460000'=>'海南省','460100'=>'海口市','460200'=>'三亚市','460300'=>'三沙市','460400'=>'儋州市','500000'=>'重庆市','510000'=>'四川省','510100'=>'成都市','510300'=>'自贡市','510400'=>'攀枝花市','510500'=>'泸州市','510600'=>'德阳市','510700'=>'绵阳市','510800'=>'广元市','510900'=>'遂宁市','511000'=>'内江市','511100'=>'乐山市','511300'=>'南充市','511400'=>'眉山市','511500'=>'宜宾市','511600'=>'广安市','511700'=>'达州市','511800'=>'雅安市','511900'=>'巴中市','512000'=>'资阳市','513200'=>'阿坝藏族羌族自治州','513300'=>'甘孜藏族自治州','513400'=>'凉山彝族自治州','520000'=>'贵州省','520100'=>'贵阳市','520200'=>'六盘水市','520300'=>'遵义市','520400'=>'安顺市','520500'=>'毕节市','520600'=>'铜仁市','522300'=>'黔西南布依族苗族自治州','522600'=>'黔东南苗族侗族自治州','522700'=>'黔南布依族苗族自治州','530000'=>'云南省','530100'=>'昆明市','530300'=>'曲靖市','530400'=>'玉溪市','530500'=>'保山市','530600'=>'昭通市','530700'=>'丽江市','530800'=>'普洱市','530900'=>'临沧市','532300'=>'楚雄彝族自治州','532500'=>'红河哈尼族彝族自治州','532600'=>'文山壮族苗族自治州','532800'=>'西双版纳傣族自治州','532900'=>'大理白族自治州','533100'=>'德宏傣族景颇族自治州','533300'=>'怒江傈僳族自治州','533400'=>'迪庆藏族自治州','540000'=>'西藏自治区','540100'=>'拉萨市','540200'=>'日喀则市','540300'=>'昌都市','540400'=>'林芝市','540500'=>'山南市','540600'=>'那曲市','542500'=>'阿里地区','610000'=>'陕西省','610100'=>'西安市','610200'=>'铜川市','610300'=>'宝鸡市','610400'=>'咸阳市','610500'=>'渭南市','610600'=>'延安市','610700'=>'汉中市','610800'=>'榆林市','610900'=>'安康市','611000'=>'商洛市','620000'=>'甘肃省','620100'=>'兰州市','620200'=>'嘉峪关市','620300'=>'金昌市','620400'=>'白银市','620500'=>'天水市','620600'=>'武威市','620700'=>'张掖市','620800'=>'平凉市','620900'=>'酒泉市','621000'=>'庆阳市','621100'=>'定西市','621200'=>'陇南市','622900'=>'临夏回族自治州','623000'=>'甘南藏族自治州','630000'=>'青海省','630100'=>'西宁市','630200'=>'海东市','632200'=>'海北藏族自治州','632300'=>'黄南藏族自治州','632500'=>'海南藏族自治州','632600'=>'果洛藏族自治州','632700'=>'玉树藏族自治州','632800'=>'海西蒙古族藏族自治州','640000'=>'宁夏回族自治区','640100'=>'银川市','640200'=>'石嘴山市','640300'=>'吴忠市','640400'=>'固原市','640500'=>'中卫市','650000'=>'新疆维吾尔自治区','650100'=>'乌鲁木齐市','650200'=>'克拉玛依市','650400'=>'吐鲁番市','650500'=>'哈密市','652300'=>'昌吉回族自治州','652700'=>'博尔塔拉蒙古自治州','652800'=>'巴音郭楞蒙古自治州','652900'=>'阿克苏地区','653000'=>'克孜勒苏柯尔克孜自治州','653100'=>'喀什地区','653200'=>'和田地区','654000'=>'伊犁哈萨克自治州','654200'=>'塔城地区','654300'=>'阿勒泰地区','810000'=>'香港特别行政区','820000'=>'澳门特别行政区','830000'=>'台湾省','830100'=>'台北市','830200'=>'新北市','830300'=>'桃园市','830400'=>'台中市','830500'=>'台南市','830600'=>'高雄市','830700'=>'基隆市','830800'=>'新竹市','830900'=>'嘉义市']];

}