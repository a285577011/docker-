<?php

/**
 * Description of Captcha
 *
 */

namespace Business;


use Ku\Logger;
use Mapper\DeviceModel;
use Mapper\DevicePortLogModel;
use Mapper\DevicePortModel;

class FrpModel extends \Business\AbstractModel
{

    use \Base\Model\InstanceModel;

    /**
     * @param $port
     * @param int $type 1frps连接2stf连接
     */
    public static function connPort($port, $server, $type = 1)
    {
        try {
            $status = 2;
            switch ($type) {
                case 2:
                    $status = 1;
                    break;

            }
            DevicePortModel::getInstance()->begin();
            if($deviceData=DevicePortModel::getInstance()->fetchArray(['port'=>$port,'server'=>$server])){
                $update=[];
                $update['status'] = $status;
                $update['server'] = $server;
                $id=$deviceData['id'];
                DevicePortModel::getInstance()->updateWithArray($update,['id'=>$id]);
            }else{
                $insert = [];
                $insert['server'] = $server;
                $insert['device_id'] = 0;
                $insert['port'] = $port;
                $insert['status'] = $status;
                $id=DevicePortModel::getInstance()->insertWithArray($insert);
            }
            $insertLog=[];
            $insertLog['device_port_id']=$id;
            $insertLog['port']=$port;
            $insertLog['server']=$server;
            $insertLog['type']=$type;
            $insertLog['status']=1;
            DevicePortLogModel::getInstance()->insertWithArray($insertLog);
            DevicePortModel::getInstance()->commit();
            return true;
        } catch (\Exception $e) {
            DevicePortModel::getInstance()->rollback();
            Logger::write('connPort', json_encode($e));
            return false;
        }
    }
    /**
     * @param $port
     * @param int $type 1客户机连接frps2stf连接frps
     */
    public static function delPort($port, $server, $type = 1)
    {
        try {
            $deviceData=DevicePortModel::getInstance()->fetchArray(['port'=>$port,'server'=>$server]);
            if($deviceData) {
                DevicePortModel::getInstance()->del(['port' => $port, 'server' => $server]);
                $insertLog = [];
                $insertLog['device_port_id'] = $deviceData['id'];
                $insertLog['port'] = $port;
                $insertLog['server']=$server;
                $insertLog['type'] = $type;
                $insertLog['status'] = 2;
                DevicePortLogModel::getInstance()->insertWithArray($insertLog);
            }
            return true;
        } catch (\Exception $e) {
            Logger::write('delPort', json_encode($e));
            return false;
        }
    }

}
