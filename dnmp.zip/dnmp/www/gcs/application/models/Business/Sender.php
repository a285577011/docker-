<?php

namespace Business;

final class SenderModel extends \Business\AbstractModel {

    use \Base\Model\InstanceModel;
    
    public function sendSms($mobile, $channel) {
        $memberModel = \Mapper\MemberModel::getInstance()->findByMobile($mobile);

        return ($memberModel instanceof \MemberModel ? true : false);
    }

    /**
     * 注册
     *
     * @param number $mobile
     * @return boolean
     */
    public function reg($mobile) {
        if ($this->checkMobile($mobile) === true) {
            return $this->setResult(23213);
        }

        return true;
    }

    /**
     * 忘记密码
     *
     * @param number $mobile
     * @return boolean
     */
    public function resetpassword($mobile) {
        if ($this->checkMobile($mobile) === false) {
            return $this->setResult(23215);
        }

        return true;
    }

    /**
     * 修改手机
     *
     * @param number $mobile
     * @return boolean
     */
    public function changemobile($mobile) {
        if ($this->checkMobile($mobile) === true) {
            return $this->setResult(23213);
        }

        return true;
    }

    /**
     * 检查手机号是否已存在
     *
     * @param string $mobile
     * @return string
     */
    public function checkMobile($mobile) {
        $memberModel = \Mapper\MemberModel::getInstance()->findByMobile($mobile);

        return ($memberModel instanceof \MemberModel ? true : false);
    }

}
