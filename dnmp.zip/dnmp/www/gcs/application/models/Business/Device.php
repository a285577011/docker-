<?php


namespace Business;


use Base\ApiController;
use Ku\Logger;
use Mapper\DevicePortModel;

class DeviceModel extends \Business\AbstractModel
{

    use \Base\Model\InstanceModel;

    /**
     * 连接frps回调初始化设备信息
     */
    public  function connCallback($port,$server){
        $imie=ApiController::getImie();
        try {
            \Mapper\DeviceModel::getInstance()->begin();
            $deviceData=\Mapper\DeviceModel::getInstance()->fetchArray(['imie'=>$imie]);
            if(!$deviceData){
                $insert = [];
                $insert['name'] = $imie;
                $insert['imie'] = $imie;
                $deviceId=\Mapper\DeviceModel::getInstance()->insertWithArray($insert);
            }else{
                $deviceId=$deviceData['id'];
            }
            $devicePortData=DevicePortModel::getInstance()->fetchArray(['port'=>$port,'server'=>$server]);
            if(!$devicePortData){
                Logger::write('connCallback', '端口:'.$port.' frps异步回调数据未通知或者异常');
                $insert = [];
                $insert['server'] = $server;
                $insert['device_id'] = $deviceId;
                $insert['port'] = $port;
                $insert['status'] = 2;
                $id=DevicePortModel::getInstance()->insertWithArray($insert);
            }else{
                $update=[];
                $update['status'] = 2;
                $update['device_id'] = $deviceId;
                DevicePortModel::getInstance()->updateWithArray($update,['id'=>$devicePortData['id']]);
            }
            \Mapper\DeviceModel::getInstance()->commit();
            return true;
        } catch (\Exception $e) {
            \Mapper\DeviceModel::getInstance()->rollback();
            Logger::write('connCallback', json_encode($e));
            return false;
        }
    }

}
