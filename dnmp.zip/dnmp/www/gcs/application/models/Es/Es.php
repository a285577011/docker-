<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2017/11/6
 * Time: 10:05
 */

namespace Es;

use \Ku\ElasticSearch\Client;

class EsModel
{
    private $es = null;
    const SERVER="http://elastic:changeme@192.168.66.191:9200";
    public function __construct($index, $type)
    {
        $esServer = self::SERVER;
        // 如果是多个则随机取一个
        if (is_array($esServer)) {
            $esServer = $esServer[mt_rand(0, count($esServer) - 1)];
        }
        $url = implode('/', [$esServer, $index, $type]);
        $this->es = Client::connection($url);
    }

    /**
     * @return \Ku\ElasticSearch\Client|null
     */
    public function getEs()
    {
        return $this->es;
    }

    public function setEsByUrl($configUrl)
    {
        $this->es = Client::connection($configUrl);
        return $this->es;
    }
}