<?php
/**
 */

namespace Es;


class ElasticBaseModel
{
    protected $esIndexName = '';
    protected $esIndexType = '_doc';

    protected $es;

    public function __construct()
    {
        $this->es = $this->getEs();
    }

    protected function makeFilterQuery($source, $and, $or, $notIn, $sort = null, $size = 2000, $offset = 0)
    {
        $filter = [];
        foreach ($and as $key => $value) {
            $filter[] = $this->getTermClause($key, $value);
        }
        if ($or) {
            foreach ($or as $v) {
                $tmp = [];
                foreach ($v as $k => $v) {
                    $tmp[] = $this->getTermClause($k, $v);
                }
                $filter[] = [
                    'bool' => [
                        'should' => $tmp
                    ]
                ];
            }
        }
        $bool['filter'] = $filter;
        $mustNot = [];
        if ($notIn) {
            foreach ($notIn as $k => $v) {
                $mustNot[] = $this->getTermClause($k, $v);
            }
            $bool['must_not'] = $mustNot;
        }

        $query = [
            'bool' => $bool
        ];

        return $this->makerQuery($query, $source, $sort, $offset, $size);
    }

    protected function makerQuery($query, $source = null, $sort = null, $offset = 0, $size = 1000)
    {
        $q = [
            'query' => $query,
            'size' => $size,
            'from' => $offset,
            "_source" => $source
        ];
        if ($sort) {
            $q['sort'] = $sort;
        }
        if (isset($_GET['es_test_dump4'])) {
            var_dump(json_encode($q));
        }

        return $q;
    }

    protected function getTermClause($key, $value)
    {
        if (is_array($value)) {
            $clause = [
                'terms' => [
                    $key => $value
                ]
            ];
        } else {
            $clause = [
                'term' => [
                    $key => $value
                ]
            ];
        }
        return $clause;
    }

    protected function getEs()
    {
        $es = new EsModel($this->esIndexName, $this->esIndexType);
        return $es->getEs();
    }

    protected function search($query)
    {
        $rs = $this->es->search($query, ['filter_path' => 'hits.hits._id,hits.hits._source,took,timed_out']);
        if (!$rs || isset($rs['error']) || $rs['timed_out']) {
            return false;
        } elseif (!isset($rs['hits']['hits']) || empty($rs['hits']['hits'])) {
            return [];
        }

        $hits = $rs['hits']['hits'];
        return $hits;
    }

    //es搜索
    public function searchQuery($conditions = array(), $offset = 0, $limit = 20, $columns = array(), $order = array('field' => 'id', 'sort' => 'desc'))
    {
        $params = [
            "query" => [
                "bool" => [
                    'filter' => [
                    ],
                    'must' => [

                    ],
                ],
            ],
            'sort' => [
                $order['field'] => [
                    'order' => $order['sort'],
                ],
            ],
            '_source' => $columns,
            'from' => $offset,
            'size' => $limit,
        ];

        if (!empty($conditions)) {
            foreach ($conditions as $k => $v) {
                switch (true) {
                    case is_array($v):
                        if ($v[0] == 'like') {//like查询
                            $params['query']['bool']['must'][]['wildcard'][$k] = $v[1];
                        } elseif ($v[0] == 'fc') {//分词搜索(单词拆分)
                            $params['query']['bool']['must'][]['match'][$k] = $v[1];
                        } elseif ($v[0] == 'between') {
                            if(isset($v[1])){
                                $params['query']['bool']['filter'][]['range'][$k]['gte'] = $v[1];
                            }
                            if(isset($v[2])){
                                $params['query']['bool']['filter'][]['range'][$k]['lte'] = $v[2];
                            }
                        } else {//in查询
                            $params['query']['bool']['filter'][]['terms'][$k] = $v;
                        }
                        break;
                    default://非数组=绑定 适用于完全精确匹配，范围检索。 filter
                        $params['query']['bool']['filter'][]['term'][$k] = $v;
                        break;
                }
                /*switch ($v['type']) {
                    case 'between':
                        $params['query']['bool']['filter']['must'][]['range'][$v['field']]['gt'] = $v['value'][0];
                        $params['query']['bool']['filter']['must'][]['range'][$v['field']]['lt'] = $v['value'][1];
                        break;
                    case '>':
                        $params['query']['bool']['filter']['must'][]['range'][$v['field']]['gt'] = $v['value'];
                        break;
                    case '>=':
                        $params['query']['bool']['filter']['must'][]['range'][$v['field']]['gte'] = $v['value'];
                        break;
                    case '<':
                        $params['query']['bool']['filter']['must'][]['range'][$v['field']]['lt'] = $v['value'];
                        break;
                    case '<=':
                        $params['query']['bool']['filter']['must'][]['range'][$v['field']]['lte'] = $v['value'];
                        break;
                    case '=':
                        $params['query']['bool']['filter'][]['term'][$v['field']] = $v['value'];
                        break;
                    case '!=':
                        $params['query']['bool']['filter']['must_not'][]['term'][$v['field']] = $v['value'];
                        break;
                    case 'in':
                        if (!empty($v['value']) && is_array($v['value'])) {
                            foreach ($v['value'] as $m => $n) {
                                $params['query']['bool']['filter']['must'][] = array(
                                    'term' => array(
                                        $v['field'] => $n,
                                    ),
                                );
                            }
                        }
                        break;
                    case 'not in':
                        if (!empty($v['value']) && is_array($v['value'])) {
                            foreach ($v['value'] as $m => $n) {
                                $params['query']['bool']['filter']['must_not'][] = array(
                                    'term' => array(
                                        $v['field'] => $n,
                                    ),
                                );
                            }
                        }
                        break;
                    case 'like':
                        $params['query']['bool']['must'][]['match'][$v['field']] = $v['value'];
                        unset($params['sort']);
                        $params['sort']['_score']['order'] = 'desc';
                        break;
                    default:
                        return false;
                        break;
                }*/
            }
        }
        //$params=['query'=>['match'=>[['id'=>6]]]];
        $res = $this->es->search($params, ['filter_path' => 'hits.hits._id,hits.hits._source,hits.total,took,timed_out']);
        print_r($params);
        $reData['data'] = array();
        if (!empty($res['hits']['hits'])) {
            foreach ($res['hits']['hits'] as $k => $v) {
                $reData['data'][$k] = $v;
            }
        }
        $reData['count'] = !empty($res['hits']['total']) ? $res['hits']['total'] : 0;
        return $reData;
    }

    //es统计数量
    public function count($conditions = array())
    {
        $params = [
            "query" => [
                "filtered" => [
                    'filter' => [
                        'bool' => [
                            'must' => [
                            ],
                        ],
                    ],
                    "query" => [
                        'bool' => [
                            'must' => [

                            ],
                        ],
                    ],
                ],
            ],
        ];
        if (!empty($conditions)) {
            foreach ($conditions as $v) {
                switch ($v['type']) {
                    case 'between':
                        $params['query']['filtered']['filter']['bool']['must'][]['range'][$v['field']]['gt'] = $v['value'][0];
                        $params['query']['filtered']['filter']['bool']['must'][]['range'][$v['field']]['lt'] = $v['value'][1];
                        break;
                    case '>':
                        $params['query']['filtered']['filter']['bool']['must'][]['range'][$v['field']]['gt'] = $v['value'];
                        break;
                    case '>=':
                        $params['query']['filtered']['filter']['bool']['must'][]['range'][$v['field']]['gte'] = $v['value'];
                        break;
                    case '<':
                        $params['query']['filtered']['filter']['bool']['must'][]['range'][$v['field']]['lt'] = $v['value'];
                        break;
                    case '<=':
                        $params['query']['filtered']['filter']['bool']['must'][]['range'][$v['field']]['lte'] = $v['value'];
                        break;
                    case '=':
                        $params['query']['filtered']['filter']['bool']['must'][]['term'][$v['field']] = $v['value'];
                        break;
                    case '!=':
                        $params['query']['filtered']['filter']['bool']['must_not'][]['term'][$v['field']] = $v['value'];
                        break;
                    case 'in':
                        if (!empty($v['value']) && is_array($v['value'])) {
                            foreach ($v['value'] as $m => $n) {
                                $params['query']['filtered']['filter']['bool']['must'][] = array(
                                    'term' => array(
                                        $v['field'] => $n,
                                    ),
                                );
                            }
                        }
                        break;
                    case 'not in':
                        if (!empty($v['value']) && is_array($v['value'])) {
                            foreach ($v['value'] as $m => $n) {
                                $params['query']['filtered']['filter']['bool']['must_not'][] = array(
                                    'term' => array(
                                        $v['field'] => $n,
                                    ),
                                );
                            }
                        }
                        break;
                    case 'like':
                        $params['query']['filtered']['query']['bool']['must'][]['match'][$v['field']] = $v['value'];
                        break;
                    default:
                        return false;
                        break;
                }
            }
        }
        $res = $this->es->search($params, ['filter_path' => 'hits.hits._id,hits.hits._source,took,timed_out']);
        $count = !empty($res['count']) ? $res['count'] : 0;
        return $count;
    }

    public function setIndex($index)
    {
        echo 222;
        die;
        $this->esIndexName = $index;
    }
}