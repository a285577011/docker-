<?php

namespace Redis;

class RedisModel
{
    /**
     * 返回 Redis 实例
     *
     * @return \Redis|null
     */
    public function getRedis($db=13)
    {
        static $_redis = null;

        $redis= $_redis ? : \Yaf\Registry::get('redis');
        $redis->select($db);
        return $redis;
    }
}
