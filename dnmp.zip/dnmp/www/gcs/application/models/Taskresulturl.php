<?php

/**
 * Url任务结果返回表
 * 
 * @Table Schema: gcs
 * @Table Name: task_result_url
 */
class TaskresulturlModel extends \Base\Model\AbstractModel {

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @var int
     */
    protected $_id = null;

    /**
     * Tid
     * 
     * Column Type: int(11) unsigned
     * 
     * @var int
     */
    protected $_tid = null;

    /**
     * 节点名称
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_ext = null;

    /**
     * Version
     * 
     * Column Type: varchar(64)
     * 
     * @var string
     */
    protected $_version = null;

    /**
     * Extip
     * 
     * Column Type: varchar(15)
     * 
     * @var string
     */
    protected $_extip = null;

    /**
     * 节点地区
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_extarea = null;

    /**
     * 节点运营商
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_extoperator = null;

    /**
     * 提交的频道
     * 
     * Column Type: varchar(64)
     * 
     * @var string
     */
    protected $_channel = null;

    /**
     * 节点DNS
     * 
     * Column Type: varchar(15)
     * 
     * @var string
     */
    protected $_dns = null;

    /**
     * 节点浏览器
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_browser = null;

    /**
     * ip所在地址
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_location = null;

    /**
     * 节点ip
     * 
     * Column Type: varchar(15)
     * 
     * @var string
     */
    protected $_ip = null;

    /**
     * 请求的url
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_url = null;

    /**
     * 最后返回的url
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_lasturl = null;

    /**
     * Referer
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_referer = null;

    /**
     * html返回码
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_code = null;

    /**
     * 编码
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_charset = null;

    /**
     * 返回头部
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_header = null;

    /**
     * 内容大小，取header数据
     * 
     * Column Type: int(11) unsigned
     * Default: 0
     * 
     * @var int
     */
    protected $_size = 0;

    /**
     * 返回标题
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_title = null;

    /**
     * 返回关键字
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_keywords = null;

    /**
     * 返回秒速
     * 
     * Column Type: text
     * 
     * @var string
     */
    protected $_description = null;

    /**
     * 截图文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_screen = null;

    /**
     * 渲染后的源码文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_source = null;

    /**
     * 未渲染后的源码文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @var string
     */
    protected $_originsource = null;

    /**
     * Sourcemd5
     * 
     * Column Type: varchar(32)
     * 
     * @var string
     */
    protected $_sourcemd5 = null;

    /**
     * Originsourcemd5
     * 
     * Column Type: varchar(32)
     * 
     * @var string
     */
    protected $_originsourcemd5 = null;

    /**
     * Addtime
     * 
     * Column Type: bigint(20)
     * 
     * @var int
     */
    protected $_addtime = null;

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @param int $id
     * @return \TaskresulturlModel
     */
    public function setId($id) {
        $this->_id = (int)$id;

        return $this;
    }

    /**
     * Id
     * 
     * Column Type: int(11) unsigned
     * auto_increment
     * PRI
     * 
     * @return int
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Tid
     * 
     * Column Type: int(11) unsigned
     * 
     * @param int $tid
     * @return \TaskresulturlModel
     */
    public function setTid($tid) {
        $this->_tid = (int)$tid;

        return $this;
    }

    /**
     * Tid
     * 
     * Column Type: int(11) unsigned
     * 
     * @return int
     */
    public function getTid() {
        return $this->_tid;
    }

    /**
     * 节点名称
     * 
     * Column Type: varchar(255)
     * 
     * @param string $ext
     * @return \TaskresulturlModel
     */
    public function setExt($ext) {
        $this->_ext = (string)$ext;

        return $this;
    }

    /**
     * 节点名称
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getExt() {
        return $this->_ext;
    }

    /**
     * Version
     * 
     * Column Type: varchar(64)
     * 
     * @param string $version
     * @return \TaskresulturlModel
     */
    public function setVersion($version) {
        $this->_version = (string)$version;

        return $this;
    }

    /**
     * Version
     * 
     * Column Type: varchar(64)
     * 
     * @return string
     */
    public function getVersion() {
        return $this->_version;
    }

    /**
     * Extip
     * 
     * Column Type: varchar(15)
     * 
     * @param string $extip
     * @return \TaskresulturlModel
     */
    public function setExtip($extip) {
        $this->_extip = (string)$extip;

        return $this;
    }

    /**
     * Extip
     * 
     * Column Type: varchar(15)
     * 
     * @return string
     */
    public function getExtip() {
        return $this->_extip;
    }

    /**
     * 节点地区
     * 
     * Column Type: varchar(255)
     * 
     * @param string $extarea
     * @return \TaskresulturlModel
     */
    public function setExtarea($extarea) {
        $this->_extarea = (string)$extarea;

        return $this;
    }

    /**
     * 节点地区
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getExtarea() {
        return $this->_extarea;
    }

    /**
     * 节点运营商
     * 
     * Column Type: varchar(255)
     * 
     * @param string $extoperator
     * @return \TaskresulturlModel
     */
    public function setExtoperator($extoperator) {
        $this->_extoperator = (string)$extoperator;

        return $this;
    }

    /**
     * 节点运营商
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getExtoperator() {
        return $this->_extoperator;
    }

    /**
     * 提交的频道
     * 
     * Column Type: varchar(64)
     * 
     * @param string $channel
     * @return \TaskresulturlModel
     */
    public function setChannel($channel) {
        $this->_channel = (string)$channel;

        return $this;
    }

    /**
     * 提交的频道
     * 
     * Column Type: varchar(64)
     * 
     * @return string
     */
    public function getChannel() {
        return $this->_channel;
    }

    /**
     * 节点DNS
     * 
     * Column Type: varchar(15)
     * 
     * @param string $dns
     * @return \TaskresulturlModel
     */
    public function setDns($dns) {
        $this->_dns = (string)$dns;

        return $this;
    }

    /**
     * 节点DNS
     * 
     * Column Type: varchar(15)
     * 
     * @return string
     */
    public function getDns() {
        return $this->_dns;
    }

    /**
     * 节点浏览器
     * 
     * Column Type: text
     * 
     * @param string $browser
     * @return \TaskresulturlModel
     */
    public function setBrowser($browser) {
        $this->_browser = (string)$browser;

        return $this;
    }

    /**
     * 节点浏览器
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getBrowser() {
        return $this->_browser;
    }

    /**
     * ip所在地址
     * 
     * Column Type: varchar(255)
     * 
     * @param string $location
     * @return \TaskresulturlModel
     */
    public function setLocation($location) {
        $this->_location = (string)$location;

        return $this;
    }

    /**
     * ip所在地址
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getLocation() {
        return $this->_location;
    }

    /**
     * 节点ip
     * 
     * Column Type: varchar(15)
     * 
     * @param string $ip
     * @return \TaskresulturlModel
     */
    public function setIp($ip) {
        $this->_ip = (string)$ip;

        return $this;
    }

    /**
     * 节点ip
     * 
     * Column Type: varchar(15)
     * 
     * @return string
     */
    public function getIp() {
        return $this->_ip;
    }

    /**
     * 请求的url
     * 
     * Column Type: text
     * 
     * @param string $url
     * @return \TaskresulturlModel
     */
    public function setUrl($url) {
        $this->_url = (string)$url;

        return $this;
    }

    /**
     * 请求的url
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getUrl() {
        return $this->_url;
    }

    /**
     * 最后返回的url
     * 
     * Column Type: text
     * 
     * @param string $lasturl
     * @return \TaskresulturlModel
     */
    public function setLasturl($lasturl) {
        $this->_lasturl = (string)$lasturl;

        return $this;
    }

    /**
     * 最后返回的url
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getLasturl() {
        return $this->_lasturl;
    }

    /**
     * Referer
     * 
     * Column Type: text
     * 
     * @param string $referer
     * @return \TaskresulturlModel
     */
    public function setReferer($referer) {
        $this->_referer = (string)$referer;

        return $this;
    }

    /**
     * Referer
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getReferer() {
        return $this->_referer;
    }

    /**
     * html返回码
     * 
     * Column Type: varchar(255)
     * 
     * @param string $code
     * @return \TaskresulturlModel
     */
    public function setCode($code) {
        $this->_code = (string)$code;

        return $this;
    }

    /**
     * html返回码
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getCode() {
        return $this->_code;
    }

    /**
     * 编码
     * 
     * Column Type: varchar(255)
     * 
     * @param string $charset
     * @return \TaskresulturlModel
     */
    public function setCharset($charset) {
        $this->_charset = (string)$charset;

        return $this;
    }

    /**
     * 编码
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getCharset() {
        return $this->_charset;
    }

    /**
     * 返回头部
     * 
     * Column Type: text
     * 
     * @param string $header
     * @return \TaskresulturlModel
     */
    public function setHeader($header) {
        $this->_header = (string)$header;

        return $this;
    }

    /**
     * 返回头部
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getHeader() {
        return $this->_header;
    }

    /**
     * 内容大小，取header数据
     * 
     * Column Type: int(11) unsigned
     * Default: 0
     * 
     * @param int $size
     * @return \TaskresulturlModel
     */
    public function setSize($size) {
        $this->_size = (int)$size;

        return $this;
    }

    /**
     * 内容大小，取header数据
     * 
     * Column Type: int(11) unsigned
     * Default: 0
     * 
     * @return int
     */
    public function getSize() {
        return $this->_size;
    }

    /**
     * 返回标题
     * 
     * Column Type: text
     * 
     * @param string $title
     * @return \TaskresulturlModel
     */
    public function setTitle($title) {
        $this->_title = (string)$title;

        return $this;
    }

    /**
     * 返回标题
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getTitle() {
        return $this->_title;
    }

    /**
     * 返回关键字
     * 
     * Column Type: text
     * 
     * @param string $keywords
     * @return \TaskresulturlModel
     */
    public function setKeywords($keywords) {
        $this->_keywords = (string)$keywords;

        return $this;
    }

    /**
     * 返回关键字
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getKeywords() {
        return $this->_keywords;
    }

    /**
     * 返回秒速
     * 
     * Column Type: text
     * 
     * @param string $description
     * @return \TaskresulturlModel
     */
    public function setDescription($description) {
        $this->_description = (string)$description;

        return $this;
    }

    /**
     * 返回秒速
     * 
     * Column Type: text
     * 
     * @return string
     */
    public function getDescription() {
        return $this->_description;
    }

    /**
     * 截图文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @param string $screen
     * @return \TaskresulturlModel
     */
    public function setScreen($screen) {
        $this->_screen = (string)$screen;

        return $this;
    }

    /**
     * 截图文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getScreen() {
        return $this->_screen;
    }

    /**
     * 渲染后的源码文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @param string $source
     * @return \TaskresulturlModel
     */
    public function setSource($source) {
        $this->_source = (string)$source;

        return $this;
    }

    /**
     * 渲染后的源码文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getSource() {
        return $this->_source;
    }

    /**
     * 未渲染后的源码文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @param string $originsource
     * @return \TaskresulturlModel
     */
    public function setOriginsource($originsource) {
        $this->_originsource = (string)$originsource;

        return $this;
    }

    /**
     * 未渲染后的源码文件地址
     * 
     * Column Type: varchar(255)
     * 
     * @return string
     */
    public function getOriginsource() {
        return $this->_originsource;
    }

    /**
     * Sourcemd5
     * 
     * Column Type: varchar(32)
     * 
     * @param string $sourcemd5
     * @return \TaskresulturlModel
     */
    public function setSourcemd5($sourcemd5) {
        $this->_sourcemd5 = (string)$sourcemd5;

        return $this;
    }

    /**
     * Sourcemd5
     * 
     * Column Type: varchar(32)
     * 
     * @return string
     */
    public function getSourcemd5() {
        return $this->_sourcemd5;
    }

    /**
     * Originsourcemd5
     * 
     * Column Type: varchar(32)
     * 
     * @param string $originsourcemd5
     * @return \TaskresulturlModel
     */
    public function setOriginsourcemd5($originsourcemd5) {
        $this->_originsourcemd5 = (string)$originsourcemd5;

        return $this;
    }

    /**
     * Originsourcemd5
     * 
     * Column Type: varchar(32)
     * 
     * @return string
     */
    public function getOriginsourcemd5() {
        return $this->_originsourcemd5;
    }

    /**
     * Addtime
     * 
     * Column Type: bigint(20)
     * 
     * @param int $addtime
     * @return \TaskresulturlModel
     */
    public function setAddtime($addtime) {
        $this->_addtime = (int)$addtime;

        return $this;
    }

    /**
     * Addtime
     * 
     * Column Type: bigint(20)
     * 
     * @return int
     */
    public function getAddtime() {
        return $this->_addtime;
    }

    /**
     * Return a array of model properties
     * 
     * @return array
     */
    public function toArray() {
        return array(
            'id'              => $this->_id,
            'tid'             => $this->_tid,
            'ext'             => $this->_ext,
            'version'         => $this->_version,
            'extip'           => $this->_extip,
            'extarea'         => $this->_extarea,
            'extoperator'     => $this->_extoperator,
            'channel'         => $this->_channel,
            'dns'             => $this->_dns,
            'browser'         => $this->_browser,
            'location'        => $this->_location,
            'ip'              => $this->_ip,
            'url'             => $this->_url,
            'lasturl'         => $this->_lasturl,
            'referer'         => $this->_referer,
            'code'            => $this->_code,
            'charset'         => $this->_charset,
            'header'          => $this->_header,
            'size'            => $this->_size,
            'title'           => $this->_title,
            'keywords'        => $this->_keywords,
            'description'     => $this->_description,
            'screen'          => $this->_screen,
            'source'          => $this->_source,
            'originsource'    => $this->_originsource,
            'sourcemd5'       => $this->_sourcemd5,
            'originsourcemd5' => $this->_originsourcemd5,
            'addtime'         => $this->_addtime
        );
    }

}
