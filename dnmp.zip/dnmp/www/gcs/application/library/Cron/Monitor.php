<?php

namespace Cron;

// php -f ./script/work.php Monitor task
// php -f ./script/work.php Monitor ext
class Monitor extends \Cron\CronAbstract {

    public function main() {
        $argv = $this->getArgv(2);
        switch ($argv) {
            case 'task'://队列数量
                $this->task();
                break;
            case 'ext'://插件在线
                $this->ext();
                break;
            case 'filter'://处理特殊任务
                $host = $this->getArgv(3);
                $this->filter($host);
                break;
            default :
                $this->log('无任务对象');
                break;
        }
    }

    public function task(){
        $taskBs = \Business\TaskModel::getInstance();
        $result = $taskBs->status();
        if($result){
            $redis = $this->getRedis();
            $data = $taskBs->getResultData();
            $limit = 200;
            foreach($data as $k => $v){
                $exist = $redis->get('monitor:task:'.$k);
                if(!$exist && $v > $limit){
                    $redis->set('monitor:task:'.$k, 1);
                    $this->log('[monitor][task][过多]'.' '.$k.' '.$v);
                    $this->nodifyWeixinMsg('查劫持队列过多', '队列【'.$k.'】数量'.$v);
                }elseif($exist && $v <= ($limit-10)){
                    $redis->del('monitor:task:'.$k);
                    $this->log('[monitor][task][恢复]'.' '.$k.' '.$v);
                    $this->nodifyWeixinMsg('查劫持队列恢复', '队列【'.$k.'】数量'.$v);
                }
            }
            //var_dump($data);
        }
    }

    public function ext(){
        $time = time();
        $redis = $this->getRedis();
        $exts = $redis->ZRANGEBYSCORE('monitor:ext', 1, $time-1200, ['withscores'=>true]);
        foreach($exts as $ext=>$expire){
            $redis->zadd('monitor:ext', -$expire, $ext);
            $this->log('[monitor][ext][timeout]'.' '.$ext);
            $this->nodifyWeixinMsg('查劫持心跳', '插件【'.$ext.'】超过二十分钟无请求');
        }
    }

    public function filter($host){
        //$toolBs = \Business\ToolModel::getInstance();
        //$toolBs->filterFriendLink($host);
    }
}
