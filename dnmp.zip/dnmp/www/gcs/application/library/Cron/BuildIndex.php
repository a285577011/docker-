<?php

namespace Cron;

// php -f ./script/work.php BuildIndex
class BuildIndex extends \Cron\CronAbstract {

    public function main() {
        $searchBs = \Business\SearchModel::getInstance();
        $searchBs->xunIndex();
    }
}
