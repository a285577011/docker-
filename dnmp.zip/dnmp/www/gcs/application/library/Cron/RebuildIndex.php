<?php

namespace Cron;

// php -f ./script/work.php RebuildIndex
class RebuildIndex extends \Cron\CronAbstract {

    public function main() {
        $searchBs = \Business\SearchModel::getInstance();
        $searchBs->xunReindex();
    }
}
