<?php

namespace Cron;

//处理任务队列
class Task extends \Cron\CronAbstract {

    /**
     * /usr/local/Cellar/php71/7.1.25/bin/php -f ./script/work.php task task
     * /usr/local/Cellar/php71/7.1.25/bin/php -f ./script/work.php task pending
     */
    public function main() {
        $argv = $this->getArgv(2);
        switch ($argv) {
            case 'task'://把任务压入等待处理
                $this->processTask();
                break;
            case 'pending'://处理未处理完成的任务
                $this->processPending();
                break;
            default :
                $this->log('无任务对象');
                break;
        }
    }

    public function processTask() {
        $taskBs = \Business\TaskModel::getInstance();

        $beginTime = time();
        while (time() - $beginTime < 60) {
            $result = $taskBs->processTask();
            if(!$result){
                sleep(1);
            }
        }
    }

    protected function processPending(){
        $taskBs = \Business\TaskModel::getInstance();

        $beginTime = time();
        while (time() - $beginTime < 60) {
            $results = $taskBs->processPending();
            if(count($results)>0){
                foreach($results as $id => $status){
                    $this->log($id.' '.($status?'sucess':'fail'));
                }
            }else{
                sleep(1);
            }
        }
    }
}
